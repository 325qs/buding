
//=============================================================================
// Patch_StartOfBattlePassiveCards
//=============================================================================

drill_cowa_iscalculating = function() {
    return false; // 或者根据你的需求返回正确的值
};

Game_Actor.prototype.performStartOfBattlePassiveCards = function () {
    for (var i = 0; i < this._cardDeck.length; i++) {
        var card = this._cardDeck.card(i);
        var cardId = card.id();
        var skill = $dataSkills[cardId];
        if (skill && skill._cardPassives && skill._cardPassives.startInZone == 'hand') {
            this.drawCardOfSkillId(cardId);
        }
    }
};