//=============================================================================
// IsiahCardGameCombat                                              
//=============================================================================
/*:
 * @target MZ
 * @author Isiah Brighton
 * @plugindesc v1.5.7 把技能变成卡牌
 * @url https://mythatelier.itch.io/card-game-combat
 * 
 * 
 * @param startOfBattleActions
 * @text 战斗开始动作
 * @desc 在角色的第一个回合/战斗开始时抽取的卡牌数，以“\”分隔。
 * 格式："Shuffle Deck\nDraw 5"
 * @type note
 * @default "Shuffle Deck, Draw 5"
 * 
 * @param startOfTurnActions
 * @text 每回合开始动作
 * @desc 在玩家第二回合开始时，以新线分隔的行动列表。
 * 格式："Discard Until 0（手牌剩余*张）, Draw 5（抽取*张）"
 * @type note
 * @default "Discard Until 0, Draw 5"
 * 
 * @param maxHandSize
 * @text 手牌上限
 * @type number
 * @default -1
 * @min -1
 * @desc 角色手上牌数达到最大限制时，无法抽牌。设置为-1表示手牌无上限。
 * 
 * 
 * @param 卡牌外观
 * 
 *   @param cardDesign
 *   @text 默认卡组
 *   @parent 卡牌外观
 *   @type file
 *   @dir img/system
 *   @require 1
 *   @desc 用于卡片模板的默认图像
 *   
 *   @param cardDesignDirectory
 *   @text 卡组填充文件夹设置
 *   @parent 卡牌外观
 *   @default system
 *   @desc 所有卡组填充文件，所在文件夹的名称
 *
 *   @param cardArtDirectory
 *   @text 卡片装饰目录文件夹
 *   @parent 卡牌外观
 *   @default system
 *   @desc 填入文件夹的名称，所有的卡片装饰将被寻找
 *   
 *   @param iconSize
 *   @text 图标大小
 *   @parent 卡牌外观
 *   @type number
 *   @default 16
 *   @desc 图标可能需要在卡片上按比例绘制。这是像素的宽度/高度图标设置。
 *   
 *   @param 卡牌名称设置
 *   @parent Card Appearance
 *   
 *       @param cardNameFont
 *       @text 卡牌名称字体大小
 *       @parent 卡牌名称设置
 *       @type number
 *       @default 16
 *       @desc 卡牌/技能名称的字体大小
 *       
 *       @param cardNameX
 *       @text 名片名称X
 *       @parent 卡牌名称设置
 *       @type number
 *       @default 6
 *       @min -99
 *       @desc 卡片名称将开始在卡片上绘制的X坐标。
 *
 *       @param cardNameY
 *       @text 名片名称Y
 *       @parent 卡牌名称设置
 *       @type number
 *       @default -4
 *       @min -99
 *       @desc 卡片名称将开始在卡片上绘制的Y坐标。
 *   
 *   @param 技能成本
 *   @parent Card Appearance
 *   
 *       @param skillCostX
 *       @text 技能消耗X轴
 *       @parent 技能成本
 *       @type number
 *       @default 0
 *       @desc 消耗是右对齐的，所以这个数字越高，它出现的位置就越靠左。
 *   
 *       @param skillCostY
 *       @text 技能消耗X轴
 *       @parent 技能成本
 *       @type number
 *       @default 8
 *       @desc 将显示成本的Y坐标。
 *       
 *   
 *   
 *   @param displayCardDesc
 *   @text 显示卡牌描述
 *   @parent Card Appearance
 *   @type boolean
 *   @default true
 *   @desc 如果设置为OFF，卡片将不会显示它们的描述，你可以忽略这组插件参数。
 *   
 *       @param cardDescFont
 *       @text 卡片说明字体大小
 *       @parent displayCardDesc
 *       @type number
 *       @default 12
 *       @desc 卡片描述的字体大小。
 *   
 *       @param cardDescX
 *       @text 卡片描述X轴
 *       @parent displayCardDesc
 *       @type number
 *       @default 4
 *       @desc c卡片描述将开始在卡片上绘制的X坐标。
 *       
 *       @param cardDescY
 *       @text 卡片描述Y轴
 *       @parent displayCardDesc
 *       @type number
 *       @default 100
 *       @desc 卡片描述将开始在卡片上绘制的Y坐标。
 *       
 *       @param cardDescW
 *       @text 卡片描述宽度
 *       @parent displayCardDesc
 *       @type number
 *       @default 0
 *       @desc 用于绘制卡片描述的空间宽度。留0以使用整个卡片宽度。需要YEP_MessageCore插件。
 *   
 *   
 *   @param cardEnabledImage
 *   @text 可使用卡牌标记
 *   @parent Card Appearance
 *   @type file
 *   @dir img/system
 *   @desc 当纸牌可以使用时，出现在纸牌底部的边框。
 *   
 *   @param cardDiscardImage
 *   @text 选择丢弃卡牌时标记
 *   @parent Card Appearance
 *   @type file
 *   @dir img/system
 *   @desc 当卡片可以被选择时出现在卡片顶部的边框
 *   
 *   @param removalAnimation
 *   @text 移除卡牌动画效果
 *   @parent Card Appearance
 *   @type select
 *   @option Fade
 *   @option Burn
 *   @default Fade
 *   @desc 卡将展示的特定行为，以显示它被移除。
 *   
 * @param 手牌外表
 *
 *   @param handY
 *   @parent 手牌外表
 *   @text 手卡Y坐标
 *   @type number
 *   @default 554
 *   @desc 在战斗中手牌的y坐标。一般推荐屏幕底部。
 *   
 *   @param handCenter
 *   @parent 手牌外表
 *   @text 手卡X坐标
 *   @type number
 *   @desc 手卡中心的x坐标。默认值是408，是RM默认窗口宽度的一半。
 *   @default 408
 *
 *   @param selectedCardYOff
 *   @parent 手牌外表
 *   @text 选定卡片Y偏移量
 *   @type number
 *   @default 40
 *   @desc 当前选中的牌的像素数将高于手牌的其余部分
 *
 *   @param discardingCardYOff
 *   @parent 卡牌外表
 *   @text 弃牌Y偏移
 *   @type number
 *   @default 40
 *   @desc 如果一张卡被选择丢弃，它将被提升的像素数。
 *
 *   @param inactiveCardYOff
 *   @parent 卡牌外表
 *   @text 非活动手Y偏移量
 *   @type number
 *   @default 40
 *   @desc 如果玩家当前不能选择纸牌，所有纸牌的像素数将会降低。
 *
 *   @param maxHandWidth
 *   @parent 卡牌外表
 *   @text 最大手牌宽度
 *   @type number
 *   @default 816
 *   @desc 手牌所能占据的最大水平空间。
 *   
 *   @param minCardSeparationW
 *   @parent 手牌外表
 *   @text 最小卡片分离距离
 *   @type number
 *   @default 60
 *   @desc 在达到最大宽度之前，卡片之间的最小像素空间。
 *   
 *   @param cardRotationMulti
 *   @parent 手牌外表
 *   @text 卡片旋转倍增器
 *   @type number
 *   @decimals 2
 *   @min -100
 *   @default 1.00
 *   @desc 一张牌旋转的数量取决于它离手的中心有多远。
 *   
 *   @param cardHeightMulti
 *   @parent 手牌外表
 *   @text 卡片旋转倍增器
 *   @type number
 *   @decimals 2
 *   @min -100
 *   @default 1.00
 *   @desc 卡的高度变化取决于他们的距离中心的手。这将为该值增加一个乘数。
 * 
 * 
 * @param Deck Appearance
 * @text 在战斗中卡组外观
 * 
 *   @param deckImage
 *   @text 卡组的形象
 *   @parent 在战斗中卡组外观
 *   @type file
 *   @dir img/system
 *   @require 1
 *   @desc 代表玩家在战斗中的牌组的图像。
 *   
 *   @param deckX
 *   @text 卡组的X坐标
 *   @parent 在战斗中卡组外观
 *   @type number
 *   @min -9999
 *   @desc 战斗中卡组图像的x坐标
 *   
 *   @param deckY
 *   @text 卡组的Y坐标
 *   @parent 在战斗中卡组外观
 *   @type number
 *   @min -9999
 *   @desc 战斗中卡组图像的Y坐标
 *   
 *   @param deckScale
 *   @text 卡组显示大小
 *   @parent 在战斗中卡组外观
 *   @type number
 *   @min 0
 *   @max 4
 *   @default 1
 *   @decimals 4
 *   @desc 当抽牌从牌组中出现时，计数就会开始。如果牌组图标很小，很有用。
 *   
 *   @param deckRotation
 *   @text 卡牌旋转（发牌）
 *   @parent 在战斗中卡组外观
 *   @type number
 *   @min -360
 *   @max 360
 *   @default 0
 *   @desc 抽卡开始时，他们从牌组中出现。如果牌组图标被设计成歪斜的，就很有用。
 *   
 *   @param deckNumberSize
 *   @parent 在战斗中卡组外观
 *   @text 卡组数量号码字体大小
 *   @type number
 *   @default 24
 *   @desc 显示角色牌组中当前有多少张牌的文本的字体大小。设置为0以隐藏此数字。
 * 
 *   @param deckNumberX
 *   @text 卡组数量X轴
 *   @parent Deck Appearance
 *   @type number
 *   @default 0
 *   @desc 卡组图像右侧的“左”的多少像素将显示卡组号。
 * 
 *   @param deckNumberY
 *   @text 卡组数量Y轴
 *   @parent Deck Appearance
 *   @type number
 *   @default 0
 *   @desc 显示牌组中牌的数量的文本的y坐标。基于顶部的甲板图像。
 *   
 *   
 * 
 * @param Discard Appearance
 * @text 战斗中弃牌外观
 * 
 *   @param discardImage
 *   @text 丢牌区外表
 *   @parent 战斗中弃牌外观
 *   @type file
 *   @dir img/system
 *   @require 1
 *   @desc 表示玩家在战斗中的弃牌堆的图像。
 *   
 *   @param showDiscard
 *   @text 显示丢弃图像?
 *   @parent 战斗中弃牌外观
 *   @type boolean
 *   @default true
 *   @desc 如果设置为OFF，丢弃堆将由最后丢弃的卡代替上面的图像表示。
 *   
 *   @param discardX
 *   @text 弃牌区X坐标
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @min -9999
 *   @desc 战斗中弃牌堆的x坐标
 *   
 *   @param discardY
 *   @text 弃牌区Y坐标
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @min -9999
 *   @desc 战斗中弃牌堆的Y坐标
 *   
 *   @param discardScale
 *   @text 弃牌区大小
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @min 0
 *   @max 4
 *   @default 1
 *   @decimals 4
 *   @desc 比例卡将成为当他们被丢弃。如果丢弃图标很小就有用。
 *   
 *   @param discardRotation
 *   @text 弃牌轮换
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @min -360
 *   @max 360
 *   @default 0
 *   @desc 当使用的卡被丢弃时将会有。如果丢弃图标被设计成弯曲的，则很有用。
 *   
 *   @param discardNumberSize
 *   @parent 战斗中弃牌外观
 *   @text 丢弃数量字体大小
 *   @type number
 *   @default 24
 *   @desc 显示当前在弃牌堆中有多少张牌的文本的字体大小。设置为0以隐藏此数字。
 * 
 *   @param discardNumberX
 *   @text 丢弃数量字体X轴
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @default 0
 *   @desc 丢弃图像右侧的“左”的多少像素将显示在弃牌区。
 * 
 *   @param discardNumberY
 *   @text 丢弃数量字体Y轴
 *   @parent 战斗中弃牌外观
 *   @type number
 *   @default 0
 *   @desc 显示弃牌数量的文本的y坐标。基于丢弃图像的顶部。
 * 
 * 
 * @param changeBattleWindows
 * @text 是否改变战斗窗口
 * @type boolean
 * @default true
 * @desc 设置为关闭，如果你有其他插件，增加战斗状态窗口和角色命令窗口。
 * 
 *   @param showHelpWindow
 *   @parent changeBattleWindows
 *   @text 显示帮助窗口
 *   @type boolean
 *   @default true
 *   @desc 如果显示卡片描述，您可以关闭技能的帮助窗口。帮助窗口仍然出现在其他事情上。
 *   
 *   @param skipActorCommand
 *   @parent changeBattleWindows
 *   @text 跳过角色命令菜单
 *   @type boolean
 *   @default true
 *   @desc 如果设置为ON，玩家将直接进入卡牌选择，而不是选择攻击/防御、背包界面。
 *   
 *   @param statusWindowTop
 *   @parent changeBattleWindows
 *   @text 顶部状态窗口
 *   @type boolean
 *   @default true
 *   @desc 如果设置为ON，状态窗口(和命令窗口)将出现在屏幕的顶部，在帮助窗口下面。
 *   
 *   @param displayStatusCardIcons
 *   @parent changeBattleWindows
 *   @text :显示卡片图标
 *   @type boolean
 *   @default true
 *   @desc 如果设置为ON，额外的图标将出现在战斗状态窗口，显示每个角色在每个区域有多少牌。
 *   
 *     @param handSizeIcon
 *     @parent displayStatusCardIcons
 *     @text :手牌图标样式
 *     @type number
 *     @default 1
 *     @desc 代表角色手牌的图标的图标样式。
 *     
 *     @param deckSizeIcon
 *     @parent displayStatusCardIcons
 *     @text 卡组图标样式
 *     @type number
 *     @default 2
 *     @desc 代表玩家牌组的图标样式。
 *     
 *     @param discardSizeIcon
 *     @parent displayStatusCardIcons
 *     @text 丢弃图标样式
 *     @default 3
 *     @desc 表示角色丢弃的图标的图标样式。
 *   
 * @param 额外的战斗按钮
 * 
 *   @param buttonOrder
 *   @parent 额外的战斗按钮
 *   @text 按钮顺序
 *   @type string
 *   @default Item Hand End
 *   @desc 按您想要的顺序放置按钮的名称。大小写敏感的。默认为“技能栏”
 * 
 *   @param End Turn Button
 *   @parent 额外的战斗按钮
 *   @desc 如果按钮顺序不包含'End'忽略它。结束回合按钮将不会出现。
 *   
 *     @param endTurnSkill
 *     @parent 额外的战斗按钮
 *     @text 结束回合技能
 *     @type skill
 *     @default 2
 *     @desc 当你按下结束回合按钮时执行的技能
 *     
 *     @param endTurnImage
 *     @parent 额外的战斗按钮
 *     @text 结束旋转图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc :用于结束旋转按钮的图像。
 *     
 *     @param endTurnDisabledImage
 *     @parent 额外的战斗按钮
 *     @text 结束转禁用图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 无法按下结束旋转按钮时使用的图像。
 *     
 *     @param endTurnHighlight
 *     @parent 额外的战斗按钮
 *     @text 结束回合图标
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 图片显示时覆盖在结束回合按钮上的图像。
 *     
 *     @param endTurnDiscard
 *     @parent 额外的战斗按钮
 *     @text 结束回合丢弃图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 当玩家确认弃牌时，用于确定丢弃的按钮图像。
 *     
 *     @param endTurnDiscardDisabled
 *     @parent 额外的战斗按钮
 *     @text :丢弃卡牌结束图标
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 当玩家必须选择弃牌时，用于结束回合按钮的图像。
 *     
 *     @param endTurnButtonX
 *     @parent 额外的战斗按钮
 *     @text 按钮X坐标
 *     @type number
 *     @desc 结束回合按钮在屏幕上的x坐标。
 *     
 *     @param endTurnButtonY
 *     @parent 额外的战斗按钮
 *     @text 按钮Y坐标
 *     @type number
 *     @desc 结束回合按钮在屏幕上的y坐标。
 *     
 *     @param endTurnCondition
 *     @parent 额外的战斗按钮
 *     @text 是否启用结束按钮
 *     @type text
 *     @default true
 *     @desc 要使用的按钮必须求值为true的表达式
 *     
 *   @param 项目菜单按钮
 *   @parent Extra Battle Buttons
 *   @desc 如果按钮订单不包含“Item”忽略它。项目按钮将不会出现。
 *
 *     @param itemImage
 *     @parent 项目菜单按钮
 *     @text 背包按钮图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 用于项目菜单按钮的图像。
 *
 *     @param itemDisabledImage
 *     @parent 项目菜单按钮
 *     @text 背包按钮禁用图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 无法按下项目菜单按钮时使用的图像。
 *
 *     @param itemHighlight
 *     @parent 项目菜单按钮
 *     @text 背包按钮高亮显示图像
 *     @type file
 *     @dir img/system
 *     @require 1
 *     @desc 背包菜单按钮高亮显示时覆盖在其上的图像。
 *     
 *     @param itemButtonX
 *     @parent 项目菜单按钮
 *     @text 背包菜单按钮X轴
 *     @type number
 *     @desc 背包按钮在屏幕上的x坐标。你应该把它放在左手边。
 *
 *     @param itemButtonY
 *     @parent 项目菜单按钮
 *     @text 背包菜单按钮Y轴
 *     @type number
 *     @desc 背包按钮在屏幕上的y坐标。
 *     
 *     @param itemButtonDescription
 *     @parent 项目菜单按钮
 *     @text 项目按钮说明
 *     @default Open the Item Menu
 *     @desc当项目按钮高亮显示时，在帮助窗口上显示的文本。
 *
 *     @param itemButtonCondition
 *     @parent 项目菜单按钮
 *     @text 背包菜单是否启用
 *     @type text
 *     @default true
 *     @desc 要使用的按钮必须求值为true的表达式
 *     
 * @param 技能菜单
 * 
 *   @param cardLibraryForSkill
 *   @parent 技能菜单
 *   @text 将技能菜单替换为库
 *   @type boolean
 *   @desc 如果设置为ON，卡牌库将取代技能菜单，并忽略下一个参数。
 *   @default true
 *   
 *   @param showCardLibraryInMenu
 *   @parent 技能菜单
 *   @text 在菜单中显示卡片库
 *   @type boolean
 *   @desc 如果设置为ON，菜单将有一个打开卡库的选项。可以用插件命令关闭。
 *   @default false
 *   
 *   @param cardLibraryMenuDesc
 *   @parent 技能菜单
 *   @text 卡片库菜单文本
 *   @desc 菜单中显示的文本，用于打开卡库。
 *   @default Cards
 *   
 *   @param simpleView
 *   @parent 技能菜单
 *   @text 简单视图
 *   @desc 如果将此设置为ON，则角色卡的每个副本将单独显示。
 *   @type boolean
 *   @default false
 *   
 *   @param showMissingCards
 *   @parent 技能菜单
 *   @text 在图书馆显示丢失的卡片
 *   @desc 如果此设置为ON，则技能场景中丢失的卡将显示为灰色。
 *   @type boolean
 *   @default false
 * 
 * @command setCardBattle
 * @text Set Card Battle
 * 
 *   @arg enabled
 *   @type bool
 *   @default true
 *   @desc If ON, battles will be card battles. If OFF, they'll be default battles.
 *   
 *   
 *   
 *   
 * @command setCardBattle
 * @text Set Card Battle
 * @desc Determines if Card Battles are enabled.
 *
 *   @arg enabled
 *   @type boolean
 *   @default true
 *   @desc If ON, battles will be card battles. If OFF, they'll be default battles.
 *
 * @command setCardLibrary
 * @text Set Card Library
 * @desc Determines if the Card Library will show up in the player's menu.
 *
 *   @arg enabled
 *   @type boolean
 *   @default true
 *   @desc If ON, the Card Library will be available in the player's menu.
 *
 * @command openCardLibrary
 * @text Open Card Library
 * @desc Opens the Card Library.
 *   
 * @help
 * 
 * ============================================================================
 * Notetag quick reference
 * ============================================================================
 * 
 * 技能方面:
 * 
 * <Hide from card library>
 *    使卡片不显示在卡片库中
 *     
 * <Card Art: file_name>
 *     使卡片的卡片美术为给定名称的文件。Art可以在插件参数的Art目录中找到
 *     
 * <Card Base: file_name>
 *     用给定名称的文件替换默认的卡基。可以在插件参数的base目录中找到base
 *     
 * 
 *     
 * 技能和项目:
 * 
 * <willEndTurn>
 *     如果你没有使用YEP_InstantCast，这将导致给定的技能在使用时结束回合。
 *     如果你正在使用YEP_InstantCast，请遵循该插件的指示。
 *     
 * 卡牌动作: 
 *     
 *     <Card Actions>
 *     action
 *     action
 *     </Card Actions>
 *     
 *     <Card Passives>
 *     passive
 *     passive
 *     </Card Passives>
 *     
 * 操作:
 * 
 * Draw X
 *     其中X是一个数字，出这张牌会使行为人抽到X张牌
 *
 * Draw Until X
 *     其中X是一个数字，将使角色抽卡牌，直到他们的手是X大小
 *
 * Discard X
 *     会让行为人弃掉X张牌
 *
 * Discard Until X
 *     会让行为人弃手牌，直到手牌的大小达到X
 *     
 * Remove X
 * Remove Until X （移除直到剩下X张）
 *     就像丢弃一样，但会从游戏中移除所选的卡牌
 *     
 * Add [skillID] to [zoneName]
 *      将卡片直接添加到一个区域。例如，
 *     “Add 7 to hand”将在你的手牌中创建一张技能ID为7的卡片。（zonename=区域名称）
 *
 * Mill X
 *     将X张牌直接从牌组移到弃牌组
 *     
 * Search For X
 * Search For [skill name]
 *     抽取具有指定技能ID (x)或名称的卡牌(如果该牌在牌组中)。
 *     
 * Move X from [zoneName] to [zoneName]
 *     这可以代替抽牌、弃牌或磨牌，但适用于所有区域。
 * 
 * Wait X
 *    导致Card Action在继续执行前等待X帧，就像RPG Maker中的等待命令一样。
 *    不工作在回合开始/战斗参数。
 *     
 * Shuffle Deck
 *    将洗牌
 *    
 * Eval [expression]
 *    将执行单词“eval”之后的任何内容作为一段代码。
 *    
 *    
 * 被动效果:
 *     
 * Remove this
 *     使用后将此牌从场上移除，而不是弃牌。
 *     
 * Discard if unplayed
 *     如果这张牌在手上而回合结束，将弃掉这张牌。
 *     
 * Remove if unplayed
 *     如果回合结束时这张牌还在手上，将从游戏中移除。
 *     
 * Start in Hand
 *     将在战斗开始时，在战斗开始之前，在玩家手中。
 *     
 * Require [expression]
 *     除非表达式的计算结果为真，否则不能播放。可以放置多个需求。
 *    使用“用户”一词来指代卡片的使用者。
 *     
 *     例如:
 *     
 *     Require user.handSize > 2
 *     Require user.handSize < 10
 *     Require $gameSwitches.value(3)
 *     
 *    只有当玩家手上的牌多于2张且少于10张时，这张牌才具有可玩性。
 *  另外，只有当游戏开关3设置为ON时才能使用。
 *
 * Start of Turn: Skill X
 *      在回合开始时，如果此卡在手，执行技能ID X。
 *
 * End of Turn: Skill X
 *      在回合结束时，如果此卡在手，执行技能ID X。
 *      
 *  Enter [zoneName]: Skill X
 *      当此卡进入指定区域后，执行技能ID X。
 *      
 *  Exit [zoneName]: Skill X
 *      当此卡退出指定区域时，执行技能ID X。
 * 
 * 
 * ============================================================================
 * 插件命令
 * ============================================================================
 * 
 * DisableCardBattle - 将游戏返回到无牌战斗状态。.
 * EnableCardBattle - 将游戏返回到卡牌对战。.
 * 这些命令必须在战斗之外调用。.
 * 
 * EnableCardLibrary - 将卡库选项添加到菜单中。.
 * DisableCardLibrary - 从菜单中删除卡库选项.
 * 
 * OpenCardLibrary - 直接打开卡库场景. 
 * 
 * 
 * ============================================================================
 * 有关更多信息和其他功能，请使用wiki*已为此和所有相关的插件:
 * http://card-game-combat-help.alwaysdata.net/
 * ============================================================================
 * 
 *
 * ============================================================================
 * Version History
 * ============================================================================
 * 
 * v1.5.7 - Fixed crash introduced in 1.5.6 when discarding cards while using
 *          Card Types while not using the End Turn Button.
 *          Forced actions such as through End of Turn: Skill X no longer break
 *          when using YEP_InstantCast
 * 
 * v1.5.6 - Start of Battle/Start of Turn Actions parameters now support
 *          multiline input and Actions are no longer separated by commas.
 *          Some backend changes to add more versatility for expansions.
 *          Fixed apparent crash if enemies move first.
 *          Created system-independant measurement of an actor's first turn
 *          so they always use Battle Start/Turn Start Actions correctly.
 *          Fixed softlock with CGCCardTypes when using Card Actions Discard/
 *          Remove X of Type when fewer than X cards of the specified Type 
 *          were in the hand.
 * 
 * v1.5.5 - Fixed bug introduced in 1.5.4 that disables the Item button
 *          Fixed crash when battling with card battle disabled but for real
 *          this time.
 * 
 * v1.5.4 - Fixed crash when exiting battle while deck is overdrawn.
 *          Fixed crash when battling with card battle disabled that was
 *          introduced in 1.5.2.
 *          Fixed graphical glitch where scaled icons would borrow a pixel
 *          from their neighbors.
 *          Card-based forced actions smoothness improved. Help Window no
 *          longer visible and input doesn't flicker for a frame.
 *          
 *          Improved compatibility with YEP_BattleEngineCore - Card-based
 *          forced actions now still work when there are multiple calls at
 *          once (like if you have 3 Start of Turn: Skill X cards in hand)
 *          Fixed bug with YEP_X_BattleSysSTB where actors don't all execute
 *          their Start of Turn Actions.
 *          Improved compatibility with YEP_CoreEngine when using PartyUI_A
 *          - Card Zone icons no longer draw in the micro status window.
 * 
 * v1.5.3 - Learn Skill is now permanent mid-battle. Cards gained by level up
 *          now works as intended.
 *          Card Name X/Card Name Y parameter names fixed.
 * 
 * v1.5.2 - Added default value to Hand Y parameter.
 *          Status Window will now take the full width of the screen if the
 *          Actor Command Window is skipped, just like it does if it displays
 *          at the top of the screen.
 *          Added plugin parameter Inactive Y Offset.
 *          Added plugin parameter Card Height Multiplier.
 *          Fixed bug where the hand fan would offset the Y positions of cards 
 *          based on the center of the screen and not the center of the hand.
 *          Fixed infinite loop crash when starting a game with more than one
 *          party member.
 *          Fixed MZ crash when selecting the Discard deck.
 *          Cards examined through CGCCardSelection now update the help window
 *          with their descriptions during battle.
 *          Fixed crash if the End Turn Button is not present in battle.
 *          Added End Turn Use Condition and Item Button Use Condition 
 *          parameters which make those buttons function more in line with the
 *          Extra Buttons plugin expansion.
 *          Fixed niche crash where start-of-turn forced action variable
 *          wouldn't initialize when using some other plugins.
 *          
 *          Compatibility updates:
 *          -YEP_X_SkillCostItems - it works but item costs do not display
 *              on the card.
 *          -Yep_BattleStatusWindow - if this is in the project, it will use
 *              that plugin's drawing of state icons over this one's.
 * 
 * 
 * v1.5.1 - Changed backend handling of cards to make extensions easier in the
 *        future. This will cause errors when loading save files from previous
 *        builds.
 *        Text indicating the amount of copies of a card an actor has no
 *        longer scales up when the card is highlighted.
 *        New parameter Card Rotation Multiplier which gives you more control
 *        over the angles of the cards in the hand.
 *        Fixed bug with Discard if Unplayed/Remove if Unplayed passives
 *        that would discard/remove the wrong card if there were multiple
 *        in the hand.
 *        
 * 
 * v1.5.0 - Added a generic Move Card Action
 *        Added Enter/Exit zone forced actions
 *        Fixed hand fan bunching together when the hand size is larger than
 *        10.
 *        Fixed crash with the Extra Button extension when selecting an extra 
 *        button during discard selection.
 *        Unsure if Mill broke during the development of 1.5 but it got 
 *        un-broke.
 *        Fixed MZ touch input when cards overlap. It should be consistent 
 *        now.
 *        Fixed the Card Library scene now showing cards when Card Types plugin
 *        is not present.
 *        Search For [skillname] now works.
 *        Simple View Card Library now actually shows the last card.
 *        Lots of backend refactoring which shouldn't change anything user-
 *        side but will make bug fixes and extensions easier.
 *         
 * 
 * v1.4.7 - Added max hand size parameter. 
 *          Added new Card Action - Add [skill ID] to [zone name]
 *          Fixed bug where cards with card art might not show text.
 *          Start of Turn/Start of Battle Card Actions now execute just like
 *          skill Card Actions - meaning multiple discards and Wait now work
 *          in these Plugin Parameters.
 * 
 * v1.4.6 - Fixed crash when selecting the item button or using Card Selection
 *          to select deck/discard when choosing cards to discard.
 *          Fixed issue with PartyUI_A that would crash in MZ at start of 
 *          battle.
 * 
 * v1.4.5 -
 *        Discard image now shows up when discard contains 0 cards.
 *        Card Library scene has been masssively optimized. Cards now spawn
 *        one-per-frame rather than all at once, which makes it look a bit
 *        different but keeps there from being a huge frame dip when you
 *        start the scene.
 *        Card Library scene no longer refreshes when you scroll down a lot.
 *        Added coordinate parameters for Card Name and Cost text.
 *        Added Card Passive Start of Turn 
 *        Added Card Passive End of Turn
 *        
 *        Fixed MZ plugin command support - plugin commands should now show
 *        up properly.
 * 
 * v1.4.1 - Fixed MZ graphical bug on the Card Library scene where rectangles
 *         would appear.
 * 
 * v1.4.0 - 
 *         Added several parameters to give more control over card name and cost
 *         Fixed icon placement in description with another plugin parameter
 *         Fixed bug where the Amount text in the Card Library wouldn't be
 *         in the right place the first time loading that card's base image.
 *         Added compatibility with IsiahCGCCardTypes v1.0!
 *         Added "Mill" Card Action
 *         Added "Search for" Card Action
 *         Added "Wait" Card Action for Skills and Items only.
 *         Cards targeting party members in the side view will now move
 *         to those actors. This also fixes graphical incompatibility with
 *         YEP_TargetCore and YEP_X_SelectionControl.
 * 
 * v1.3.5 - In MV:
 *         Added compatibility with Eli_MessageActions
 *         
 *         In MZ:
 *         Added compatibility with EliMZ_MessageActions
 *         
 * v1.3.2 - In both versions:
 *         Added ability to reorder item button, end turn button, and hand
 *         in any configuration using the plugin parameter Button Order.
 *         
 *         In MV:
 *         Added compatibility with Irina_AutoMessageColor
 *         Added compatibility with RS_MessageAlign
 * 
 * v1.3.1 - In both versions:
 *         Fixed minor memory leak when removing cards introduced in v1.3.0
 *         Fixed touch input bug when selecting cards, which existed before
 *         1.3.0 but was made worse by IsiahCGCPartyUI_A.
 *         Fixed crash from touch input on the Card Library scene.
 *         Fixed crash when adding party members mid-battle.
 * 
 * v1.3.0 - In both versions:
 *         Implemented Party Battle
 *         Added several plugin parameters relating to Status Window Card 
 *         Icons.
 *         Added plugin parameter to give you control over the X coordinate of
 *         the center point of the hand.
 *         
 *         In MV:
 *         Added drawing icons representing hand/deck/discard size on the
 *         status window. This function will work in both versions, but there
 *         is no room in the MZ-style window for these icons.
 *         
 *         In MZ:
 *         Fixed MZ-exclusive functions that would cause problems if card
 *         battle was disabled.
 * 
 * v1.2.5 - In both versions:
 *         Separated Skill scene from Card Library scene.
 *         Added DisableCardBattle and EnableCardBattle plugin commands.
 *         Added Card Base skill notetag.
 * 
 * v1.2.2 - In both versions:
 *         The player no longer needs to discard/remove cards if all enemies
 *         are defeated. The battle's over already.
 * 
 * v1.2.1 - In both versions:
 *         Fixed using \I to draw icons to card text, and fixed the spacing
 *         so it's based on scaled icon size instead of regular icon size.
 * 
 * v1.2.0 - In both versions:
 *         Added eval Card Action
 *         Added variable support to Card Action numbers
 *         Added plugin parameter to turn off descriptions from cards
 *         Added plugin parameter to turn the help window back on in the
 *             skills scene.
 *         Added compatibility with YEP_X_ExtMesPack1 and 2
 *         Fixed issue where an enemy using a skill that contains card actions
 *         would generate an error.
 *         Fixed an embarrassing typo that resulted in a crash if you used
 *             text codes to draw an icon onto the card text.
 *             
 * v1.1.1 - In MZ:
 *         Fixed bug where ending the turn as the player's first action
 *         of the battle would lead to a crash.
 *         In MV:
 *         Fixed a less significant bug where doing the same thing would
 *         skip the first turn for all other battlers.
 * 
 * v1.1.0 - In both versions:
 *         Completely restructured Card Actions
 *         Completely restructured Card Passives
 *         Added the following card passives:
 *             Discard if Unplayed
 *             Remove if Unplayed
 *             Start in Hand
 *             Require
 *         Added the removedCards variable for damage formulas.
 * v1.0.8 - Fixed softlock where drawing when the discard was empty would 
 *         prevent drawing from working for the rest of the battle.
 *         Added <Remove X> and <Remove Until X> Card Actions.
 *         Added <Remove this> Notetag.
 *         Removal comes with 2 animations - Burn and Fade.
 *         Added enabled and discard highlight sprites to cards.
 *         Fixed bug where skills with <Discard> or <Remove> notetags that
 *         also targetted multiple enemies would perform neither action
 *         correctly. Card Actions now execute at the end of an action.
 *         Added new damage formula variable cardsInPlay.
 * 
 * v1.0.7 - In MZ:
 *         No longer softlocks if you back out of a skill execution.
 *         Actor Selection Window doesn't hang around weirdly if you back out
 *         of a User-targetting skill selection.
 *         Status Window no longer disappears when you attack manually
 *         targetted enemies. Neither does the Help Window
 *         Added touch controls.
 *         
 *         In both versions:
 *         Cards that cannot be selected to be played can now still be
 *         selected for discard.
 *         
 * 
 * v1.0.6 - Added MZ compatibility! Touch controls will be fixed for MZ at a 
 *         later date.
 * 
 * v1.0.5 - Added Disabled Discard button image for better feedback when the 
 *         player needs to discard cards. The End Turn Button is no longer
 *         visible until the turn begins.
 *         Actors now only truly forget skills if the final instance of that 
 *         skill is removed from their deck.
 *         Fixed bug in Skill scene that caused highlighted card to be off
 *         by one row.
 *         The enemy selection window now follows the same size/location as
 *         the battle status window.
 *         Hitting cancel on card selection now returns to the party window.
 *         Items can now execute Card Actions.
 * 
 * v1.0.4 - Removed dependency on YEP_BattleEngineCore introduced in v1.02
 * 
 * v1.0.3 - Fixed bug with Show Missing Cards in Library parameter - missing
 *         cards would not draw consistently correctly.
 * 
 * v1.0.2 - Added compatibility with YEP_InstantCast
 * 
 * v1.0.1 - Fixed bug where cards selected out of order would not discard 
 *         properly.
 * 
 * v1.0.0 - Finished plugin
*/

var Isiah = Isiah || {};
Isiah.CGC = Isiah.CGC || {};
Isiah.CGC.version = 1.2;
Isiah.CGC.minorVersion = 5;

Isiah.Util = Isiah.Util || {};
Isiah.Util.usingMZ = (Utils.RPGMAKER_NAME == "MZ");
Isiah.Util.spritePrototype = Isiah.Util.usingMZ ? Sprite_Clickable : Sprite_Base;

var Imported = Imported || {};
Imported.IsiahCGC = true;

Isiah.Parameters = PluginManager.parameters('IsiahCardGameCombat');

Isiah.CGC.cardDirectory = Isiah.Parameters.cardArtDirectory;

Isiah.CGC.cardDesignDirectory = Isiah.Parameters.cardDesignDirectory;

Isiah.CGC.images = {
	card: Isiah.Parameters.cardDesign,
	cardDeck: Isiah.Parameters.deckImage,
	cardDiscard: Isiah.Parameters.discardImage,

	cardEnabledImage: Isiah.Parameters.cardEnabledImage,
	cardDiscardImage: Isiah.Parameters.cardDiscardImage,

	endTurn: Isiah.Parameters.endTurnImage,
	endTurnDisabled: Isiah.Parameters.endTurnDisabledImage,
	endTurnHighlight: Isiah.Parameters.endTurnHighlight,
	endTurnDiscard: Isiah.Parameters.endTurnDiscard,
	endTurnDiscardDisabled: Isiah.Parameters.endTurnDiscardDisabled,

	itemButton: Isiah.Parameters.itemImage,
	itemButtonDisabled: Isiah.Parameters.itemDisabledImage,
	itemButtonHighlight: Isiah.Parameters.itemHighlight,
};

try
{
	Isiah.CGC.startOfBattleActions = JSON.parse(Isiah.Parameters.startOfBattleActions);
	Isiah.CGC.startOfTurnActions = JSON.parse(Isiah.Parameters.startOfTurnActions);
}
catch (e)
{
	console.warn("IsiahCardGameCombat v1.5.5 changed how the Start of Battle Actions and Start of Turn Actions plugin parameters work. Your current parameters will still work, but it is recommended you redo them using multiple lines instead of commas.")
	Isiah.CGC.startOfBattleActions = Isiah.Parameters.startOfBattleActions;
	Isiah.CGC.startOfBattleActions = Isiah.CGC.startOfBattleActions.replace(/,/g, "\n");
	Isiah.CGC.startOfTurnActions = Isiah.Parameters.startOfTurnActions;
	Isiah.CGC.startOfTurnActions = Isiah.CGC.startOfTurnActions.replace(/,/g, "\n");
}



Isiah.CGC.coordinates = {
	deckX: Number(Isiah.Parameters.deckX),
	deckY: Number(Isiah.Parameters.deckY),
	deckDegrees: Number(Isiah.Parameters.deckRotation),
	deckScale: Number(Isiah.Parameters.deckScale),
	deckNumX: Number(Isiah.Parameters.deckNumberX),
	deckNumY: Number(Isiah.Parameters.deckNumberY),

	discardX: Number(Isiah.Parameters.discardX),
	discardY: Number(Isiah.Parameters.discardY),
	discardDegrees: Number(Isiah.Parameters.discardRotation),
	discardScale: Number(Isiah.Parameters.discardScale),
	discardNumX: Number(Isiah.Parameters.discardNumberX),
	discardNumY: Number(Isiah.Parameters.discardNumberY),

	handY: Number(Isiah.Parameters.handY),
	handCenter: Number(Isiah.Parameters.handCenter),
	maxHandWidth: Number(Isiah.Parameters.maxHandWidth),
	minCardSeparationW: Number(Isiah.Parameters.minCardSeparationW),
	selectedCardYOff: Number(Isiah.Parameters.selectedCardYOff),
	discardingCardYOff: Number(Isiah.Parameters.discardingCardYOff),
	inactiveCardYOff: Number(Isiah.Parameters.inactiveCardYOff),
	cardRotationMulti: Number(Isiah.Parameters.cardRotationMulti),
	cardHeightMulti: Number(Isiah.Parameters.cardHeightMulti),

	cardNameX: Number(Isiah.Parameters.cardNameX),
	cardNameY: Number(Isiah.Parameters.cardNameY),

	cardNameWidth: 80,
	skillCostX: Number(Isiah.Parameters.skillCostX),
	skillCostY: Number(Isiah.Parameters.skillCostY),
	cardDescX: Number(Isiah.Parameters.cardDescX),
	cardDescY: Number(Isiah.Parameters.cardDescY),
	cardDescIconY: 4,
	cardDescWidth: Number(Isiah.Parameters.cardDescW),
	displayCardDesc: JSON.parse(Isiah.Parameters.displayCardDesc),


	endTurnButtonX: Number(Isiah.Parameters.endTurnButtonX),
	endTurnButtonY: Number(Isiah.Parameters.endTurnButtonY),

	itemButtonX: Number(Isiah.Parameters.itemButtonX),
	itemButtonY: Number(Isiah.Parameters.itemButtonY),
}

Isiah.CGC.fontSizes = {
	cardName: Number(Isiah.Parameters.cardNameFont),
	cardDesc: Number(Isiah.Parameters.cardDescFont),

	iconSize: Number(Isiah.Parameters.iconSize),

	deckNum: Number(Isiah.Parameters.deckNumberSize),
	discardNum: Number(Isiah.Parameters.discardNumberSize)
}

Isiah.CGC.statusIcons = {
	handSize: Number(Isiah.Parameters.handSizeIcon),
	deckSize: Number(Isiah.Parameters.deckSizeIcon),
	discardSize: Number(Isiah.Parameters.discardSizeIcon)
}

Isiah.CGC.addLearnedSkillToDeck = true;

Isiah.CGC.simpleDeckView = JSON.parse(Isiah.Parameters.simpleView);
Isiah.CGC.showMissingCardsInLibrary = JSON.parse(Isiah.Parameters.showMissingCards);

Isiah.CGC.changeBattleWindows = JSON.parse(Isiah.Parameters.changeBattleWindows);
Isiah.CGC.showHelpWindow = JSON.parse(Isiah.Parameters.showHelpWindow);
Isiah.CGC.showHelpWindowInSkillScene = true;//JSON.parse(Isiah.Parameters.showHelpWindow);
Isiah.CGC.statusWindowAtTop = JSON.parse(Isiah.Parameters.statusWindowTop);
Isiah.CGC.skipActorCommand = JSON.parse(Isiah.Parameters.skipActorCommand);
Isiah.CGC.drawCardZones = true;
Isiah.CGC.battleStatusZoneInfo = true;

Isiah.CGC.buttonOrder = Isiah.Parameters.buttonOrder;
Isiah.CGC.buttonOrder = Isiah.CGC.buttonOrder.split(' ');

Isiah.CGC.showEndTurn = Isiah.CGC.buttonOrder.includes("End");//JSON.parse(Isiah.Parameters.showEndTurn);
Isiah.CGC.endTurnSkill = Number(Isiah.Parameters.endTurnSkill);
Isiah.CGC.endTurnCondition = Isiah.Parameters.endTurnCondition;

Isiah.CGC.showItemButton = Isiah.CGC.buttonOrder.includes("Item");//JSON.parse(Isiah.Parameters.showItemButton);

Isiah.CGC.maxHandSize = Number(Isiah.Parameters.maxHandSize);



Isiah.CGC.itemMenuDescription = Isiah.Parameters.itemButtonDescription;
Isiah.CGC.itemButtonCondition = Isiah.Parameters.itemButtonCondition;

Isiah.CGC.showDiscardImage = JSON.parse(Isiah.Parameters.showDiscard);
Isiah.CGC.removeMode = Isiah.Parameters.removalAnimation;

Isiah.CGC.displayStatusCardIcons = JSON.parse(Isiah.Parameters.displayStatusCardIcons);


Isiah.CGC.cardLibraryForSkill = JSON.parse(Isiah.Parameters.cardLibraryForSkill);
Isiah.CGC.cardLibraryMenuDesc = Isiah.Parameters.cardLibraryMenuDesc;

//Unimplemented
Isiah.CGC.endTurnDescription = "End your turn";
Isiah.CGC.discardDescription = "Discard the selected cards";


//Plugin Commands change these
Isiah.CGC.showCardLibraryInMenu = JSON.parse(Isiah.Parameters.showCardLibraryInMenu);


Isiah.CGC.Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
Game_Interpreter.prototype.pluginCommand = function (command, args)
{
	Isiah.CGC.Game_Interpreter_pluginCommand.call(this, command, args);
	if (command.toLowerCase() == 'enablecardbattle') $gameSystem.setCardBattle(true);
	if (command.toLowerCase() == 'disablecardbattle') $gameSystem.setCardBattle(false);
	if (command.toLowerCase() == 'enablecardlibrary') $gameSystem.setShowCardLibrary(true);
	if (command.toLowerCase() == 'disablecardlibrary') $gameSystem.setShowCardLibrary(false);
	if (command.toLowerCase() == 'opencardlibrary') SceneManager.push(Scene_CardLibrary);
};

if (Isiah.Util.usingMZ)
{
	PluginManager.registerCommand("IsiahCardGameCombat", "setCardBattle", args =>
	{
		const arg0 = JSON.parse(args.enabled);
		$gameSystem.setCardBattle(arg0);
	});

	PluginManager.registerCommand("IsiahCardGameCombat", "setCardLibrary", args =>
	{
		const arg0 = JSON.parse(args.enabled);
		$gameSystem.setShowCardLibrary(arg0);
	});

	PluginManager.registerCommand("IsiahCardGameCombat", "openCardLibrary", args =>
	{
		SceneManager.push(Scene_CardLibrary);
	});
}

//=============================================================================
// Game_System
//=============================================================================

Isiah.CGC.Game_System_initialize = Game_System.prototype.initialize;
Game_System.prototype.initialize = function ()
{
	Isiah.CGC.Game_System_initialize.call(this);
	this.initCardSettings();
};

Game_System.prototype.initCardSettings = function ()
{
	this._cardBattleEnabled = true;
	this._showCardLibraryInMenu = Isiah.CGC.showCardLibraryInMenu;
};

Game_System.prototype.setCardBattle = function (enabled)
{
	this._cardBattleEnabled = enabled;
};

Game_System.prototype.setShowCardLibrary = function (enabled)
{
	this._showCardLibraryInMenu = enabled;
}



function Game_Card()
{
	this.initialize(...arguments);
}

Game_Card.prototype.initialize = function (skillId, origin)
{
	this._skillId = skillId;
	if (origin)
		this._origin = origin;
	else
		this._origin = "learned";
}

Game_Card.prototype.id = function ()
{
	return this._skillId;
};

Game_Card.prototype.origin = function ()
{
	return this._origin;
};

//The wrapper class for a card array.

function Game_Cards()
{
	this.initialize(...arguments);
}

Game_Cards.prototype.initialize = function (name)
{
	this._data = [];
	this.length = 0;
	this.name = name;
};

Game_Cards.prototype.push = function (skillId, origin)
{
	var card = new Game_Card(skillId, origin);
	this._data.push(card);
	this.length++;
	return card;
};

Game_Cards.prototype.add = function (card)
{
	if (card instanceof Game_Card)
	{
		this._data.push(card);
		this.length++;
	}
}

Game_Cards.prototype.addNextToDuplicates = function (card)
{
	if (card instanceof Game_Card)
	{
		var pushed = false;
		for (var i = 0; i < this._data.length; i++)
		{
			var c = this._data[i];
			if (c.id() == card.id())
			{
				this._data.splice(i, 0, card);
				pushed = true;
				break;
			}
		}
		if (!pushed)
			this._data.push(card);
		this.length++;
	}
}

Game_Cards.prototype.splice = function (index, amount)
{
	var card = this._data[index];
	this._data.splice(index, amount);
	this.length -= amount;
	return card;
};

Game_Cards.prototype.slice = function ()
{
	return this._data.slice();
}

Game_Cards.prototype.card = function (index)
{
	if (index < this._data.length && index >= 0)
		return this._data[index];

	return null;
};

Game_Cards.prototype.indexOf = function (skillId, origin)
{
	for (var i = 0; i < this._data.length; i++)
	{
		var card = this._data[i];
		if (card.id() == skillId)
		{
			if (origin && card.origin() != origin)
				continue;
			return i;
		}
	}

	return -1;
};

Game_Cards.prototype.amountOf = function (skillId)
{
	var amount = 0;

	for (var i = 0; i < this._data.length; i++)
	{
		var card = this._data[i];
		if (card.id() == skillId)
		{
			amount++;
		}
	}

	return amount;
}

Game_Cards.prototype.clear = function ()
{
	this._data = [];
	this.length = 0;
};

Game_Cards.prototype.copy = function (cards)
{
	this._data = [];
	for (var i = 0; i < cards._data.length; i++)
	{
		this._data.push(cards._data[i]);
	}
	this.length = this._data.length;
};

Game_Cards.prototype.shuffle = function ()
{
	Isiah.Util.shuffleArray(this._data);
}



function Sprite_SkillCard()
{
	this.initialize.apply(this, arguments);
};

Sprite_SkillCard.prototype = Object.create(Isiah.Util.spritePrototype.prototype);
Sprite_SkillCard.prototype.constructor = Sprite_SkillCard;

Sprite_SkillCard.prototype.initialize = function (skill, actor)
{
	Isiah.Util.spritePrototype.prototype.initialize.call(this);
	this._actor = actor;
	this.bitmap = new Bitmap(1, 1);
	this.addHighlights();
	this.initMembers();
	
	this.setSkill(skill);
	this.contents = this.bitmap;
	this.updateBitmap();
};

Sprite_SkillCard.prototype.setSkill = function (skill)
{
	this._skill = skill;
};

Sprite_SkillCard.prototype.initMembers = function ()
{
	this.anchor.x = 0.5;
	this.anchor.y = 0.5;
	this._skill = null;
	this._skillId = null;
	this._iconIndex = null;
	this._skillname = null;
	this.x = Isiah.CGC.coordinates.deckX;
	this.y = Isiah.CGC.coordinates.deckY;
	this.drawType = 'none';
	this.loadCardBack();
};

Sprite_SkillCard.prototype.shrinkToDeck = function ()
{
	var coords = Isiah.CGC.coordinates;
	var targetAngle = coords.deckDegrees * Math.PI / 180;
	this.rotation = targetAngle;
	this.scale.x = coords.deckScale;
	this.scale.y = coords.deckScale;
	this.x = Isiah.CGC.coordinates.deckX;
	this.y = Isiah.CGC.coordinates.deckY;
}

Sprite_SkillCard.prototype.spawnIn = function ()
{
	var coords = Isiah.CGC.coordinates;
	this.scale.x = 0.01;
	this.scale.y = 0.01;
	this.x = Graphics.boxWidth / 2;
	this.y = 0;
/*	this.x = Isiah.CGC.coordinates.deckX;
	this.y = Isiah.CGC.coordinates.deckY;*/
}

Sprite_SkillCard.prototype.update = function ()
{
	Isiah.Util.spritePrototype.prototype.update.call(this);
	this.updateBitmap();
};

Sprite_SkillCard.prototype.updateBitmap = function ()
{
	if (this.isImageChanged())
	{
		this._skillId = this._skill.id;
		this._iconIndex = this._skill.iconIndex;
		this._skillname = this._skill.name;
		
		this.updateCardBack();
		this.updateArt();

		this.drawCardBitmap();
	}
};

Sprite_SkillCard.prototype.isImageChanged = function ()
{
	return (this._skillId !== this._skill.id ||
		this._iconIndex !== this._skill.iconIndex ||
		this._skillname !== this._skill.name ||
		this.bitmap.width === 0 || this._unfinishedLoading === true);
};

Sprite_SkillCard.prototype.loadCardBack = function ()
{
	this._cardback = ImageManager.loadBitmap("img/system/", Isiah.CGC.images.card, 0, true);
};

Sprite_SkillCard.prototype.updateCardBack = function()
{
	var cardDesign = $dataSkills[this._skillId]._cardBase;

	if(cardDesign)
	{
		var back = ImageManager.loadBitmap("img/" + Isiah.CGC.cardDesignDirectory + "/", cardDesign);
		this._cardback = back;
	}
	else
	{
	    this._cardback = ImageManager.loadBitmap("img/system/", Isiah.CGC.images.card, 0, true);
	}
	
	return true;
};

Sprite_SkillCard.prototype.updateArt = function ()
{
	var cardArt = $dataSkills[this._skillId]._cardArt;
	if (cardArt)
	{
		var art = ImageManager.loadBitmap("img/" + Isiah.CGC.cardDirectory + "/", cardArt);
		this._cardArt = art;
	}
	else
		this._cardArt = "icon";
}

Sprite_SkillCard.prototype.addHighlights = function ()
{
	var images = Isiah.CGC.images;
	var enabledBitmap = ImageManager.loadBitmap("img/system/", images.cardEnabledImage);
	var discardBitmap = ImageManager.loadBitmap("img/system/", images.cardDiscardImage);
	this._enabledSprite = new Sprite(enabledBitmap);
	this._discardSprite = new Sprite(discardBitmap);
	this._enabledSprite.anchor.x = 0.5;
	this._enabledSprite.anchor.y = 0.5;
	this._enabledSprite.smooth = true;
	this.addChild(this._enabledSprite);
	this._discardSprite.anchor.x = 0.5;
	this._discardSprite.anchor.y = 0.5;
	this._discardSprite.smooth = true;
	this.addChild(this._discardSprite);
	this._enabledSprite.opacity = 0;
	this._discardSprite.opacity = 0;

	this._enabledSprite.hide = function ()
	{
		this._hide = true;
	};
	this._enabledSprite.show = function ()
	{
		this._hide = false;
	}
	this._enabledSprite.update = function ()
	{
		Sprite.prototype.update.call(this);
		if (this._hide)
		{
			this.opacity -= 10;
			if (this.opacity < 0)
				this.opacity = 0;
		}
		else
		{
			this.opacity += 10;
			if (this.opacity > 255)
				this.opacity = 255;
		}
	}

	this._discardSprite.hide = function ()
	{
		this._hide = true;
	};
	this._discardSprite.show = function ()
	{
		this._hide = false;
	}
	this._discardSprite.update = function ()
	{
		Sprite.prototype.update.call(this);
		if (this._hide)
		{
			this.opacity -= 10;
			if (this.opacity < 0)
				this.opacity = 0;
		}
		else
		{
			this.opacity += 10;
			if (this.opacity > 255)
				this.opacity = 255;
		}
	}

	this._enabledSprite.hide();
	this._discardSprite.hide();
}

Sprite_SkillCard.prototype.drawCardBitmap = function ()
{
	//this.__drawing = this.__drawing + 1 || 0;
	var bitmap = this._cardback;
	if (!bitmap.isReady() || bitmap.width == 0)
	{
		setTimeout(() =>
		{
			this.drawCardBitmap();
		}, 100);
		return;
	}

	var width = bitmap.width;
	var height = bitmap.height;
	this.bitmap = new Bitmap(width, height);
	this.contents = this.bitmap;
	this.bitmap.smooth = true;
	this.bitmap.blt(bitmap, 0, 0, width, height, 0, 0, width, height);

	//this.bitmap.textColor = "white";


	var success = this.drawCardArt();
	if (!success)
	{
		setTimeout(() =>
		{
			this.drawCardBitmap();
		}, 100);
		return;
	}

	this.drawCardName();
	this.drawCardCost();

	this.drawCardDescription();
	this.drawCardType();

	this.drawType = 'none';
	if (this._amount === 0)
	{

		this.shadeCard();
	}
	else if (this._amountText)
	{
		this.drawAmount();
	}
		

	//this._unfinishedLoading = false;
};

Sprite_SkillCard.prototype.drawAmount = function ()
{
	var b = this._amountText.bitmap;
	b.clear();
	b.smooth = true;
	//b.fillRect(0, 0, 1, b.height, 'white');
	//b.fillRect(b.width - 1, 0, 1, b.height, 'white');
	b.drawText("x" + this._amount, 0, 0, b.width, b.height, 'center');
	//this._amountText.y = this.bitmap.height / 2;
	//this._amountText.x = -(b.width / 2);
	//this._amountText.x = this.bitmap.width / 2;
	//this._amountText.anchor = new Point(0.5, 0);
}

Sprite_SkillCard.prototype.drawCardArt = function ()
{
	var cardArt = this._cardArt;
	if (cardArt != "icon")
	{
		if (!cardArt.isReady())
		{
			//this._unfinishedLoading = true;
			setTimeout(() =>
			{
				this.drawCardArt();
			}, 100);
			return false;
		}
		this.bitmap.blt(cardArt, 0, 0, cardArt.width, cardArt.height, 0, 0);
	}
	else
	{
		this.drawIconScaled(this._iconIndex, 4, 22, this.bitmap.width - 8, this.bitmap.width - 8);
	}
		

	return true;
};

Sprite_SkillCard.prototype.drawCardName = function ()
{
	this.drawType = 'name';
	var coords = Isiah.CGC.coordinates;
	this.drawTextEx(this._skillname, coords.cardNameX, coords.cardNameY);
};

Sprite_SkillCard.prototype.drawCardCost = function ()
{
	var coords = Isiah.CGC.coordinates;
	var skillWidth = this.bitmap.width - 8;
	if (Imported.YEP_SkillCore)
		skillWidth += (Window_Base._iconWidth - Isiah.CGC.fontSizes.iconSize);
	this.drawSkillCost(this._skill, 0, coords.skillCostY, skillWidth - coords.skillCostX);
};

Sprite_SkillCard.prototype.drawCardDescription = function ()
{
	var coords = Isiah.CGC.coordinates;
	if (coords.displayCardDesc)
	{
		this.drawType = 'desc';
		var desc = this._skill.description;
		if (Imported.YEP_MessageCore)
			desc = "<WordWrap>" + desc;
		this.drawTextEx(desc, coords.cardDescX, coords.cardDescY);
	}
};

Sprite_SkillCard.prototype.drawCardType = function ()
{
	//To be overridded in IsiahCGCCardTypes
}

Sprite_SkillCard.prototype.shadeCard = function ()
{
	var shadowBitmap = new Bitmap(this.bitmap.width, this.bitmap.height);
	shadowBitmap.paintOpacity = 220;
	shadowBitmap.fillAll('black');
	shadowBitmap.paintOpacity = 255;
	var shadeSprite = new Sprite(shadowBitmap);
	shadeSprite.anchor = new Point(0.5, 0.5);
	this._shadeSprite = shadeSprite;
	this.addChild(shadeSprite);
};

Sprite_SkillCard.prototype.unshadeCard = function ()
{
	if (this._shadeSprite)
	{
		this.removeChild(this._shadeSprite);
		this._shadeSprite = null;
	}
}

//=====================================================================
// Mimick Window_Base text drawing behavior
//======================================================================

//#region Mimick Window_Base text drawing behavior

Sprite_SkillCard.prototype.drawTextEx = function (text, x, y)
{
	return Window_Base.prototype.drawTextEx.call(this, text, x, y);
};

Sprite_SkillCard.prototype.drawText = function (text, x, y, maxWidth, align)
{
	return Window_Base.prototype.drawText.call(this, text, x, y, maxWidth, align);
}

Sprite_SkillCard.prototype.lineHeight = function ()
{
	return Isiah.CGC.fontSizes.cardDesc;
}

Sprite_SkillCard.prototype.convertEscapeCharacters = function (text)
{
	return Window_Base.prototype.convertEscapeCharacters.call(this, text);
};

Sprite_SkillCard.prototype.calcTextHeight = function (textState, all)
{
	if (Isiah.Util.usingMZ)
	{
		const lineSpacing = this.lineHeight() / 2;
		const lastFontSize = this.contents.fontSize;
		const lines = textState.text.slice(textState.index).split("\n");
		const textHeight = this.maxFontSizeInLine(lines[0]) + lineSpacing;
		this.contents.fontSize = lastFontSize;
		return textHeight;
	}
	else
		return Window_Base.prototype.calcTextHeight.call(this, textState, all);
};

Sprite_SkillCard.prototype.resetFontSettings = function ()
{
	Window_Base.prototype.resetFontSettings.call(this);
	if (this.drawType == 'name')
	{
		this.contents.fontSize = Isiah.CGC.fontSizes.cardName;
	}
	else if (this.drawType == 'desc')
	{
		this.contents.fontSize = Isiah.CGC.fontSizes.cardDesc;
	}
	else
	{
		this.contents.fontSize = this.standardFontSize();
	}
};

Sprite_SkillCard.prototype.actorName = function (n)
{
	return Window_Base.prototype.actorName.call(this, n);
};

Sprite_SkillCard.prototype.partyMemberName = function (n)
{
	return Window_Base.prototype.partyMemberName.call(this, n);
};

Sprite_SkillCard.prototype.standardFontFace = function ()
{
	return Window_Base.prototype.standardFontFace.call(this);
};

Sprite_SkillCard.prototype.standardFontSize = function ()
{
	//return Window_Base.prototype.standardFontSize.call(this);
	return Isiah.CGC.fontSizes.cardDesc;
};

Sprite_SkillCard.prototype.resetTextColor = function ()
{
	return Window_Base.prototype.resetTextColor.call(this);
};

if (Isiah.Util.usingMZ)
{
	Sprite_SkillCard.prototype.createTextState = function (text, x, y, width)
	{
		return Window_Base.prototype.createTextState.call(this, text, x, y, width);
	}

	Sprite_SkillCard.prototype.changeOutlineColor = function (color)
	{
		Window_Base.prototype.changeOutlineColor.call(this, color);
	}

	Sprite_SkillCard.prototype.maxFontSizeInLine = function (line)
	{
		return Window_Base.prototype.maxFontSizeInLine.call(this, line);
	}
	
	Sprite_SkillCard.prototype.createTextBuffer = function (rtl)
	{
		return Window_Base.prototype.createTextBuffer.call(this, rtl);
	}
	
	Sprite_SkillCard.prototype.processAllText = function (textState)
	{
		return Window_Base.prototype.processAllText.call(this, textState);
	}
	
	Sprite_SkillCard.prototype.flushTextState = function (textState)
	{
		return Window_Base.prototype.flushTextState.call(this, textState);
	}
	
	Sprite_SkillCard.prototype.processControlCharacter = function (textState, c)
	{
		return Window_Base.prototype.processControlCharacter.call(this, textState, c);
	}

	Isiah.CGC.Window_BattleStatus_isOpenAndActive = Window_BattleSkill.prototype.isOpenAndActive;
	Window_BattleSkill.prototype.isOpenAndActive = function ()
	{
		if ($gameSystem._cardBattleEnabled)
			return this.isOpen() && this.active;
		else
			return Isiah.CGC.Window_BattleStatus_isOpenAndActive.call(this);
	};

	Isiah.CGC.Window_BattleStatus_maxCols = Window_BattleStatus.prototype.maxCols;
	Window_BattleStatus.prototype.maxCols = function ()
	{
		if ($gameSystem._cardBattleEnabled)
		{
			var actors = $gameParty.allMembers().slice(0, $gameParty.maxBattleMembers());
			return actors.length;
		}
		else
			return Isiah.CGC.Window_BattleStatus_maxCols.call(this);
		
	}

	Isiah.CGC.Scene_Battle_needsInputWindowChange = Scene_Battle.prototype.needsInputWindowChange;
	Scene_Battle.prototype.needsInputWindowChange = function ()
	{
		if (!$gameSystem._cardBattleEnabled)
		{
			return Isiah.CGC.Scene_Battle_needsInputWindowChange.call(this);
		}
		const windowActive = this.isAnyInputWindowActive();
		const inputting = BattleManager.isInputting();
		const inputPhase = BattleManager._phase == 'input';

		if (!inputPhase) return false;
		
		if (windowActive && inputting)
		{
			if (this._actorCommandWindow.actor() !== BattleManager.actor())
			{
				this._actorCommandWindow._actor = BattleManager.actor();
				return true;
			}
			else
				return false;
		}
		return windowActive !== inputting;
	};


	Isiah.CGC.Scene_Battle_statusWindowRect = Scene_Battle.prototype.statusWindowRect;
	Scene_Battle.prototype.statusWindowRect = function ()
	{
		if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
		{
			return Isiah.CGC.Scene_Battle_statusWindowRect.call(this);
		}
		const extra = 10;
		var ww = Graphics.boxWidth - 192;
		ww /= (5 - Window_BattleStatus.prototype.maxCols());
		const wh = this.windowAreaHeight() + extra;
		const wx = this.isRightInputMode() ? 0 : Graphics.boxWidth - ww;
		const wy = Graphics.boxHeight - wh + extra - 4;
		return new Rectangle(wx, wy, ww, wh);
	};

	Isiah.CGC.Scene_Battle_onActorCancel = Scene_Battle.prototype.onActorCancel
	Scene_Battle.prototype.onActorCancel = function ()
	{
		Isiah.CGC.Scene_Battle_onActorCancel.call(this);
		if ($gameSystem._cardBattleEnabled)
		{
			this._statusWindow.show();
			this._skillWindow.activate();
		}

	};



	Scene_Battle.prototype.hideSubInputWindows = function ()
	{
		this._actorWindow.deactivate();
		this._enemyWindow.deactivate();
		//this._skillWindow.deactivate();
		this._itemWindow.deactivate();
		this._actorWindow.hide();
		this._enemyWindow.hide();
		//this._skillWindow.hide();
		this._itemWindow.hide();
	};

	Isiah.CGC.Scene_Battle_startEnemySelection = Scene_Battle.prototype.startEnemySelection;
	Scene_Battle.prototype.startEnemySelection = function ()
	{
		Isiah.CGC.Scene_Battle_startEnemySelection.call(this);
		if ($gameSystem._cardBattleEnabled)
			this._statusWindow.show();
	}
}




Sprite_SkillCard.prototype.changeTextColor = function (color)
{
	return Window_Base.prototype.changeTextColor.call(this, color);
};

Sprite_SkillCard.prototype.normalColor = function ()
{
	return Window_Base.prototype.normalColor.call(this);
};

Sprite_SkillCard.prototype.mpCostColor = function ()
{
	return Window_Base.prototype.mpCostColor.call(this);
};

Sprite_SkillCard.prototype.textColor = function (n)
{
	var skillWindow = new Window_SkillList();
	return skillWindow.textColor(n);
};

Sprite_SkillCard.prototype.tpCostColor = function ()
{
	return Window_Base.prototype.tpCostColor.call(this);
};

Sprite_SkillCard.prototype.processCharacter = function (textState)
{
	return Window_Base.prototype.processCharacter.call(this, textState);
};

Sprite_SkillCard.prototype.processNewLine = function (textState)
{
	return Window_Base.prototype.processNewLine.call(this, textState);
};

Sprite_SkillCard.prototype.processNewPage = function (textState)
{
	return Window_Base.prototype.processNewPage.call(this, textState);
};

Sprite_SkillCard.prototype.processNormalCharacter = function (textState)
{
	return Window_Base.prototype.processNormalCharacter.call(this, textState);
};

Sprite_SkillCard.prototype.obtainEscapeCode = function (textState)
{
	return Window_Base.prototype.obtainEscapeCode.call(this, textState);
};

Sprite_SkillCard.prototype.obtainEscapeParam = function (textState)
{
	return Window_Base.prototype.obtainEscapeParam.call(this, textState);
};

Sprite_SkillCard.prototype.processEscapeCharacter = function (code, textState)
{
	return Window_Base.prototype.processEscapeCharacter.call(this, code, textState);
};

Sprite_SkillCard.prototype.textWidth = function (text)
{
	return Window_Base.prototype.textWidth.call(this, text);
};

Sprite_SkillCard.prototype.processDrawIcon = function (iconIndex, textState)
{
	var coords = Isiah.CGC.coordinates;
	this.drawIcon(iconIndex, textState.x + 2, textState.y + 2 + coords.cardDescIconY);
	textState.x += Isiah.CGC.fontSizes.iconSize + 4;
};

Sprite_SkillCard.prototype.makeFontBigger = function ()
{
	if (this.contents.fontSize <= 96)
	{
		this.contents.fontSize += 4;
	}
};

Sprite_SkillCard.prototype.makeFontSmaller = function ()
{
	if (this.contents.fontSize >= 8)
	{
		this.contents.fontSize -= 4;
	}
};

Sprite_SkillCard.prototype.textPadding = function ()
{
	return 0;//Isiah.CGC.coordinates.cardDescX;//Window_Base.prototype.textPadding.call(this);
};

Sprite_SkillCard.prototype.newLineX = function ()
{
	return Window_Base.prototype.newLineX.call(this);
};

Sprite_SkillCard.prototype.contentsWidth = function ()
{
	return Window_Base.prototype.contentsWidth.call(this);
};

Sprite_SkillCard.prototype.standardPadding = function ()
{
	return 0;
};

//#endregion

//============================================================================
// YEP_MessageCore compatibility
//============================================================================

//#region YEP_MessageCore compatibility

if (Imported.YEP_MessageCore)
{
	Sprite_SkillCard.prototype.textWidthEx = function (text)
	{
		return Window_Base.prototype.textWidthEx.call(this, text);
	};

	Sprite_SkillCard.prototype.setWordWrap = function (text)
	{
		return Window_Base.prototype.setWordWrap.call(this, text);
	};

	Sprite_SkillCard.prototype.convertExtraEscapeCharacters = function (text)
	{
		return Window_Base.prototype.convertExtraEscapeCharacters.call(this, text);
	};

	Sprite_SkillCard.prototype.actorNickname = function (n)
	{
		return Window_Base.prototype.actorNickname.call(this, n);
	};

	Sprite_SkillCard.prototype.partyClassName = function (n)
	{
		return Window_Base.prototype.partyClassName.call(this, n);
	};

	Sprite_SkillCard.prototype.partyNickname = function (n)
	{
		return Window_Base.prototype.partyNickname.call(this, n);
	};

	Sprite_SkillCard.prototype.escapeIconItem = function (n, database)
	{
		return Window_Base.prototype.escapeIconItem.call(this, n, database);
	};

	Sprite_SkillCard.prototype.obtainEscapeString = function (textState)
	{
		return Window_Base.prototype.obtainEscapeString.call(this, textState);
	};

	Sprite_SkillCard.prototype.checkWordWrap = function (textState)
	{
		return Window_Base.prototype.checkWordWrap.call(this, textState);
	};

	Sprite_SkillCard.prototype.wordwrapWidth = function ()
	{
		if (this.drawType == 'desc' && Isiah.CGC.coordinates.cardDescWidth != 0)
			return Isiah.CGC.coordinates.cardDescWidth;
		else
			return Window_Base.prototype.wordwrapWidth.call(this);
	};

	Sprite_SkillCard.prototype.saveCurrentWindowSettings = function ()
	{
		return Window_Base.prototype.saveCurrentWindowSettings.call(this);
	};

	Sprite_SkillCard.prototype.restoreCurrentWindowSettings = function ()
	{
		return Window_Base.prototype.restoreCurrentWindowSettings.call(this);
	};

	Sprite_SkillCard.prototype.clearCurrentWindowSettings = function ()
	{
		return Window_Base.prototype.clearCurrentWindowSettings.call(this);
	};

	Sprite_SkillCard.prototype.textWidthExCheck = function (text)
	{
		return Window_Base.prototype.textWidthExCheck.call(this, text);
	};
}

//#endregion

//============================================================================
// YEP_X_ExtMesPack1 compatibility
//============================================================================

if (Imported.YEP_X_ExtMesPack1)
{
	Sprite_SkillCard.prototype.convertPlaytime = function (text)
	{
		return Window_Base.prototype.convertPlaytime.call(this, text);
	};

	Sprite_SkillCard.prototype.convertMapName = function (text)
	{
		return Window_Base.prototype.convertMapName.call(this, text);
	};

	Sprite_SkillCard.prototype.convertEnemyName = function (text)
	{
		return Window_Base.prototype.convertEnemyName.call(this, text);
	};

	Sprite_SkillCard.prototype.convertDigitGrouping = function (text)
	{
		return Window_Base.prototype.convertDigitGrouping.call(this, text);
	};

	Sprite_SkillCard.prototype.groupDigits = function (number)
	{
		return Window_Base.prototype.groupDigits.call(this, number);
	};

	Sprite_SkillCard.prototype.obtainColorString = function (textState)
	{
		return Window_Base.prototype.obtainColorString.call(this, textState);
	};
}

//============================================================================
// YEP_X_ExtMesPack2 compatibility
//============================================================================

if (Imported.YEP_X_ExtMesPack2)
{
	Sprite_SkillCard.prototype.convertItemQuantitiesCodes = function (text)
	{
		return Window_Base.prototype.convertItemQuantitiesCodes.call(this, text);
	};

	Sprite_SkillCard.prototype.convertActorParameterCodes = function (text)
	{
		return Window_Base.prototype.convertActorParameterCodes.call(this, text);
	};

	Sprite_SkillCard.prototype.convertEnemyParameterCodes = function (text)
	{
		return Window_Base.prototype.convertEnemyParameterCodes.call(this, text);
	};

	Sprite_SkillCard.prototype.convertColorCompare = function (text)
	{
		return Window_Base.prototype.convertColorCompare.call(this, text);
	};

	Sprite_SkillCard.prototype.convertCaseText = function (text)
	{
		return Window_Base.prototype.convertCaseText.call(this, text);
	};
}


//============================================================================
// Irina_AutoMessageColor compatibility
//============================================================================

if (Imported.Irina_AutoMessageColor)
{
	Sprite_SkillCard.prototype.convertAutomaticMessageColors = function (e)
	{
		return Window_Base.prototype.convertAutomaticMessageColors.call(this, e);
	};

	Sprite_SkillCard.prototype.convertMvBaseTextCodes = function (e)
	{
		return Window_Base.prototype.convertMvBaseTextCodes.call(this, e);
	};

	Sprite_SkillCard.prototype.convertYepMessageCoreTextCodes = function (e)
	{
		return Window_Base.prototype.convertYepMessageCoreTextCodes.call(this, e);
	};

	Sprite_SkillCard.prototype.convertYepExtMessagePack1TextCodes = function (e)
	{
		return Window_Base.prototype.convertYepExtMessagePack1TextCodes.call(this, e);
	};

	Sprite_SkillCard.prototype.revertTextColor = function ()
	{
		return Window_Base.prototype.revertTextColor.call(this);
	};
}


//============================================================================
// RS_MessageAlign compatibility
//============================================================================

if (Imported.RS_MessageAlign)
{
	Sprite_SkillCard.prototype.doFirstLineAlign = function (textState)
	{
		return Window_Base.prototype.doFirstLineAlign.call(this, textState);
	};

	Sprite_SkillCard.prototype.processAlign = function (textState)
	{
		return Window_Base.prototype.processAlign.call(this, textState);
	};

	Sprite_SkillCard.prototype.setAlignLeft = function (textState)
	{
		return Window_Base.prototype.setAlignLeft.call(this, textState);
	};

	Sprite_SkillCard.prototype.setAlignCenter = function (textState)
	{
		return Window_Base.prototype.setAlignCenter.call(this, textState);
	};

	Sprite_SkillCard.prototype.setAlignRight = function (textState)
	{
		return Window_Base.prototype.setAlignRight.call(this, textState);
	};

	Sprite_SkillCard.prototype.calcTextWidth = function (text)
	{
		return Window_Base.prototype.calcTextWidth.call(this, text);
	};

	Sprite_SkillCard.prototype.drawTextExForAlign = function (text, x, y)
	{
		return Window_Base.prototype.drawTextExForAlign.call(this, text, x, y);
	};

	Sprite_SkillCard.prototype.isUsedTextWidthEx = function ()
	{
		return Window_Base.prototype.isUsedTextWidthEx.call(this);
	};

	Sprite_SkillCard.prototype.saveFontSettings = function ()
	{
		return Window_Base.prototype.saveFontSettings.call(this);
	};

	Sprite_SkillCard.prototype.restoreFontSettings = function ()
	{
		return Window_Base.prototype.restoreFontSettings.call(this);
	};




}

//============================================================================
// Eli_MessageActions compatibility
//============================================================================

if (Imported.Eli_MessageActions)
{
	Eli.MessageActions.alias.Sprite_SkillCard_initialize = Sprite_SkillCard.prototype.initialize;
	Sprite_SkillCard.prototype.initialize = function (skill, actor)
	{
		if (!Isiah.Util.usingMZ)
			this.initExtraEscapeCodes();
		this.setDefaultTextAlignment();
		Eli.MessageActions.alias.Sprite_SkillCard_initialize.call(this, skill, actor);

	}
	Sprite_SkillCard.prototype.initExtraEscapeCodes = function ()
	{
		return Window_Base.prototype.initExtraEscapeCodes.call(this);
	};

	Sprite_SkillCard.prototype.setDefaultTextAlignment = function ()
	{
		return Window_Base.prototype.setDefaultTextAlignment.call(this);
	};

	Sprite_SkillCard.prototype.changeDefaultFont = function (textState)
	{
		return Window_Base.prototype.changeDefaultFont.call(this, textState);
	};

	Sprite_SkillCard.prototype.changeBitmapFont = function (textState)
	{
		return Window_Base.prototype.changeBitmapFont.call(this, textState);
	};

	Sprite_SkillCard.prototype.fixAlign = function (textState)
	{
		return Window_Base.prototype.fixAlign.call(this, textState);
	};

	if (Isiah.Util.usingMZ)
	{
		Sprite_SkillCard.prototype.actionCode_OUTCOLOR = function (textState)
		{
			return Window_Base.prototype.actionCode_OUTCOLOR.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_ALIGN = function (textState, defaultAlign)
		{
			return Window_Base.prototype.actionCode_ALIGN.call(this, textState, defaultAlign);
		};

		Sprite_SkillCard.prototype.getWidthsMeasureForAlign = function (textState)
		{
			return Window_Base.prototype.getWidthsMeasureForAlign.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_TEXTBACKGROUND = function (textState)
		{
			return Window_Base.prototype.actionCode_TEXTBACKGROUND.call(this, textState);
		};

		Sprite_SkillCard.prototype.removeActionEscapeCharacters = function (code, textState)
		{
			return Window_Base.prototype.removeActionEscapeCharacters.call(this, code, textState);
		};

		Sprite_SkillCard.prototype.actionCode_COLOR = function (textState)
		{
			return Window_Base.prototype.actionCode_COLOR.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_CHANGESWITCH = function (textState)
		{
			return Window_Base.prototype.actionCode_CHANGESWITCH.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_CHANGESELFSWITCH = function (textState)
		{
			return Window_Base.prototype.actionCode_CHANGESELFSWITCH.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_CHANGEVARIABLE = function (textState)
		{
			return Window_Base.prototype.actionCode_CHANGEVARIABLE.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_PBGM = function (textState)
		{
			return Window_Base.prototype.actionCode_PBGM.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_FOBGM = function (textState)
		{
			return Window_Base.prototype.actionCode_FOBGM.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_PBGS = function (textState)
		{
			return Window_Base.prototype.actionCode_PBGS.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_FOBGS = function (textState)
		{
			return Window_Base.prototype.actionCode_FOBGS.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_PME = function (textState)
		{
			return Window_Base.prototype.actionCode_PME.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_PSE = function (textState)
		{
			return Window_Base.prototype.actionCode_PSE.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_FORMULA = function (textState)
		{
			return Window_Base.prototype.actionCode_FORMULA.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_BOLD = function (textState)
		{
			return Window_Base.prototype.actionCode_BOLD.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_ITALIC = function (textState)
		{
			return Window_Base.prototype.actionCode_ITALIC.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_OUTWIDTH = function (textState)
		{
			return Window_Base.prototype.actionCode_OUTWIDTH.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_IMAGE = function (textState)
		{
			return Window_Base.prototype.actionCode_IMAGE.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_UNDERLINE = function (textState)
		{
			return Window_Base.prototype.actionCode_UNDERLINE.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_STRIKE = function (textState)
		{
			return Window_Base.prototype.actionCode_STRIKE.call(this, textState);
		};

		Sprite_SkillCard.prototype.actionCode_CHANGEFONT = function (textState)
		{
			return Window_Base.prototype.actionCode_CHANGEFONT.call(this, textState);
		};
	}
	else
	{
		Sprite_SkillCard.prototype.COLOR = function (textState)
		{
			return Window_Base.prototype.COLOR.call(this, textState);
		};

		Sprite_SkillCard.prototype.CSW = function (textState)
		{
			return Window_Base.prototype.CSW.call(this, textState);
		};

		Sprite_SkillCard.prototype.CSSW = function (textState)
		{
			return Window_Base.prototype.CSSW.call(this, textState);
		};

		Sprite_SkillCard.prototype.CVAR = function (textState)
		{
			return Window_Base.prototype.CVAR.call(this, textState);
		};

		Sprite_SkillCard.prototype.PBGM = function (textState)
		{
			return Window_Base.prototype.PBGM.call(this, textState);
		};

		Sprite_SkillCard.prototype.FBGM = function (textState)
		{
			return Window_Base.prototype.FBGM.call(this, textState);
		};

		Sprite_SkillCard.prototype.PBGS = function (textState)
		{
			return Window_Base.prototype.PBGS.call(this, textState);
		};

		Sprite_SkillCard.prototype.FBGS = function (textState)
		{
			return Window_Base.prototype.FBGS.call(this, textState);
		};

		Sprite_SkillCard.prototype.PME = function (textState)
		{
			return Window_Base.prototype.PME.call(this, textState);
		};

		Sprite_SkillCard.prototype.PSE = function (textState)
		{
			return Window_Base.prototype.PSE.call(this, textState);
		};

		Sprite_SkillCard.prototype.SCRIPT = function (textState)
		{
			return Window_Base.prototype.SCRIPT.call(this, textState);
		};

		Sprite_SkillCard.prototype.BOLD = function (textState)
		{
			return Window_Base.prototype.BOLD.call(this, textState);
		};

		Sprite_SkillCard.prototype.ITALIC = function (textState)
		{
			return Window_Base.prototype.ITALIC.call(this, textState);
		};

		Sprite_SkillCard.prototype.OUTWIDTH = function (textState)
		{
			return Window_Base.prototype.OUTWIDTH.call(this, textState);
		};

		Sprite_SkillCard.prototype.ALIGN = function (textState)
		{
			return Window_Base.prototype.ALIGN.call(this, textState);
		};

		Sprite_SkillCard.prototype.DRAWIMG = function (textState)
		{
			return Window_Base.prototype.DRAWIMG.call(this, textState);
		};

		Sprite_SkillCard.prototype.UL = function (textState)
		{
			return Window_Base.prototype.UL.call(this, textState);
		};

		Sprite_SkillCard.prototype.TS = function (textState)
		{
			return Window_Base.prototype.TS.call(this, textState);
		};

		Sprite_SkillCard.prototype.BGC = function (textState)
		{
			return Window_Base.prototype.BGC.call(this, textState);
		};

		Sprite_SkillCard.prototype.FNT = function (textState)
		{
			return Window_Base.prototype.FNT.call(this, textState);
		};

		Sprite_SkillCard.prototype.ALIGN = function (textState, defaultAlign)
		{
			return Window_Base.prototype.ALIGN.call(this, textState, defaultAlign);
		};
	}
	
	

	


	


}

//============================================================================
// Mimick Window_SkillList cost-drawing behavior
//============================================================================

Sprite_SkillCard.prototype.drawSkillCost = function (skill, x, y, width)
{
	return Window_SkillList.prototype.drawSkillCost.call(this, skill, x, y, width);
};

//============================================================================
// YEP_SkillCore compatibility
//============================================================================

if (Imported.YEP_SkillCore)
{
	Sprite_SkillCard.prototype.drawTpCost = function (skill, wx, wy, dw)
	{
		if (this._actor.skillTpCost(skill) <= 0) return dw;

		dw = Window_SkillList.prototype.drawTpCost.call(this, skill, wx, wy, dw);
		dw += (Window_Base._iconWidth - Isiah.CGC.fontSizes.iconSize);
		return dw;
	}

	Sprite_SkillCard.prototype.drawMpCost = function (skill, wx, wy, dw)
	{
		if (this._actor.skillMpCost(skill) <= 0) return dw;

		dw = Window_SkillList.prototype.drawMpCost.call(this, skill, wx, wy, dw);
		dw += (Window_Base._iconWidth - Isiah.CGC.fontSizes.iconSize);
		return dw;
	}

	Sprite_SkillCard.prototype.drawHpCost = function (skill, wx, wy, dw)
	{
		if (this._actor.skillHpCost(skill) <= 0) return dw;
		dw = Window_SkillList.prototype.drawHpCost.call(this, skill, wx, wy, dw);
		dw += (Window_Base._iconWidth - Isiah.CGC.fontSizes.iconSize);
		return dw;
	}

	Sprite_SkillCard.prototype.drawOtherCost = function (skill, wx, wy, dw)
	{
		return Window_SkillList.prototype.drawOtherCost.call(this, skill, wx, wy, dw);
	}

	Sprite_SkillCard.prototype.drawCustomDisplayCost = function (skill, wx, wy, dw)
	{
		return Window_SkillList.prototype.drawCustomDisplayCost.call(this, skill, wx, wy, dw);
	}

	Sprite_SkillCard.prototype.runDisplayEvalCost = function (skill)
	{
		return Window_SkillList.prototype.runDisplayEvalCost.call(this, skill);
	}

}



//============================================================================
// YEP_X_SkillCostItems compatibility
//============================================================================

if (Imported.YEP_X_SkillCostItems)
{
	Sprite_SkillCard.prototype.drawSkillItemCost = function (skill, wx, wy, dw)
	{
		return Window_SkillList.prototype.drawSkillItemCost.call(this, skill, wx, wy, dw);
	}

	Isiah.CGC.drawSkillItemCost = Window_SkillList.prototype.drawSkillItemCost;
	Window_SkillList.prototype.drawSkillItemCost = function (skill, wx, wy, dw)
	{
		if (!skill || skill.buttonName || typeof skill == "string") return dw;
		return Isiah.CGC.drawSkillItemCost.call(this, skill, wx, wy, dw);
	}
}

//============================================================================
// Mimick Window_Selectable touch input
//============================================================================

if (Isiah.Util.usingMZ)
{
	Sprite_SkillCard.prototype.onClick = function ()
	{
		var scene = SceneManager._scene;
		if (scene._skillWindow)
			scene._skillWindow.confirmByCard(this);
		else if (scene._itemWindow)
			scene._itemWindow.confirmByCard(this);
		//SceneManager._scene._skillWindow.confirmByCard(this);
	};

/*	Sprite_Clickable.prototype.hitTest = function (x, y)
	{
		const rect = new Rectangle(
			-this.anchor.x * this.width,
			-this.anchor.y * this.height,
			this.width / 3 * 2,
			this.height
		);
		return rect.contains(x, y);
	};*/

/*	Sprite_SkillCard.prototype.onMouseEnter = function ()
	{
		//SceneManager._scene._skillWindow.selectByCard(this);
		var scene = SceneManager._scene;
		if (scene._skillWindow)
			scene._skillWindow.selectByCard(this);
		else if (scene._itemWindow)
			scene._itemWindow.selectByCard(this);
	};*/

	Sprite_SkillCard.prototype.onMouseEnter = function ()
	{
		//
		this.__mouseEntered = true;
		var scene = SceneManager._scene;
		if (scene._skillWindow)
			scene._skillWindow.hoverCard();
		else if (scene._itemWindow)
			scene._itemWindow.hoverCard();
	};

	Sprite_SkillCard.prototype.onMouseExit = function ()
	{
		//
		this.__mouseEntered = false;
		var scene = SceneManager._scene;
		if (scene._skillWindow)
			scene._skillWindow.hoverCard();
		else if (scene._itemWindow)
			scene._itemWindow.hoverCard();
	};

	Window_SkillList.prototype.hoverCard = function ()
	{
		var currentIndex = -1;
		var isBattle = this.isInBattle();
		var cardSprites = isBattle ? this._cardSprites.getCards() : this._cardSprites;
		//for (var i = 0; i < cardSprites.length; i++)
		for (var i = cardSprites.length - 1; i >= 0; i--)
		{
			if (cardSprites[i].__mouseEntered)
			{
				currentIndex = i + this._itemsBeforeCards;
				break;
			}
		}

		if (currentIndex != -1 && this.isCursorMovable())
		{
			this.select(currentIndex);
		}
	}

	Window_SkillList.prototype.selectByCard = function (card)
	{
		var lastIndex = this.index();
		var currentIndex = -1;
		var isBattle = this.isInBattle();
		var cardSprites = isBattle ? this._cardSprites.getCards() : this._cardSprites;
		for (var i = 0; i < cardSprites.length; i++)
		{
			if (cardSprites[i] == card)
			{
				currentIndex = i + this._itemsBeforeCards;

				break;
			}
		}
		if (currentIndex == -1)
		{
			if (card == 'endTurn')
			{
				currentIndex = this.endTurnIndex();
			}
			else if (card == 'itemMenu')
			{
				currentIndex = this._itemButton._index;
			}
		}
		

		if (currentIndex != -1 && this.isCursorMovable())
		{
			this.select(currentIndex);
		}
	};

	Window_SkillList.prototype.confirmByCard = function (card)
	{
		var lastIndex = this.index();
		var currentIndex = -1;

		var isBattle = this.isInBattle();
		var cardSprites = isBattle ? this._cardSprites.getCards() : this._cardSprites;
		for (var i = 0; i < cardSprites.length; i++)
		{
			if (cardSprites[i] == card)
			{
				currentIndex = i + this._itemsBeforeCards;

				break;
			}
		}

		//if (currentIndex != -1 && lastIndex === currentIndex)
		if (this.active)
		{
			this.processOk();
		}
	}
}
else
{
	Sprite_SkillCard.prototype.isTouchedInsideFrame = function ()
	{
		var x = this.canvasToLocalX(TouchInput.x);
		var y = this.canvasToLocalY(TouchInput.y);
		var radiusX = this.bitmap.width / 2;
		var radiusY = this.bitmap.height / 2;
		return x >= -radiusX && y >= -radiusY && x < radiusX && y < radiusY;
	};

	Sprite_SkillCard.prototype.canvasToLocalX = function (x)
	{
		var node = this;
		while (node)
		{
			x -= node.x;
			node = node.parent;
		}
		return x;
	};

	Sprite_SkillCard.prototype.canvasToLocalY = function (y)
	{
		var node = this;
		while (node)
		{
			y -= node.y;
			node = node.parent;
		}
		return y;
	};
}




//============================================================================
// Sprite_SkillDeck
//============================================================================


function Sprite_DeckTop()
{
	this.initialize.apply(this, arguments);
};

Sprite_DeckTop.prototype = Object.create(Sprite_SkillCard.prototype);
Sprite_DeckTop.prototype.constructor = Sprite_DeckTop;

Sprite_DeckTop.prototype.initialize = function ()
{
	Sprite_SkillCard.prototype.initialize.call(this, -1);
}

Sprite_DeckTop.prototype.initMembers = function ()
{
	Sprite_SkillCard.prototype.initMembers.call(this);
	this._cardsLeft = 0;
	this._oldCardsLeft = -1;
	this.scale.x = 1;
	this.scale.y = 1;
	this.rotation = 0;
}

Sprite_DeckTop.prototype.updateBitmap = function ()
{
	if (this.isImageChanged())
	{
		this._oldCardsLeft = this._cardsLeft;
		this.drawCardBitmap();
	}
};

Sprite_DeckTop.prototype.setCardsLeft = function (cardsLeft)
{
	this._cardsLeft = cardsLeft;
};

Sprite_DeckTop.prototype.isImageChanged = function ()
{
	return (this._cardsLeft != this._oldCardsLeft);
};

Sprite_DeckTop.prototype.drawCardBitmap = function ()
{
	//this.bitmap = new Bitmap(width, height);
	var bitmap = ImageManager.loadBitmap("img/system/", Isiah.CGC.images.cardDeck, 0, true);
	if (!bitmap.isReady())
	{
		setTimeout(() =>
		{
			this.drawCardBitmap();
		}, 100);
		return;
	}
	this.bitmap = new Bitmap(bitmap.width, bitmap.height);
	this.bitmap.blt(bitmap, 0, 0, bitmap.width, bitmap.height, 0, 0, bitmap.width, bitmap.height);
	this.bitmap.smooth = true;

	//this.bitmap.fillAll("black");
	//this.bitmap.blt(Isiah.Util.createOutline(width, height, 2), 0, 0, width, height, 0, 0, width, height);
	this.bitmap.textColor = "white";
	var coords = Isiah.CGC.coordinates;
	this.bitmap.fontSize = Isiah.CGC.fontSizes.deckNum;
	this.bitmap.drawText(this._cardsLeft, 0, coords.deckNumY, this.bitmap.width - coords.deckNumX, this.bitmap.fontSize, 'right');

	SceneManager._scene.removeCardSprite(this);
	SceneManager._scene.addCardSprite(this);
};

function Sprite_DiscardPile()
{
	this.initialize.apply(this, arguments);
};

Sprite_DiscardPile.prototype = Object.create(Sprite_DeckTop.prototype);
Sprite_DiscardPile.prototype.constructor = Sprite_DiscardPile;

Sprite_DiscardPile.prototype.initialize = function ()
{
	Sprite_DeckTop.prototype.initialize.call(this);
}

Sprite_DiscardPile.prototype.drawCardBitmap = function ()
{
	//this.bitmap = new Bitmap(width, height);

	var bitmap = ImageManager.loadBitmap("img/system/", Isiah.CGC.images.cardDiscard, 0, true);
	if (!bitmap.isReady())
	{
		setTimeout(() =>
		{
			this.drawCardBitmap();
		}, 100);
		return;
	}
	this.bitmap = new Bitmap(bitmap.width, bitmap.height);
	if (Isiah.CGC.showDiscardImage)
		this.bitmap.blt(bitmap, 0, 0, bitmap.width, bitmap.height, 0, 0, bitmap.width, bitmap.height);
	this.bitmap.smooth = true;

	//this.bitmap.fillAll("black");
	//this.bitmap.blt(Isiah.Util.createOutline(width, height, 2), 0, 0, width, height, 0, 0, width, height);
	this.bitmap.textColor = "white";
	var coords = Isiah.CGC.coordinates;
	this.bitmap.fontSize = Isiah.CGC.fontSizes.discardNum;
	this.bitmap.drawText(this._cardsLeft, 0, coords.discardNumY,
		this.bitmap.width - coords.discardNumX, this.bitmap.fontSize, 'right');

	SceneManager._scene.removeCardSprite(this);
	SceneManager._scene.addCardSprite(this);
};



function Sprite_EndTurnButton()
{
	this.initialize.apply(this, arguments);
};



Sprite_EndTurnButton.prototype = Object.create(Isiah.Util.spritePrototype.prototype);
Sprite_EndTurnButton.prototype.constructor = Sprite_EndTurnButton;


Sprite_EndTurnButton.prototype.initialize = function ()
{
	var images = Isiah.CGC.images;
	Isiah.Util.spritePrototype.prototype.initialize.call(this);
	this._endTurnBitmap = ImageManager.loadSystem(images.endTurn);
	this._disabledBitmap = ImageManager.loadSystem(images.endTurnDisabled);
	this._highlightSprite = new Sprite(ImageManager.loadSystem(images.endTurnHighlight));
	this._discardBitmap = ImageManager.loadSystem(images.endTurnDiscard);
	this._discardDisabledBitmap = ImageManager.loadSystem(images.endTurnDiscardDisabled);
	this._textLayer = new Sprite();

	this.anchor.x = 0.5;
	this.anchor.y = 0.5;
	this._highlightSprite.anchor.x = 0.5;
	this._highlightSprite.anchor.y = 0.5;
	this.addChild(this._highlightSprite);
	//this.bitmap = this._disabledBitmap;
};

Sprite_EndTurnButton.prototype.update = function ()
{
	Isiah.Util.spritePrototype.prototype.update.call(this);
	this.updateBitmaps();
};

Sprite_EndTurnButton.prototype.updateBitmaps = function ()
{
	var isEnabled = this.isEnabled() ;
	if (BattleManager._phase == 'discard')
	{
		var discardZone = this._skillWindow._cardsReadyToDiscard.getCards();
		var cardsToDiscard = BattleManager._cardsToDiscard - discardZone.length
		if (cardsToDiscard > 0)
		{
			this.bitmap = this._discardDisabledBitmap;
		}
		else
		{
			this.bitmap = this._discardBitmap;
		}

	}
	else if (isEnabled && BattleManager._phase == 'input')
	{
		this.bitmap = this._endTurnBitmap;
	}
	else if (!isEnabled || BattleManager._phase == 'turn')
	{
		this.bitmap = this._disabledBitmap;
	}

	if (this._skillWindow.index() == this._index && !this._skillWindow.previewOnly)
	{
		this._highlightSprite.visible = true;
	}
	else
		this._highlightSprite.visible = false;
};

Sprite_EndTurnButton.prototype.endTurn = function ()
{
	this.bitmap = this._disabledBitmap;
};

Sprite_EndTurnButton.prototype.setIndex = function (index)
{
	this._index = index;
};

Sprite_EndTurnButton.prototype.isTouchedInsideFrame = function ()
{
	var x = this.canvasToLocalX(TouchInput.x);
	var y = this.canvasToLocalY(TouchInput.y);
	var radiusX = this.bitmap.width / 2;
	var radiusY = this.bitmap.height / 2;
	return x >= -radiusX && y >= -radiusY && x < radiusX && y < radiusY;
};

Sprite_EndTurnButton.prototype.canvasToLocalX = function (x)
{
	var node = this;
	while (node)
	{
		x -= node.x;
		node = node.parent;
	}
	return x;
};

Sprite_EndTurnButton.prototype.canvasToLocalY = function (y)
{
	var node = this;
	while (node)
	{
		y -= node.y;
		node = node.parent;
	}
	return y;
};

Sprite_EndTurnButton.prototype.isEnabled = function ()
{
	try
	{
		var isEnabled = eval(Isiah.CGC.endTurnCondition);
		return isEnabled;
	}
	catch (e)
	{
		var warningMessage = "Error evaluating the End Turn Use Condition:\n" + Isiah.CGC.endTurnCondition + "\n";
		console.warn(warningMessage + e);
		return false;
	}
	
}





function Sprite_CardButton()
{
	this.initialize.apply(this, arguments);
};

Sprite_CardButton.prototype = Object.create(Isiah.Util.spritePrototype.prototype);
Sprite_CardButton.prototype.constructor = Sprite_CardButton;

Sprite_CardButton.prototype.initialize = function (name)
{
	var images = Isiah.CGC.images;
	Isiah.Util.spritePrototype.prototype.initialize.call(this);
	this._defaultBitmap = null;
	this._disabledBitmap = null;
	this._highlightSprite = new Sprite();

	this.anchor.x = 0.5;
	this.anchor.y = 0.5;
	this._highlightSprite.anchor.x = 0.5;
	this._highlightSprite.anchor.y = 0.5;
	this.addChild(this._highlightSprite);
	this.bitmap = this._disabledBitmap;
	this._index = null;
	this._skillId = null;
	this._enabledCondition = "true";
	this._name = name;
};

Sprite_CardButton.prototype.setBitmaps = function (defaultBitmap, disabledBitmap, highlightBitmap)
{
	this._defaultBitmap = ImageManager.loadSystem(defaultBitmap);
	this._disabledBitmap = ImageManager.loadSystem(disabledBitmap);
	this._highlightSprite.bitmap = ImageManager.loadSystem(highlightBitmap);
};

Sprite_CardButton.prototype.setIndex = function(index)
{
	this._index = index;
}

Sprite_CardButton.prototype.setSkill = function(id)
{
	this._skillId = id;
}

Sprite_CardButton.prototype.update = function ()
{
	Isiah.Util.spritePrototype.prototype.update.call(this);
	this.updateBitmaps();
};

Sprite_CardButton.prototype.updateBitmaps = function ()
{
	if (this.disabledDuringNonInpit)
	{
		if (BattleManager._phase == 'discard')
		{
			this.bitmap = this._disabledBitmap;
		}
		else if (BattleManager._phase == 'input')
		{
			var isEnabled = eval(this._enabledCondition);
			if (isEnabled)
				this.bitmap = this._defaultBitmap;
			else
				this.bitmap = this._disabledBitmap;
		}
		else if (BattleManager._phase == 'turn')
		{
			this.bitmap = this._disabledBitmap;
		}
	}
	else
	{
		var isEnabled = eval(this._enabledCondition);
		this.bitmap = isEnabled ? this._defaultBitmap : this._disabledBitmap;
	}

	
	if (this._skillWindow.index() == this._index && !this._skillWindow.previewOnly)
	{
		this._highlightSprite.visible = true;
	}
	else
		this._highlightSprite.visible = false;
};

Sprite_CardButton.prototype.isTouchedInsideFrame = function ()
{
	var x = this.canvasToLocalX(TouchInput.x);
	var y = this.canvasToLocalY(TouchInput.y);
	var radiusX = this.bitmap.width / 2;
	var radiusY = this.bitmap.height / 2;
	return x >= -radiusX && y >= -radiusY && x < radiusX && y < radiusY;
};

Sprite_CardButton.prototype.canvasToLocalX = function (x)
{
	var node = this;
	while (node)
	{
		x -= node.x;
		node = node.parent;
	}
	return x;
};

Sprite_CardButton.prototype.canvasToLocalY = function (y)
{
	var node = this;
	while (node)
	{
		y -= node.y;
		node = node.parent;
	}
	return y;
};

Sprite_CardButton.prototype.skillId = function ()
{
	return this._skillId;
}

Sprite_CardButton.prototype.isEnabled = function ()
{
	return eval(this._enabledCondition);
}

//============================================================================
// MZ Touch Input
//============================================================================

if (Isiah.Util.usingMZ)
{

	Sprite_EndTurnButton.prototype.onClick = function ()
	{
		SceneManager._scene._skillWindow.confirmByCard('endTurn');
	};

	Sprite_EndTurnButton.prototype.onMouseEnter = function ()
	{
		SceneManager._scene._skillWindow.selectByCard('endTurn');
	};

	Sprite_CardButton.prototype.onClick = function ()
	{
		SceneManager._scene._skillWindow.confirmByCard(this._name);
	};

	Sprite_CardButton.prototype.onMouseEnter = function ()
	{
		SceneManager._scene._skillWindow.selectByCard(this._name);
	};
}



function CardZone(actors)
{
	this.cards = [];
	this._actors = actors;
	for (var i = 0; i < actors.length; i++)
	{
		this.cards[actors[i].actorId()] = [];
	}

	this._currentActor = null;

	this.card = function (index, actor)
	{
		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		return this.cards[actor.actorId()][index];
	}

	this.getCards = function (actor)
	{
		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		return this.cards[actor.actorId()];
	}

	//gets cards of all actors except the current one
	this.getOtherCards = function (actor)
	{
		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		var cards = [];
		for (var i = 0; i < this._actors.length; i++)
		{
			if (this._actors[i] == actor) continue;
			cards = cards.concat(this.getCards(this._actors[i]));
		}

		return cards;
	}

	this.getAllCards = function ()
	{
		var cards = [];
		for (var i = 0; i < this._actors.length; i++)
		{
			cards = cards.concat(this.getCards(this._actors[i]));
		}

		return cards;
	}

	this.pushCard = function (sprite, actor)
	{
		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		this.cards[actor.actorId()].push(sprite);
	}

	this.popCard = function (actor, index)
	{
		if (index == undefined)
			index = 0;

		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		var card = this.cards[actor.actorId()][index];
		this.cards[actor.actorId()].splice(index, 1);
		return card;
	}

	this.setActor = function (actor)
	{
		this._currentActor = actor;
	}

	this.clear = function (actor)
	{
		if (!actor)
			actor = this._currentActor;
		if (!actor)
			return -1;

		this.cards[actor.actorId()] = [];
	}

	this.pushActor = function(actor)
	{
		this._actors.push(actor);
		this.cards[actor.actorId()] = [];
	}
}

Isiah.CGC.Window_SkillList_maxCols = Window_SkillList.prototype.maxCols;
Window_SkillList.prototype.maxCols = function ()
{
	if ($gameSystem._cardBattleEnabled)
		return 10;
	else
		return Isiah.CGC.Window_SkillList_maxCols.call(this);
};

Isiah.CGC.Window_BattleSkill_initialize = Window_BattleSkill.prototype.initialize;
Window_BattleSkill.prototype.initialize = function (x, y, width, height)
{
	Isiah.CGC.Window_BattleSkill_initialize.call(this, x, y, width, height);

	if (!$gameSystem._cardBattleEnabled)
		return;

	var actors = $gameParty.allMembers().slice(0, $gameParty.maxBattleMembers());

	this.opacity = 0;
	this.contentsOpacity = 0;

	this._cardSprites = new CardZone(actors);
	this._discardedSprites = new CardZone(actors);
	this._removedSprites = new CardZone(actors);

	this._cardsReadyToDiscard = new CardZone(actors);

	//this one isn't a CardZone, it's transitioning to the deck
	// and is purely cosmetic
	this._resetCardSprites = [];

	this._discardMode = '';

	this._extraButtons = [];
};

Window_BattleSkill.prototype.addActorToZones = function(actor)
{
	this._cardSprites.pushActor(actor);
	this._discardedSprites.pushActor(actor);
	this._removedSprites.pushActor(actor);
	this._cardsReadyToDiscard.pushActor(actor);
}

Window_BattleSkill.prototype.isTouchedInsideFrame = function ()
{
	return true;
};

Isiah.CGC.Window_BattleSkill_show = Window_BattleSkill.prototype.show;
Window_BattleSkill.prototype.show = function ()
{
	if (!$gameSystem._cardBattleEnabled)
		return Isiah.CGC.Window_BattleSkill_show.call(this);

	var cards = this._cardSprites.getCards();
	for (var i = 0; i < cards.length; i++)
	{
		cards[i].show();
	}

	if (Isiah.CGC.showHelpWindow)
	{
		this.showHelpWindow();
	}
};

Isiah.CGC.Window_BattleSkill_hide = Window_BattleSkill.prototype.hide;
Window_BattleSkill.prototype.hide = function ()
{
	Isiah.CGC.Window_BattleSkill_hide.call(this);

};

Window_BattleSkill.prototype.addNewCard = function ()
{
	if (!this._actor) return;

	var deck = this._actor._cardDeck;
	var card = deck.splice(0, 1);
	this._actor._cardHand.add(card);

	var spriteCard = new Sprite_SkillCard($dataSkills[skill.id()], this._actor);
	SceneManager._scene.addCardSprite(spriteCard);
	//this._cardSprites.getCards().push(spriteCard);
	this._cardSprites.pushCard(spriteCard);

	this.makeItemList();
};

Window_BattleSkill.prototype.addCard = function (skillIndex, actor, external)
{
	var spriteCard = new Sprite_SkillCard($dataSkills[skillIndex], actor);
	if (external)
		spriteCard.spawnIn();
	else
		spriteCard.shrinkToDeck();
	SceneManager._scene.addCardSprite(spriteCard);

	//this._cardSprites[actor.actorId()].push(spriteCard);
	this._cardSprites.pushCard(spriteCard, actor);
	this.makeItemList();
};

Window_BattleSkill.prototype.addCardDiscard = function (skillIndex, actor, external)
{
	var spriteCard = new Sprite_SkillCard($dataSkills[skillIndex], actor);
	if (external)
		spriteCard.spawnIn();
	else
		spriteCard.shrinkToDeck();
	SceneManager._scene.addCardSprite(spriteCard);

	//this._cardSprites[actor.actorId()].push(spriteCard);
	this._discardedSprites.pushCard(spriteCard, actor);
	this.makeItemList();
};

Window_BattleSkill.prototype.addCardToZone = function (skillIndex, zone, actor)
{
	if (zone == "hand")
		this.addCard(skillIndex, actor, true);
	if (zone == "discard")
		this.addCardDiscard(skillIndex, actor, true);
}

Window_BattleSkill.prototype.discardCard = function (index)
{
	index -= this._itemsBeforeCards;
	var handCards = this._cardSprites.getCards();
	var cardSprite = handCards[index];
	if (cardSprite)
	{
		cardSprite._enabledSprite.hide();
		cardSprite._discardSprite.hide();
		if (this._discardMode == 'discard' || this._discardMode == '')
		{
			//console.trace();
			handCards.splice(index, 1);
			this._discardedSprites.getCards().push(cardSprite);

			var card = this._actor.exitCard(this._actor._cardHand, index);
			this._actor.enterCard(this._actor._cardDiscard, card);

		}
		else if (this._discardMode == 'remove')
		{
			handCards.splice(index, 1);
			this._removedSprites.getCards().push(cardSprite);
			//Don't want Removal effect to trigger the Exit effect
			var card = this._actor._cardHand.splice(index, 1);
			this._actor.removedCards++;
		}
		else if (this._discardMode == 'return')
		{
			handCards.splice(index, 1);
			this._resetCardSprites.push(cardSprite);

			var card = this._actor.exitCard(this._actor._cardHand, index);
			this._actor.enterCard(this._actor._cardDeck, card);
		}
	}

	this._actor.updateCardVariables();
	this.deselect();
	
	this.makeItemList();
};

Window_BattleSkill.prototype.removeCard = function (index, exitEffect)
{
	if (exitEffect == undefined) exitEffect = true;
	index -= this._itemsBeforeCards;
	var cards = this._cardSprites.getCards();
	var cardSprite = cards[index];
	if (cardSprite)
	{
		cardSprite._enabledSprite.hide();
		cardSprite._discardSprite.hide();
		cards.splice(index, 1);
		this._removedSprites.getCards().push(cardSprite);

		if (exitEffect)
		{
			var skill = this._actor.exitCard(this._actor._cardHand, index);
			this._actor.removedCards++;
		}
	}

	this._actor.updateCardVariables();
	this.deselect();

	this.makeItemList();
}

Window_BattleSkill.prototype.discardAllCards = function ()
{
	var handCards = this._cardSprites.getCards();
	for (var i = handCards.length - 1; i >= 0; i--)
	{
		this.discardCard(i + this._itemsBeforeCards);
	}
}

Isiah.CGC.Window_BattleSkill_update = Window_BattleSkill.prototype.update;
Window_BattleSkill.prototype.update = function ()
{
	Isiah.CGC.Window_BattleSkill_update.call(this);
	if ($gameSystem._cardBattleEnabled)
	{
		this.updateDiscardPosition();
		this.updateRemovedPosition();
		this.updateHandPosition();
		this.updateResetCardPosition();
	}

};

Window_BattleSkill.prototype.getCardX = function (index, cardZone)
{
	var coords = Isiah.CGC.coordinates;
	var centerX = coords.handCenter;
	var card = cardZone[index];
	var totalCards = cardZone.length;

	var compareMaxCards = Math.max(10, 5 + totalCards);
	var spaceBetweenCards = (120 * (1 + (5 - totalCards) / (compareMaxCards)));
	spaceBetweenCards = Math.max(spaceBetweenCards, coords.minCardSeparationW);
	var totalSpace = Math.min(spaceBetweenCards * totalCards, coords.maxHandWidth);
	spaceBetweenCards = totalSpace / totalCards;

	var cardX = (spaceBetweenCards * index) - totalSpace / 2 + centerX + card.width / 2;

	var pos = (index + this._itemsBeforeCards);
	if (pos == this.index() && SceneManager._scene._enemyWindow && SceneManager._scene._enemyWindow.visible)
	{
		var enemy = SceneManager._scene._enemyWindow.enemy();
		if (enemy.isEnemy())
		{
				cardX = enemy._screenX;
		}
		else if (enemy.isSpriteVisible())
		{
			// This will be where we make the card move to the actor sprite
			// as soon as we figure out how to access it.
			// There's a Game_Actor variable stored in `enemy`, but
			// Game_Actors don't have access to Sprite_Actors,
			// so we don't know its x coordinate.
			var spriteset = BattleManager._spriteset;
			var battlerSprites = spriteset.battlerSprites();
			for (var i = 0; i < battlerSprites.length; i++)
			{
				if (battlerSprites[i]._actor == enemy)
				{
					cardX = battlerSprites[i].x;
					break;
				}
			}
		}
	}

	return cardX;
};

Window_BattleSkill.prototype.getCardY = function (index, card, cardX)
{
	var coords = Isiah.CGC.coordinates;
	var centerX = coords.handCenter;

	var cardY = coords.handY;
	var distanceFromCenterY = Math.abs(cardX - centerX) / 10;
	cardY += (distanceFromCenterY * coords.cardHeightMulti);
	var pos = (index + this._itemsBeforeCards);
	if (pos == this.index())
	{
		cardY -= coords.selectedCardYOff;

		if (SceneManager._scene._actorWindow && SceneManager._scene._actorWindow.active)
			cardY -= coords.selectedCardYOff;

		if (SceneManager._scene._enemyWindow && SceneManager._scene._enemyWindow.visible)
		{
			cardY -= coords.selectedCardYOff;
		}
	}

	if (card._readyToDiscard)
		cardY -= coords.discardingCardYOff;

	if (!this.active)
	{
		cardY += Isiah.CGC.coordinates.inactiveCardYOff;
	}

	return cardY;
}

Window_BattleSkill.prototype.updateHandPosition = function ()
{
	var coords = Isiah.CGC.coordinates;
	var centerX = coords.handCenter;

	var cardZone = this._cardSprites.getCards();
	var totalCards = cardZone.length;
	var spaceBetweenCards = (120 * (1 + (5 - totalCards) / 10));
	spaceBetweenCards = Math.max(spaceBetweenCards, coords.minCardSeparationW);
	var totalSpace = Math.min(spaceBetweenCards * totalCards, coords.maxHandWidth);
	spaceBetweenCards = totalSpace / totalCards;

	for (var i = cardZone.length - 1; i >= 0; i--)
	{
		var card = cardZone[i];
		var cardX = this.getCardX(i, cardZone);
		var cardY = this.getCardY(i, card, cardX);

		if (card.x != cardX || card.y != cardY)
		{
			card.x += (cardX - card.x) / 10;
			card.y += (cardY - card.y) / 10;
		}
		var pos = (i + this._itemsBeforeCards);
		var targetAngle = ((cardX - centerX) / 2000) * Isiah.CGC.coordinates.cardRotationMulti;
		if (pos == this.index())
			targetAngle = 0;

		if (card.rotation != targetAngle)
			card.rotation += (targetAngle - card.rotation) / 10;

		var targetScale = 1;
		if (card.scale.x != targetScale)
		{
			card.scale.x += (targetScale - card.scale.x) / 10;
			card.scale.y += (targetScale - card.scale.y) / 10;
		}
	}


	var otherCards = this._cardSprites.getOtherCards();
	for (var i = otherCards.length - 1; i >= 0; i--)
	{
		var card = otherCards[i];
		var cardY = Graphics.boxHeight + card.height + 40;

		if (card.y != cardY)
		{
			card.y += (cardY - card.y) / 10;
		}
	}
}

Window_BattleSkill.prototype.updateDiscardPosition = function ()
{
	var coords = Isiah.CGC.coordinates;
	var discardCards = this._discardedSprites.getCards();
	for (var i = discardCards.length - 1; i >= 0; i--)
	{
		var card = discardCards[i];
		if (card.x != coords.discardX || card.y != coords.discardY)
		{
			card.x += (coords.discardX - card.x) / 10;
			card.y += (coords.discardY - card.y) / 10;
		}

		var targetAngle = coords.discardDegrees * Math.PI / 180;
		if (card.rotation != targetAngle)
			card.rotation += (targetAngle - card.rotation) / 10;

		var targetScale = coords.discardScale;
		if (card.scale.x != targetScale)
		{
			card.scale.x += (targetScale - card.scale.x) / 10;
			card.scale.y += (targetScale - card.scale.y) / 10;
		}
	}
};

Window_BattleSkill.prototype.updateRemovedPosition = function ()
{
	var actors = $gameParty.members();
	for (var index = 0; index < actors.length; index++)
	{
		var removedCards = this._removedSprites.getCards(actors[index]);
		for (var i = removedCards.length - 1; i >= 0; i--)
		{
			var card = removedCards[i];
			var toBeRemoved = false;
			if (Isiah.CGC.removeMode == 'Fade')
			{
				toBeRemoved = this.updateRemoveFadeAnim(card);
			}
			else if (Isiah.CGC.removeMode == 'Burn')
			{
				toBeRemoved = this.updateRemoveBurnAnim(card);
			}

			if (toBeRemoved)
			{
				removedCards.splice(i, 1);
				SceneManager._scene.removeCardSprite(card);
			}
		}
	}
}

Window_BattleSkill.prototype.updateRemoveFadeAnim = function (card)
{
	card.y -= 3;
	card.opacity -= 7;
	if (card.opacity <= 0)
	{
		return true;
	}

	return false;
};

Window_BattleSkill.prototype.updateRemoveBurnAnim = function (card)
{
	SceneManager._scene.removeCardSprite(card);
	SceneManager._scene.addCardSprite(card);
	//card.y -= 1;
	if (card.rotation != 0)
	{
		card.rotation += (-card.rotation) / 10;
	}
	var maxTime = 80;
	if (card.burnTime == undefined)
		card.burnTime = maxTime;
	else
		card.burnTime--;
	//card.burnTime = card.burnTime - 1 || maxTime;
	var bitmapHeight = card.bitmap.height;
	var ratio = 1 - (card.burnTime / maxTime);
	if (ratio < 0)
		ratio = 0;
	var bitmap = new Bitmap(card.bitmap.width, card.bitmap.height);
	bitmap.blt(card.bitmap, 0, 0, bitmap.width, bitmap.height, 0, 0);
	card.bitmap.clearRect(0, bitmapHeight * (1 - ratio), card.bitmap.width, bitmapHeight * ratio);
	card.bitmap.paintOpacity = 190;
	card.bitmap.blt(bitmap, 0, bitmapHeight * (1 - ratio), bitmap.width, bitmapHeight * ratio, 0, bitmapHeight * (1 - ratio));
	card.bitmap.paintOpacity = 255;
	//card.setFrame(0, 0, card.bitmap.width, bitmapHeight / (card.burnTime / maxTime));

	//console.log(card.burnTime);
	if (card.burnTime <= -10)
	{
		return true;
	}

	return false;
};

Window_BattleSkill.prototype.updateResetCardPosition = function ()
{
	this._resetTime--;
	if (this._resetTime <= 0)
	{
		this._resetTime = 10;
		this._resetNum++;
	}
	if (this._resetCardSprites && this._resetCardSprites.length > 0)
	{
		
		var coords = Isiah.CGC.coordinates;
		var i = 0;
		for (i = this._resetCardSprites.length - 1; i >= 0; i--)
		{
			var win = this._resetCardSprites[i];
			if (win.x != coords.deckX || win.y != coords.deckY)
			{
				win.x += (coords.deckX - win.x) / 10;
				win.y += (coords.deckY - win.y) / 10;
			}

			var targetAngle = coords.deckDegrees * Math.PI / 180;
			if (win.rotation != targetAngle)
				win.rotation += (targetAngle - win.rotation) / 10;

			

			var targetScale = Isiah.CGC.coordinates.deckScale;
			if (win.scale.x != targetScale)
			{
				win.scale.x += (targetScale - win.scale.x) / 10;
				win.scale.y += (targetScale - win.scale.y) / 10;
			}

			if (Math.round(win.x) == coords.deckX && Math.round(win.y) == coords.deckY
				&& Math.round(win.rotation) == Math.round(targetAngle)
				&& Math.round(win.scale.x * 100) == Math.round(targetScale * 100))
			{
				this._resetCardSprites.splice(i, 1);
				SceneManager._scene.removeCardSprite(win);
			}

			if (this._resetCardSprites.length - i > this._resetNum) break;
		}

		if (SceneManager._scene._discardSprite)
			SceneManager._scene._discardSprite.setCardsLeft(i + 1);
	}
}

Window_BattleSkill.prototype.reshuffleDeck = function ()
{
	this._resetCardSprites = this._resetCardSprites.concat(this._discardedSprites.getCards());
	this._discardedSprites.clear();

	this._resetNum = 0;
	this._resetTime = 10;
}

Isiah.CGC.Window_BattleSkill_select = Window_BattleSkill.prototype.select;
Window_BattleSkill.prototype.select = function (index)
{

	Isiah.CGC.Window_BattleSkill_select.call(this, index);
	if ($gameSystem._cardBattleEnabled)
		SceneManager._scene.reorderCardSprites(index - this._itemsBeforeCards);
};

Isiah.CGC.Window_BattleSkill_setActor = Window_BattleSkill.prototype.setActor;
Window_BattleSkill.prototype.setActor = function (actor)
{
	var oldActor = this._actor;
	Isiah.CGC.Window_BattleSkill_setActor.call(this, actor);
	if ($gameSystem._cardBattleEnabled)
	{
		if (oldActor != actor)
		{
			this.resetCards();
		}
			
	}
};

Window_BattleSkill.prototype.setDiscardMode = function (mode, type)
{
	var cardZone = this._cardSprites.getCards();
	this._discardMode = mode;
	if (mode != '')
	{
		for (var i = 0; i < cardZone.length; i++)
		{
			var card = cardZone[i];
			card._enabledSprite.hide();
			if (!type)
				card._discardSprite.show();
		}
		if (!!type)
		{
			this._typeToSelect = type;
			this.showDiscardSpritesByType(type);
		}
	}
	else
	{
		this._typeToSelect = null;
		for (var i = 0; i < cardZone.length; i++)
		{
			var card = cardZone[i];
			if (this.isEnabled(this._data[i + this._itemsBeforeCards]))
				card._enabledSprite.show();
			else
				card._enabledSprite.hide();
			card._discardSprite.hide();
		}
	}

};

Window_BattleSkill.prototype.showDiscardSpritesByType = function (type)
{
	//to be overridden in IsiahCGCCardTypes
}

Isiah.CGC.Window_BattleSkill_setHelpWindow = Window_BattleSkill.prototype.setHelpWindowItem;
Window_BattleSkill.prototype.setHelpWindowItem = function (item)
{
	if ($gameSystem._cardBattleEnabled)
	{
		if (item instanceof Game_Card)
		{
			var skill = $dataSkills[item.id()];
			item = skill;
		}

		if (item == 'itemMenu')
		{
			//Isiah.CGC.Window_BattleSkill_setHelpWindow.call(this, null);
			if (this._helpWindow)
				this._helpWindow.setText(Isiah.CGC.itemMenuDescription);
		}
		else if (item == 'endTurn' && this._helpWindow)
		{
			if (this._discardMode == 'discard')
			{
				this._helpWindow.setText
(Isiah.CGC.discardDescription);
			}
			else
			{
				this._helpWindow.setText(Isiah.CGC.endTurnDescription);
			}
		}
		else if (typeof item === "string")
		{
			// This is NOT a long-term solution;
// v1.4.6 solution
		}
		else
		{
			Isiah.CGC.Window_BattleSkill_setHelpWindow.call(this, item);
			
		}
	}
	else
	{
		Isiah.CGC.Window_BattleSkill_setHelpWindow.call(this, item);
	}
}

Window_BattleSkill.prototype.readyDiscard = function (index)
{
	if (index < this._itemsBeforeCards)
		return;
	if (index >= this._itemsBeforeCards + this._cardSprites.getCards().length)
		return;

	var doesCondtain = false;
	index -= this._itemsBeforeCards;
	var cardsToDiscard = this._cardsReadyToDiscard.getCards();

	for (var i = cardsToDiscard.length - 1; i >= 0; i--)
	{
		if (cardsToDiscard[i] == index)
		{
			doesCondtain = true;
			cardsToDiscard.splice(i, 1);
			this._cardSprites.getCards()[index]._readyToDiscard = false;
			//this._cardsReadyToDiscard[i]._readyToDiscard = false;
		}
	}

	if (!doesCondtain && cardsToDiscard.length < BattleManager._cardsToDiscard)
	{
		cardsToDiscard.push(index);
		this._cardSprites.getCards()[index]._readyToDiscard = true;
		//this._cardsReadyToDiscard[i]._readyToDiscard = true;

		if (!Isiah.CGC.showEndTurn)
			this.discardSelectedCards();
	}
		
};

Window_BattleSkill.prototype.discardSelectedCards = function ()
{
	var cardsToDiscard = this._cardsReadyToDiscard.getCards();
	if (cardsToDiscard.length == BattleManager._cardsToDiscard)
	{
		cardsToDiscard.sort();
		for (var i = cardsToDiscard.length - 1; i >= 0; i--)
		{
			this.discardCard(cardsToDiscard[i] + this._itemsBeforeCards);
			BattleManager._cardsToDiscard--;
		}

		this._cardsReadyToDiscard.clear();
	}
	
};



Isiah.CGC.Window_SkillList_onTouch = Window_SkillList.prototype.onTouch;
Window_SkillList.prototype.onTouch = function (triggered)
{
	if (!$gameSystem._cardBattleEnabled)
	{
		Isiah.CGC.Window_SkillList_onTouch.call(this, triggered);
		return;
	}

	var lastIndex = this.index();
	var currentIndex = -1;
	var isBattle = this.isInBattle();
	var handCards = isBattle ? this._cardSprites.getCards() : this._cardSprites;
	for (var i = handCards.length - 1; i >= 0; i--)
	{
		var sprite = handCards[i];
		if (sprite.isTouchedInsideFrame())
		{
			currentIndex = i + this._itemsBeforeCards;
			break;
		}
			
	}
	if (currentIndex == -1)
	{
		currentIndex = this.processTouchForSpecialItems(currentIndex);
	}
	if (currentIndex != -1)
	{
		if (currentIndex === lastIndex)
		{
			if (triggered && this.isTouchOkEnabled())
			{
				this.processOk();
			}
		}
		else if (this.isCursorMovable())
		{
			this.select(currentIndex);
		}
	}
	if (this.index() !== lastIndex)
	{
		SoundManager.playCursor();
	}
};

Window_SkillList.prototype.processTouchForSpecialItems = function (currentIndex)
{
	return currentIndex;
}

Window_BattleSkill.prototype.processTouchForSpecialItems = function (currentIndex)
{
	if (currentIndex == -1 && this._endTurnButton)
	{
		if (this._endTurnButton.isTouchedInsideFrame())
		{
			currentIndex = this._endTurnButton._index;
		}

	}
	if (currentIndex == -1 && this._itemButton)
	{
		if (this._itemButton.isTouchedInsideFrame())
			currentIndex = this._itemButton._index;
	}

	return currentIndex;
};

Isiah.CGC.Window_BattleSkill_isEnabled = Window_BattleSkill.prototype.isEnabled;
Window_BattleSkill.prototype.isEnabled = function (item)
{
	if (!$gameSystem._cardBattleEnabled)
	{
		return Isiah.CGC.Window_BattleSkill_isEnabled.call(this, item);
	};

	if (item && !!item.buttonName)
	{
		return this.isExtraButtonEnabled(item);
	}
	if (Isiah.CGC.showEndTurn && this.index() == this.endTurnIndex() && BattleManager._phase != 'discard')
		return this._endTurnButton.isEnabled();
	else if (BattleManager._phase == 'discard')
		return this.isCorrectType(item, this._typeToSelect);
	else if (item == 'itemMenu' || item == 'endTurn')
		return this._itemButton.isEnabled();
	else
		return Isiah.CGC.Window_BattleSkill_isEnabled.call(this, item);
}

Window_BattleSkill.prototype.isCorrectType = function (item, type)
{
	return true;
	//to be overridden in IsiahCGCCardTypes
};



Window_SkillList.prototype.resetCards = function ()
{
	
	var actor = this._actor;

	this._cardSprites.setActor(actor);
	this._discardedSprites.setActor(actor);
	this._removedSprites.setActor(actor);
	this._cardsReadyToDiscard.setActor(actor);


	var handCards = this._cardSprites.getCards();
	for (var i = 0; i < actor._cardHand.length; i++)
	{
		var card = actor._cardHand.card(i);
		var skill = $dataSkills[card.id()];
		if (handCards.length >= i && handCards[i]._skill == skill)
		{
			handCards[i].show();
		}
		else
		{
			var cardSprite = new Sprite_SkillCard(skill, actor);
			handCards.push(cardSprite);
			SceneManager._scene.addCardSprite(cardSprite);
		}
	}

	var discardCards = this._discardedSprites.getCards();
	for (var i = 0; i < actor._cardDiscard.length; i++)
	{
		var card = actor._cardDiscard.card(i);
		var skill = $dataSkills[card.id()];
		if (discardCards.length >= i && discardCards[i]._skill == skill)
		{
			discardCards[i].show();
		}
		else
		{
			var cardSprite = new Sprite_SkillCard(skill, actor);
			this._discardedSprites.getCards().push(cardSprite);
			SceneManager._scene.addCardSprite(cardSprite);
		}

	}

	var otherCards = this._discardedSprites.getOtherCards();
	for (var i = otherCards.length - 1; i >= 0; i--)
	{
		otherCards[i].hide();
	}

	if (SceneManager._scene._discardSprite)
		SceneManager._scene._discardSprite.setCardsLeft(actor._cardDiscard.length);

	if (SceneManager._scene._deckSprite)
		SceneManager._scene._deckSprite.setCardsLeft(actor._cardDeck.length);

	this.makeItemList();
}



Isiah.CGC.Window_BattleStatus_numVisibleRows = Window_BattleStatus.prototype.numVisibleRows;
Window_BattleStatus.prototype.numVisibleRows = function ()
{
	if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
		return Isiah.CGC.Window_BattleStatus_numVisibleRows.call(this);

	var actors = $gameParty.allMembers().slice(0, $gameParty.maxBattleMembers());
	return actors.length;
	//return 1;
};

Isiah.CGC.Window_BattleStatus_windowWidth = Window_BattleStatus.prototype.windowWidth;
Window_BattleStatus.prototype.windowWidth = function ()
{
	if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows || (!Isiah.CGC.statusWindowAtTop && !Isiah.CGC.skipActorCommand))
		return Isiah.CGC.Window_BattleStatus_windowWidth.call(this);

	return Graphics.boxWidth;
}

if (Isiah.CGC.statusWindowAtTop || Isiah.CGC.skipActorCommand)
{
	Isiah.CGC.Window_BattleStatus_updateWindowPositions = Scene_Battle.prototype.updateWindowPositions;
	Scene_Battle.prototype.updateWindowPositions = function ()
	{
		if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
			return Isiah.CGC.Window_BattleStatus_updateWindowPositions.call(this);
		this._statusWindow.x = 0;
	};
}

Isiah.CGC.Window_BattleStatus_update = Window_BattleStatus.prototype.update;
Window_BattleStatus.prototype.update = function ()
{
	Isiah.CGC.Window_BattleStatus_update.call(this);
	if (!Isiah.CGC.changeBattleWindows) return;
	if (!$gameSystem._cardBattleEnabled) return;
	if (!Isiah.CGC.statusWindowAtTop) return;

	if (this._helpWindow && this._helpWindow.visible)
		this.y = this._helpWindow.height;
	else
		this.y = 0;
};

if (!Isiah.Util.usingMZ)
{
	Isiah.CGC.Window_battleStatus_drawBasicArea = Window_BattleStatus.prototype.drawBasicArea;
	Window_BattleStatus.prototype.drawBasicArea = function (rect, actor)
	{
		if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.displayStatusCardIcons || !Isiah.CGC.changeBattleWindows)
		{
			return Isiah.CGC.Window_battleStatus_drawBasicArea.call(this, rect, actor);
		}
		var neededWidth = Window_Base._iconWidth * 3 + this.textWidth("00") * 3 + 8;
		var normalRect = rect.width - neededWidth;
		this.drawActorName(actor, rect.x + 0, rect.y, 150);
		if (!Imported.YEP_BattleStatusWindow)
			this.drawActorIcons(actor, rect.x + 156, rect.y, normalRect - 156);
		if (!Isiah.CGC.PartyUI)
			this.drawActorCardZones(actor, rect.x + normalRect, rect.y, neededWidth);
	}
}

Isiah.CGC.Window_ActorCommand_update = Window_ActorCommand.prototype.update;
Window_ActorCommand.prototype.update = function ()
{
	Isiah.CGC.Window_ActorCommand_update.call(this);
	if (!Isiah.CGC.changeBattleWindows) return;
	if (!$gameSystem._cardBattleEnabled) return;
	if (!Isiah.CGC.statusWindowAtTop) return;

	if (this._helpWindow && this._helpWindow.visible)
		this.y = this._helpWindow.height;
	else
		this.y = 0;
};

Isiah.CGC.Window_ActorCommand_numVisibleRows = Window_ActorCommand.prototype.numVisibleRows;
Window_ActorCommand.prototype.numVisibleRows = function ()
{
	if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
		return Isiah.CGC.Window_ActorCommand_numVisibleRows.call(this);
	return 1;
};

Isiah.CGC.Window_ActorCommand_addAttackCommand = Window_ActorCommand.prototype.addAttackCommand;
Window_ActorCommand.prototype.addAttackCommand = function ()
{
	if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
		Isiah.CGC.Window_ActorCommand_addAttackCommand.call(this);
};

if (!Imported.YEP_BattleEngineCore || !Yanfly.Param.BECEnemySelect)
{
	Isiah.CGC.Window_BattleEnemy_numVisibleRows = Window_BattleEnemy.prototype.numVisibleRows;
	Window_BattleEnemy.prototype.numVisibleRows = function ()
	{
		if (!$gameSystem._cardBattleEnabled || !Isiah.CGC.changeBattleWindows)
			return Isiah.CGC.Window_BattleEnemy_numVisibleRows.call(this);
		return 1;
	};

	Isiah.CGC.Window_BattleEnemy_update = Window_BattleEnemy.prototype.update;
	Window_BattleEnemy.prototype.update = function ()
	{
		Isiah.CGC.Window_BattleEnemy_update.call(this);
		if (!Isiah.CGC.changeBattleWindows) return;
		if (!$gameSystem._cardBattleEnabled) return;
		if (!Isiah.CGC.statusWindowAtTop) return;
			if (this._helpWindow && this._helpWindow.visible)
				this.y = this._helpWindow.height;
			else
				this.y = 0;
	};
}


Isiah.CGC.BattleManager_startBattle = BattleManager.startBattle;
BattleManager.startBattle = function ()
{
	Isiah.CGC.BattleManager_startBattle.call(this);
	this._highestPerformedIndex = -1;
}

BattleManager._cardActions = [];

Isiah.CGC.BattleManager_startAction = BattleManager.startAction;
BattleManager.startAction = function ()
{
	Isiah.CGC.BattleManager_startAction.call(this);
	if ($gameSystem._cardBattleEnabled)
	{
		if (!this._action) return;

		var item = this._action.item();
		if (item && item._cardActions)
		{
			this._cardActions.push.apply(this._cardActions, item._cardActions.split(','));
			this._cardActionIndex = 0;
		}
		else
		{
			this.__executedCardEffects = false;
		}

		if (item && item._cardTargetActions)
		{
			this._cardTargetActions = item._cardTargetActions.split(',');
			this._cardTargetActionIndex = 0;
			this._cardTargets = [...this._targets];
		}

		if (this.__forcedActions && this.__forcedActions.length > 0) return;


		var win = SceneManager._scene._skillWindow;
		if (win.index() >= 0)
		{
			var item = win.item();
			if (item._removeAfterPlay || (item._cardPassives && item._cardPassives.removeAfterPlay))
				win.removeCard(win.index());
			else
				win.discardCard(win.index());
		}
	}
};


Isiah.CGC.BattleManager_updateAction = BattleManager.updateAction;
BattleManager.updateAction = function ()
{
	if (!$gameSystem._cardBattleEnabled)
		return Isiah.CGC.BattleManager_updateAction.call(this);

	var target = this._targets.shift();
	var hadCardActions = (this._cardTargetActionIndex > 0 || this._cardActionIndex > 0);
	if (target)
	{
		this.invokeAction(this._subject, target);
	}
	else
	{
		if (this._cardTargetActions && this._cardTargetActionIndex < this._cardTargetActions.length)
		{
			var target = this._cardTargets[0];
			if (target.isActor())
			{
				SceneManager._scene._skillWindow.setActor(target);
			}
			var action = this._cardTargetActions[this._cardTargetActionIndex];
			target.performCardAction(action);
			this._cardTargetActionIndex++;

			if (this._cardTargetActionIndex >= this._cardTargetActions.length)
			{
				this._cardTargets.shift();
				if (this._cardTargets.length > 0)
					this._cardTargetActionIndex = 0;
				else
					this._cardTargetActions = null;
			}
		}
		else if (this._cardActions && this._cardActionIndex < this._cardActions.length)
		{
			var subject = this._action.subject();
			if (subject.isActor())
			{
				SceneManager._scene._skillWindow.setActor(subject);
			}
			var action = this._cardActions[this._cardActionIndex];
			subject.performCardAction(action);
			this._cardActionIndex++;
			
			if (this._cardActionIndex >= this._cardActions.length)
			{
				this._cardActions = [];
			}
		}
		else if (!this.__executedCardEffects && !hadCardActions)
		{
			this._action.applyCardEffect(); //LEGACY
			this.__executedCardEffects = true;
		}
		else
		{
			if (Imported.YEP_BattleEngineCore)
			{
				if (this._returnPhase === 'target')
				{
					this.setTargets([this._individualTargets[0]]);
					this._phase = 'actionTargetList';
				} else
				{
					this.setTargets(this._allTargets.slice());
					this._phase = 'actionList';
				}
			}
			else
				this.endAction();
		}
	}
};

if (Imported.YEP_BattleEngineCore)
{
	Isiah.CGC.YEPBattle_BattleManager_startAction = BattleManager.startAction;
	BattleManager.startAction = function ()
	{
		Isiah.CGC.YEPBattle_BattleManager_startAction.call(this);
		if ($gameSystem._cardBattleEnabled)
			this._phaseSteps.push('cardActions');
	};

	Isiah.CGC.BattleManager_updatePhase = BattleManager.updatePhase;
	BattleManager.updatePhase = function ()
	{
		var phase = this._phaseSteps[0];
		if (phase == 'cardActions')
		{
			//this._phaseSteps.shift();
			this.createPhaseChanges();
			this.createCardActionsActions(); //I didn't think ahead when I adopted this naming convention.
		}
		else
		{
			Isiah.CGC.BattleManager_updatePhase.call(this);
		}
	};

	BattleManager.createCardActionsActions = function ()
	{
		this._returnPhase = 'cardActions';
		if (this._cardTargetActions && this._cardTargetActionIndex < this._cardTargetActions.length)
		{
			var target = this._cardTargets[0];
			if (target.isActor())
			{
				SceneManager._scene._skillWindow.setActor(target);
			}
			var action = this._cardTargetActions[this._cardTargetActionIndex];
			target.performCardAction(action);
			this._cardTargetActionIndex++;

			if (this._cardTargetActionIndex >= this._cardTargetActions.length)
			{
				this._cardTargets.shift();
				if (this._cardTargets.length > 0)
					this._cardTargetActionIndex = 0;
				else
					this._cardTargetActions = null;
			}
		}
		else if (this._cardActions && this._cardActionIndex < this._cardActions.length)
		{
			//this._phase = 'phaseChange';
			var subject = this._action.subject();
			if (subject.isActor())
			{
				SceneManager._scene._skillWindow.setActor(subject);
			}

			subject.performCardAction(this._cardActions[this._cardActionIndex]);
			this._cardActionIndex++;

			if (this._cardActionIndex >= this._cardActions.length)
			{
				this._phaseSteps.shift();
				this._cardActions = [];
			}
		}
		else
			this._phaseSteps.shift();
	}

}

BattleManager._highestPerformedIndex = -1;

Isiah.CGC.BattleManager_endTurn = BattleManager.endTurn;
BattleManager.endTurn = function ()
{
	if ($gameSystem._cardBattleEnabled)
	{
		if (this.__forcedActions && this.__forcedActions.length > 0) return;

		if (this._highestPerformedIndex != -1)
		{
			for (var i = 0; i < $gameParty.members().length; i++)
			{
				var actor = $gameParty.members()[i];
				this.endTurnForcedActions(actor);
			}
			this._highestPerformedIndex = -1;
			//this._phase = 'turnEnd';
			if (this.__forcedActions && this.__forcedActions.length > 0) return;
		}


		var win = SceneManager._scene._skillWindow;
		var data = win._data;
		for (var i = data.length - 1; i >= 0; i--)
		{
			var item = data[i];
			if (item._cardPassives)
			{
				if (item._cardPassives.removeIfUnplayed)
					win.removeCard(i);
				else if (item._cardPassives.discardIfUnplayed)
					win.discardCard(i);
			}
		}		
	}
	
	Isiah.CGC.BattleManager_endTurn.call(this);
}

BattleManager.requireDiscard = function (amount, mode, type)
{
	if ($gameTroop.isAllDead())
		return;
	if (!mode)
		mode = 'discard';
	this._cardsToDiscard = amount || 1;
	var actor = SceneManager._scene._skillWindow._actor;
	var currentCards = SceneManager._scene._skillWindow._cardSprites.getCards().length;
	if (type != null && Isiah.CGC.Types)
	{
		currentCards = actor.cardsInZoneOfType("hand", type);
	}
	if (this._cardsToDiscard >= currentCards)
	{
		//this._cardsToDiscard = currentCards;
		SceneManager._scene._skillWindow.setDiscardMode(mode);
		SceneManager._scene._skillWindow.discardAllCards(type);
		SceneManager._scene._skillWindow.setDiscardMode('');
	}
	else
	{
		this._previousPhase = this._phase;
		this._phase = 'discard';
		SceneManager._scene._skillWindow.setDiscardMode(mode, type);
	}
}

BattleManager.requireWait = function (frames)
{
	if (frames > 0)
	{
		this._cardWaitFrames = frames;
		this._previousPhase = this._phase;
		this._phase = 'cardwait';
	}
}

BattleManager.updateCardWait = function ()
{
	this._cardWaitFrames--;
	if (this._cardWaitFrames <= 0)
	{
		var skillWindow = SceneManager._scene._skillWindow;
		this._phase = this._previousPhase;
		if (this._phase != 'input')
		{
			skillWindow.deactivate();
		}
	}
}

BattleManager.requireDiscardTo = function (amount, mode, type)
{
	var actor = SceneManager._scene._skillWindow._actor;
	var currentCards = SceneManager._scene._skillWindow._cardSprites.getCards().length;
	var cardsToDiscard = (currentCards - amount);
	if (cardsToDiscard > 0)
		this.requireDiscard(cardsToDiscard, mode, type);
}

BattleManager.updateDiscard = function ()
{
	if (this._cardsToDiscard <= 0)
	{
		var skillWindow = SceneManager._scene._skillWindow;
		SceneManager._scene._skillWindow.setDiscardMode('');
		this._phase = this._previousPhase;
		if (this._phase != 'input')
		{
			skillWindow.deactivate();
		}
	}
	else
	{
		var skillWindow = SceneManager._scene._skillWindow;
		skillWindow.activate();
		if (skillWindow.index() < skillWindow._itemsBeforeCards)
			skillWindow.select(skillWindow._itemsBeforeCards);
	}
};

if (Isiah.Util.usingMZ)
{
	//MZ
	Isiah.CGC.BattleManager_changeCurrentActor = BattleManager.changeCurrentActor;
	BattleManager.changeCurrentActor = function (forward)
	{
		const members = $gameParty.battleMembers();
		Isiah.CGC.BattleManager_changeCurrentActor.call(this, forward);
		if ($gameSystem._cardBattleEnabled)
		{
			var actor = this._currentActor;
			if (actor)
			{
				var newActorIndex = members.indexOf(actor);
				this.startTurnCardActions(actor, newActorIndex);
			}
		}
	}
}
else
{
	//MV
	Isiah.CGC.BattleManager_changeActor = BattleManager.changeActor;
	BattleManager.changeActor = function (newActorIndex, lastActorActionState)
	{
		Isiah.CGC.BattleManager_changeActor.call(this, newActorIndex, lastActorActionState);
		if ($gameSystem._cardBattleEnabled)
		{
			var actor = this.actor();
			this.startTurnCardActions(actor, newActorIndex);
		}
	};
}


//CTB still not fully compatible.
if (Imported.YEP_X_BattleSysCTB)
{
	console.warn("Warning: Card Game Combat is not fully compatible with Yanfly's CTB system.");
	Isiah.CGC.BattleManager_startCTBInput = BattleManager.startCTBInput;
	BattleManager.startCTBInput = function (battler)
	{
		Isiah.CGC.BattleManager_startCTBInput.call(this, battler);
		if ($gameSystem._cardBattleEnabled)
		{
			var actor = this.actor();
			this.startTurnCardActions(actor, -1);
		}
	}

	Isiah.CGC.Game_Battler_checkCTBEndInstantCast = Game_Battler.prototype.checkCTBEndInstantCast;
	Game_Battler.prototype.checkCTBEndInstantCast = function ()
	{
		var action = this.currentAction();
		if (!action) return false;
		var item = action.item();
		if (!item) return false;
		if (item.meta.willEndTurn)
		{
			this._ctbSpeed = Math.max(this._ctbSpeed, BattleManager.ctbTarget());
			this._ctbSpeed += 0.00000000001;
			return true;
		}

		return Isiah.CGC.Game_Battler_checkCTBEndInstantCast.call(this);
	}
}

BattleManager.startTurnCardActions = function (actor, newActorIndex)
{
	if (actor)
	{
		SceneManager._scene._skillWindow.setActor(actor);
		if (newActorIndex > this._highestPerformedIndex || !this.isUsingDTB())
		{
			this._highestPerformedIndex = newActorIndex;
			var actions = this.getStartCardActions(actor);
			this._cardActions.push.apply(this._cardActions, actions.split('\n'));
			this._cardActionIndex = 0;

			this._phase = 'cardstart';
			this._cardStartActor = actor;

			SceneManager._scene._statusWindow.refresh();
			//this.startTurnForcedActions(actor);
		}
	}
};

BattleManager.isUsingDTB = function ()
{
	if (Imported.YEP_X_BattleSysSTB)
		return false;
	if (Imported.YEP_X_BattleSysCTB)
		return false;

	return true;
}

BattleManager.getStartCardActions = function (actor)
{
	if (!actor._battleStart)
	{
		return (Isiah.CGC.startOfTurnActions);
	}
	else
	{
		actor._battleStart = false;
		return (Isiah.CGC.startOfBattleActions);
	}
}

BattleManager.updateCardStart = function ()
{
	if (this._cardActions && this._cardActionIndex < this._cardActions.length)
	{
		var action = this._cardActions[this._cardActionIndex];
		this._cardStartActor.performCardAction(action);
		this._cardActionIndex++;

		if (this._cardActionIndex >= this._cardActions.length)
		{
			this._cardActions = [];
		}
	}
	else
	{
		
		this._phase = 'input';

		this.startTurnForcedActions(this._cardStartActor);
		this._cardStartActor = undefined;
	}
}

BattleManager.startTurnForcedActions = function (actor)
{
	if (!this.__forcedActions)
		this.__forcedActions = [];
	for (var i = 0; i < actor._cardHand.length; i++)
	{
		var card = actor._cardHand.card(i);
		var skillId = card.id();
		var skill = $dataSkills[skillId];
		if (skill.__forcedActions && skill.__forcedActions.turnStart)
		{
			var actions = skill.__forcedActions.turnStart;
			for (var j = 0; j < actions.length; j++)
			{
				this.__forcedActions.push({ actor: actor, skill: actions[j] });
			}
		}
	}
};

BattleManager.endTurnForcedActions = function (actor)
{
	if (!this.__forcedActions)
		this.__forcedActions = [];
	for (var i = 0; i < actor._cardHand.length; i++)
	{
		var card = actor._cardHand.card(i);
		var skillId = card.id();
		var skill = $dataSkills[skillId];
		if (skill.__forcedActions && skill.__forcedActions.turnEnd)
		{
			var actions = skill.__forcedActions.turnEnd;
			for (var j = 0; j < actions.length; j++)
			{
				this.__forcedActions.push({ actor: actor, skill: actions[j] });
			}
		}
	}

	return (this.__forcedActions.length > 0);
};

BattleManager.exitZoneForcedActions = function (actor, zone, skillId)
{
	
	if (!this.__forcedActions)
		this.__forcedActions = [];
	var skill = $dataSkills[skillId];
	if (skill.__forcedActions && skill.__forcedActions.exitZone)
	{
		var exitZoneActions = skill.__forcedActions.exitZone;
		for (var i = 0; i < exitZoneActions.length; i++)
		{
			var action = exitZoneActions[i];
			if (action.zone == zone)
			{
				this.__forcedActions.push({ actor: actor, skill: action.skill });
			}
		}
	}
}

BattleManager.enterZoneForcedActions = function (actor, zone, skillId)
{
	if (!this.__forcedActions)
		this.__forcedActions = [];
	var skill = $dataSkills[skillId];
	if (skill.__forcedActions && skill.__forcedActions.enterZone)
	{
		var enterZoneActions = skill.__forcedActions.enterZone;
		for (var i = 0; i < enterZoneActions.length; i++)
		{
			var action = enterZoneActions[i];
			if (action.zone == zone)
				this.__forcedActions.push({ actor: actor, skill: action.skill });
		}
	}
}

BattleManager.playForcedAction = function ()
{
	var actor = this.__forcedActions[0].actor;
	var skill = Number(this.__forcedActions[0].skill);
/*	if (Imported.YEP_BattleEngineCore)
	{
		this.createForceActionFailSafes();
		this.queueForceAction(actor, skill);
	}
	else*/
	{
		actor.forceAction(skill, -1);
		this.forceAction(actor);
	}

	if (Imported.YEP_InstantCast)
		this.performInstantCast();
	else
		this.playCard();
	SceneManager._scene._skillWindow.deactivate();
	SceneManager._scene._skillWindow.deselect();
	SceneManager._scene._partyCommandWindow.deactivate();
	SceneManager._scene._actorCommandWindow.deactivate();
	this.__forcedActions.splice(0, 1);
}


Game_Battler.prototype.atMaxHandSize = function ()
{
	return true;
}

Game_Battler.prototype.drawCards = function (amount)
{
	for (var i = 0; i < amount; i++)
	{
		this.drawCard();
	}
};

Game_Battler.prototype.drawCardsUntil = function (amount)
{
	if (!this._cardHand) return;

	var len = this._cardHand.length;
	for (var i = len; i < amount; i++)
	{
		this.drawCard();
	}
};

Game_Battler.prototype.drawCard = function ()
{
	if (!this._cardDeck) return;

	if (this._cardDeck.length > 0)
	{
		//this.drawCardAtIndex(0);
		this.moveCard(0, this._cardDeck, this._cardHand);
	}
	else
	{
		setTimeout(() =>
		{
			if (SceneManager._scene instanceof Scene_Battle)
				this.drawCard();
		}, 100);
	}
};

Game_Battler.prototype.drawCardAtIndex = function (index)
{
	if (this.atMaxHandSize())
		return;

	if (this._cardDeck.length > index)
	{
		var card = this.exitCard(this._cardDeck, index);
		this.enterCard(this._cardHand, card);

		if (this._cardDeck.length == 0)
		{
			this.reshuffleDeck();
		}

		if (SceneManager._scene._skillWindow)
			SceneManager._scene._skillWindow.addCard(card.id(), this);

		this.updateCardVariables();
	}
}

Game_Battler.prototype.millCards = function (amount)
{
	this.moveCards(amount, "deck", "discard");
};

Game_Battler.prototype.millCard = function ()
{
	this.moveCards(1, "deck", "discard");
};

Game_Actor.prototype.millCardAtIndex = function (index)
{
	if (this.atMaxHandSize()) return;

	this.moveCard(index, this.getZoneByName("deck"), this.getZoneByName("discard"));
};

Game_Battler.prototype.moveCards = function (amount, zone1, zone2)
{
	var startingZone = this.getZoneByName(zone1);
	var endingZone = this.getZoneByName(zone2);

	if (startingZone == this._cardHand)
	{
		if (endingZone == this._cardDiscard)
			this.discardCards(amount);
		else if (endingZone == this._cardDeck)
		{
			BattleManager.requireDiscard(amount, 'return');
		}
	}
	else
	{
		for (var i = 0; i < amount; i++)
		{
			this.moveCard(0, startingZone, endingZone);
		}
	}

};

Game_Battler.prototype.moveCard = function (index, startingZone, endingZone)
{

	if (endingZone == this._cardHand && this.atMaxHandSize()) return;
	if (!startingZone || !endingZone) return;
	if (startingZone.length == 0) return;
	if (startingZone == endingZone) return;

	var card = this.exitCard(startingZone, index);
	this.enterCard(endingZone, card);

	if (startingZone == this._cardDeck && this._cardDeck.length == 0)
	{
		this.reshuffleDeck();
	}

	var skillWindow = SceneManager._scene._skillWindow;
	if (startingZone == this._cardDeck)
	{
		var skill = card.id();
		if (endingZone == this._cardDiscard)
			skillWindow.addCardDiscard(skill, this);
		else if (endingZone == this._cardHand)
			skillWindow.addCard(skill, this);
		else
		{
			this.moveCardToCustomZone(startingZone, endingZone);
		}
	}
	else if (startingZone == this._cardDiscard)
	{
		var cardSprite = skillWindow._discardedSprites.popCard(this, index);
		if (endingZone == this._cardDeck)
			skillWindow._resetCardSprites.push(cardSprite);
		else if (endingZone == this._cardHand)
		{
			skillWindow._cardSprites.pushCard(cardSprite);
			skillWindow.makeItemList();
		}
		else
		{
			this.moveCardToCustomZone(startingZone, endingZone);
		}
	}
	else
	{
		this.moveCardToCustomZone(startingZone, endingZone);
	}

	this.updateCardVariables();
};

Game_Battler.prototype.moveCardToCustomZone = function (startingZone, endingZone)
{
	//
}


Game_Battler.prototype.shuffleDeck = function ()
{
	if (!this._cardDeck) return;
	this._cardDeck.shuffle();
}

//requires player input for actor and something else for enemy
Game_Battler.prototype.discardCards = function (amount)
{
};

//requires player input for actor and something else for enemy
Game_Battler.prototype.discardCardsUntil = function (amount)
{
};

//requires player input for actor and something else for enemy
Game_Battler.prototype.removeCards = function (amount)
{
};

//requires player input for actor and something else for enemy
Game_Battler.prototype.removeCardsUntil = function (amount)
{
};

Game_Battler.prototype.drawCardOfSkillId = function (skillId)
{
	if (this.atMaxHandSize())
		return;

	var index = null;
	for (var i = 0; i < this._cardDeck.length; i++)
	{
		var card = this._cardDeck.card(i);
		if (card.id() == skillId)
		{
			index = i;
			break;
		}
	}

	if (index != null)
	{
		var card = this.exitCard(this._cardDeck, index);
		this.enterCard(this._cardHand, card);

		if (this._cardDeck.length == 0)
		{
			this.reshuffleDeck();
		}

		if (SceneManager._scene._skillWindow)
			SceneManager._scene._skillWindow.addCard(card.id(), this);


		this.updateCardVariables();
	}
};

Game_Battler.prototype.drawCardOfSkillName = function (skillName)
{
	var skill = Isiah.Util.findSkillbyName(skillName);
	if (!skill) return;
	this.drawCardOfSkillId(skill.id);
};

Game_Battler.prototype.addCardToZone = function (skill, zone)
{
	zone = zone.trim().toLowerCase();
	var cardZone = null;
	switch (zone)
	{
		case "deck":
			cardZone = this._cardDeck; break;
		case "discard":
			cardZone = this._cardDiscard; break;
		case "hand":
			cardZone = this._cardHand; break;
	}

	if (cardZone == null)
		return console.error("Error trying to add skill #" + skill + " to zone " + zone + ". Did you misspell a zone name?");

	cardZone.push(skill);

	this.updateCardVariables();
}

Game_Battler.prototype.syncEvalVariables = function ()
{
};

Game_Battler.prototype.performCardAction = function (action)
{
}

Game_Battler.prototype.exitCard = function (zone, index)
{
	var card = zone.splice(index, 1);
	BattleManager.exitZoneForcedActions(this, zone.name, card.id());
	return card;
}

Game_Battler.prototype.enterCard = function (zone, card)
{
	zone.add(card);
	BattleManager.enterZoneForcedActions(this, zone.name, card.id());
	return card;
}

Game_Battler.prototype.getZoneByName = function (zoneName)
{
	zoneName = zoneName.trim().toLowerCase();
	var cardZone = null;
	switch (zoneName)
	{
		case "deck":
			cardZone = this._cardDeck; break;
		case "discard":
			cardZone = this._cardDiscard; break;
		case "hand":
			cardZone = this._cardHand; break;
	}

	return cardZone;
}

Game_Battler.prototype.reshuffleDeck = function ()
{
	if (this._cardDiscard.length > 0)
	{
		while (this._cardDiscard.length > 0)
		{
			var card = this.exitCard(this._cardDiscard, 0);
			this.enterCard(this._cardDeck, card);
		}
		this._cardDeck.shuffle();



		return true;

		this.updateCardVariables();
	}
	else
	{
		setTimeout(() =>
		{
			this.reshuffleDeck();
		}, 100);

		return false;
	}
};




Isiah.CGC.Game_Actor_initMembers = Game_Actor.prototype.initMembers;
Game_Actor.prototype.initMembers = function ()
{
	Isiah.CGC.Game_Actor_initMembers.call(this);
	this._skillCards = new Game_Cards("skills");
	this._cardDeck =   new Game_Cards("deck");
	this._cardHand = new Game_Cards("hand");
	this._cardDiscard = new Game_Cards("discard");
	this.handSize = 0;
	this.currentDeckSize = 0;
	this.totalDeckSize = 0;
	this.discardSize = 0;
	this.cardsInPlay = 0;
	this.cardsToDraw = 0;
	this.removedCards = 0;
	this._bonusHandSize = 0;
	this._battleStart = false;
};

var useMakeActions = false;


Isiah.CGC.Game_Actor_onBattleStart = Game_Actor.prototype.onBattleStart;
Game_Actor.prototype.onBattleStart = function ()
{
	Isiah.CGC.Game_Actor_onBattleStart.call(this);

	if ($gameSystem._cardBattleEnabled)
	{
		//Make a copy of the deck so anything that gives you cards midway through the battle
		// is not saved
		this._deckCopy = new Game_Cards("copy");
		this._deckCopy.copy(this._cardDeck);

		this.removedCards = 0;

		this.performStartOfBattlePassives();

		this.totalDeckSize = this._cardDeck.length;
		this._battleStart = true;
	}
	
};

Game_Actor.prototype.performStartOfBattlePassives = function ()
{
	for (var i = this._cardDeck.length - 1; i >= 0; i--)
	{
		var card = this._cardDeck.card(i);
		var cardId = card.id();
		var skill = $dataSkills[cardId];
		if (skill && skill._cardPassives)
		{
			if (skill._cardPassives.startInZone == 'hand')
				this.drawCardOfSkillId(cardId);
		}
	}
}


Game_Actor.prototype.performCardAction = function (action)
{
	BattleManager._currentCardActor = this;

	action = action.replace(/`comma`/g, ',');
	action = action.replace(/\\/g, '\x1b');
	action = action.replace(/\x1b\x1b/g, '\\');
	action = action.replace(/\x1bV\[(\d+)\]/gi, function ()
	{
		return $gameVariables.value(parseInt(arguments[1]));
	}.bind(this));

	if (action.match(/<?(?:Draw )(\d+)>?/i))
	{
		this.drawCards(RegExp.$1);
	}
	else if (action.match(/<?(?:Draw Until )(\d+)>?/i))
	{
		this.drawCardsUntil(RegExp.$1);
	}
	else if (action.match(/(?:Search For )(\d+)/i))
	{
		this.drawCardOfSkillId(RegExp.$1);
	}
	else if (action.match(/(?:Search For )(.+)/i))
	{
		this.drawCardOfSkillName(RegExp.$1);
	}
	else if (action.match(/<?(?:Discard )(\d+)>?/i))
	{
		BattleManager.requireDiscard(RegExp.$1);
	}
	else if (action.match(/<?(?:Discard Until )(\d+)>?/i))
	{
		BattleManager.requireDiscardTo(RegExp.$1);
	}
	else if (action.match(/<?(?:Remove )(\d+)>?/i))
	{
		BattleManager.requireDiscard(RegExp.$1, 'remove');
	}
	else if (action.match(/<?(?:Remove Until )(\d+)>?/i))
	{
		BattleManager.requireDiscardTo(RegExp.$1, 'remove');
	}
	else if (action.match(/<?(?:Wait )(\d+)>?/i))
	{
		BattleManager.requireWait(RegExp.$1);
	}
	else if (action.match(/<?(?:Mill )(\d+)>?/i))
	{
		this.millCards(RegExp.$1);
	}
	else if (action.match(/<?Shuffle Deck>?/i))
	{
		this.shuffleDeck();
	}
	else if (action.match(/<?(?:Add )(\d+)(?: to )(\w+)>?/i))
	{
		var skill = RegExp.$1;
		var zone = RegExp.$2;
		this.addCardToZone(skill, zone);
	}
	else if (action.match(/(?:Move )(\d+)(?: from )(\w+)(?: to )(\w+)/i))
	{
		var amount = RegExp.$1;
		var zone1 = RegExp.$2;
		var zone2 = RegExp.$3;
		this.moveCards(amount, zone1, zone2);
	}
	else if (action.match(/(?:Move skill )(\d+)(?: from )(\w+)(?: to )(\w+)/i))
	{
		var skill = RegExp.$1;
		var zone1 = RegExp.$2;
		var zone2 = RegExp.$3;
		//TODO: 
	}
	else if (action.match(/eval (.*)/i))
	{
		var user = this;
		try
		{
			eval(RegExp.$1);
		}
		catch (error)
		{
			console.error(error);
			console.error("Error in IsiahCardGameCombat Card Action Eval.");
		}
	}
	else
	{
		console.log("IsiahCardGameCombat warning - action " + action + " is not registered.\nCould there be a typo?");
	}
}

Isiah.CGC.Game_Actor_onBattleEnd = Game_Actor.prototype.onBattleEnd;
Game_Actor.prototype.onBattleEnd = function ()
{
	Isiah.CGC.Game_Actor_onBattleEnd.call(this);
	if ($gameSystem._cardBattleEnabled)
		this.returnCardsToDeck();
	
};

Game_Actor.prototype.returnCardsToDeck = function ()
{
	this._cardDeck.clear();
	this._cardHand.clear();
	this._cardDiscard.clear();

	this._cardDeck.copy(this._deckCopy);
}

Game_Actor.prototype.atMaxHandSize = function ()
{
	if (Isiah.CGC.maxHandSize != -1)
	{
		var totalHandSize = Isiah.CGC.maxHandSize + this._bonusHandSize;
		if (this._cardHand.length >= totalHandSize)
			return true;
	}

	return false;
}









Game_Actor.prototype.addCardToZone = function (skill, zone)
{
	Game_Battler.prototype.addCardToZone.call(this, skill, zone);

	if (SceneManager._scene._skillWindow)
		SceneManager._scene._skillWindow.addCardToZone(skill, zone, this);

	this.updateCardVariables();
}

Game_Actor.prototype.updateCardVariables = function ()
{
	var scene = SceneManager._scene;
	if (scene._deckSprite)
		scene._deckSprite.setCardsLeft(this._cardDeck.length);
	if (scene._discardSprite)
		scene._discardSprite.setCardsLeft(this._cardDiscard.length);

	this.syncEvalVariables();
}


Game_Actor.prototype.discardCards = function (amount)
{
	BattleManager.requireDiscard(amount);
};

Game_Actor.prototype.discardCardsUntil = function (amount)
{
	BattleManager.requireDiscardTo(amount);
};

Game_Actor.prototype.removeCards = function (amount)
{
	BattleManager.requireDiscard(amount, 'remove');
};

Game_Actor.prototype.removeCardsUntil = function (amount)
{
	BattleManager.requireDiscardTo(amount, 'remove');
};

Game_Actor.prototype.reshuffleDeck = function ()
{
	var success = Game_Battler.prototype.reshuffleDeck.call(this);
	if (success)
	{
		if (SceneManager._scene._skillWindow)
		{
			SceneManager._scene._skillWindow.reshuffleDeck();
		}
	}
};



Isiah.CGC.Game_Actor_learnSkill = Game_Actor.prototype.learnSkill;
Game_Actor.prototype.learnSkill = function (skillId)
{
	Isiah.CGC.Game_Actor_learnSkill.call(this, skillId);

	if (!$dataSkills[skillId])
	{
		console.error("Warning: The database does not contain a skill with the ID of " + skillId + ". If an actor draws a card with that ID, it will crash the game.");
	}
	else
	{
		this._skillCards.push(skillId);
		if (Isiah.CGC.addLearnedSkillToDeck)
			this._cardDeck.push(skillId);
		if ($gameParty._actors.includes(this.actorId))
			$gameParty.addCardToLibrary(skillId);
	}
	
};

Isiah.CGC.Game_Actor_forgetSkill = Game_Actor.prototype.forgetSkill;
Game_Actor.prototype.forgetSkill = function (skillId)
{
	var index = this._skillCards.indexOf(skillId);
	if (index >= 0)
	{
		this._skillCards.splice(index, 1);

		index = this._skillCards.indexOf(skillId);
		if (index == -1)
		{
			Isiah.CGC.Game_Actor_forgetSkill.call(this, skillId);
		}

		if (index == -1 || Isiah.CGC.addLearnedSkillToDeck)
		{
			var index = this._cardDeck.indexOf(skillId);
			if (index >= 0)
				this._cardDeck.splice(index, 1);
		}

		$gameParty.removeCardFromLibrary(skillId);
	}
};

Game_Actor.prototype.syncEvalVariables = function ()
{
	this.handSize = this._cardHand.length;
	this.currentDeckSize = this._cardDeck.length;
	this.discardSize = this._cardDiscard.length;
	this.cardsInPlay = this._cardDiscard.length + this._cardDeck.length + this._cardHand.length;
};

Isiah.CGC.Game_Actor_canUse = Game_BattlerBase.prototype.canUse;
Game_Actor.prototype.canUse = function (item)
{
	if (!$gameSystem._cardBattleEnabled)
		return Isiah.CGC.Game_Actor_canUse.call(this, item);

	var canUse = Isiah.CGC.Game_Actor_canUse.call(this, item);
	if (SceneManager._scene instanceof Scene_Battle && canUse)
	{
		if (item._cardPassives && item._cardPassives.requirements)
		{
			for (var i = 0; i < item._cardPassives.requirements.length; i++)
			{
				var req = item._cardPassives.requirements[i];
				var user = this;
				try
				{
					canUse = eval(req);
				}
				catch (error)
				{
					console.error(error);
					console.error("Error in IsiahCardGameCombat Card Passive Require. It tried to parse an expression it didn't understand in Skill #"
						+ item.id + " " + item.name + ". Make sure your syntax is correct.");
				}

				if (!canUse) break;
			}
		}
	}

	return canUse;
}

Isiah.CGC.Game_Party_setupStartingMembers = Game_Party.prototype.setupStartingMembers;
Game_Party.prototype.setupStartingMembers = function ()
{
	Isiah.CGC.Game_Party_setupStartingMembers.call(this);
	for (var i = 0; i < this._actors.length; i++)
	{
		var actor = $gameActors.actor(this._actors[i]);
		var skillCards = actor._skillCards.slice();
		for (var j = 0; j < skillCards.length; j++)
		{
			if (this._allCards)
				this._allCards.add(skillCards[j]);
		}
	}
}

Isiah.CGC.Game_Party_addActor = Game_Party.prototype.addActor;
Game_Party.prototype.addActor = function (actorId)
{
	if (!this._actors.contains(actorId) && $gameSystem._cardBattleEnabled && SceneManager._scene instanceof Scene_Battle)
	{
		resetZones = true;
		var actor = $gameActors.actor(actorId);
		SceneManager._scene._skillWindow.addActorToZones(actor);
	}
	if (!this._actors.includes(actorId))
	{
		var skillCards = $gameActors.actor(actorId)._skillCards.slice();
		for (var i = 0; i < skillCards.length; i++)
		{
			this._allCards.add(skillCards[i]);
		}
	}
	Isiah.CGC.Game_Party_addActor.call(this, actorId);
};

Isiah.CGC.Game_Party_initialize = Game_Party.prototype.initialize;
Game_Party.prototype.initialize = function ()
{
	Isiah.CGC.Game_Party_initialize.call(this);
	this._allCards = new Game_Cards("Library");
};

Game_Party.prototype.addCardToLibrary = function (skillId)
{
	this._allCards.push(skillId);
}


Game_Party.prototype.removeCardFromLibrary = function (skillId)
{
	var index = this._allCards.indexOf(skillId);
	if (index >= 0)
		this._allCards.splice(index, 1);
}



Isiah.CGC.Scene_ItemBase_create = Scene_ItemBase.prototype.create;
Scene_ItemBase.prototype.create = function ()
{
	ImageManager.loadBitmap("img/system/", Isiah.CGC.images.card, 0, true);
	Isiah.CGC.Scene_ItemBase_create.call(this);
};

Isiah.CGC.Scene_Battle_updateBattleProcess = Scene_Battle.prototype.updateBattleProcess;
Scene_Battle.prototype.updateBattleProcess = function ()
{
	//console.log(BattleManager._phase);
	if (BattleManager._phase == 'discard')
		BattleManager.updateDiscard();
	else if (BattleManager._phase == 'cardwait')
		BattleManager.updateCardWait();
	else if (BattleManager._phase == 'cardstart')
		BattleManager.updateCardStart();

	var isActionPhase = BattleManager.isActionPhase();
	if ((!isActionPhase && BattleManager._phase != 'discard') && BattleManager.__forcedActions && BattleManager.__forcedActions.length > 0)
	{
		BattleManager.playForcedAction();
	}
	Isiah.CGC.Scene_Battle_updateBattleProcess.call(this);
};

//This prevents Input from changing during a series of forced inputs
Isiah.CGC.Scene_Battle_changeInputWindow = Scene_Battle.prototype.changeInputWindow;
Scene_Battle.prototype.changeInputWindow = function ()
{
	if (BattleManager.__forcedActions == undefined || BattleManager.__forcedActions.length == 0)
		Isiah.CGC.Scene_Battle_changeInputWindow.call(this);
}

BattleManager.isActionPhase = function ()
{
	if (this._processingForcedAction) return true;

	switch (this._phase)
	{
		case 'action':
		case 'actionList':
		case 'actionTargetList':
			return true;
			break;
		default:
			return false;
			break;
	}
}

Isiah.CGC.Scene_Battle_createDisplayObjects = Scene_Battle.prototype.createDisplayObjects;
Scene_Battle.prototype.createDisplayObjects = function ()
{
	ImageManager.loadBitmap("img/system/", Isiah.CGC.images.card, 0, true);
	ImageManager.loadBitmap("img/system/", Isiah.CGC.images.cardDeck, 0, true);
	ImageManager.loadBitmap("img/system/", Isiah.CGC.images.cardDiscard, 0, true);
	Isiah.CGC.Scene_Battle_createDisplayObjects.call(this);

	if (!$gameSystem._cardBattleEnabled)
		return;

	if (Isiah.CGC.showEndTurn)
		this.createEndTurnButton();
	if (Isiah.CGC.showItemButton)
		this.createItemButton();

	this.createExtraButtons();
}

Isiah.CGC.Scene_Battle_createSkillWindow = Scene_Battle.prototype.createSkillWindow;
Scene_Battle.prototype.createSkillWindow = function ()
{
	Isiah.CGC.Scene_Battle_createSkillWindow.call(this);
};

Isiah.CGC.Scene_battle_commandSkill = Scene_Battle.prototype.commandSkill;
Scene_Battle.prototype.commandSkill = function ()
{
	Isiah.CGC.Scene_battle_commandSkill.call(this);
	if (!$gameSystem._cardBattleEnabled)
	{
		return;
	}
		

	this._skillWindow.select(this._skillWindow._itemsBeforeCards);
	if (Isiah.Util.usingMZ)
	{
		this._statusWindow.show();

	}
		
}

Isiah.CGC.Scene_Battle_onSkillOk = Scene_Battle.prototype.onSkillOk;
Scene_Battle.prototype.onSkillOk = function ()
{
	if (!$gameSystem._cardBattleEnabled)
	{
		Isiah.CGC.Scene_Battle_onSkillOk.call(this);
		return;
	}
	if (BattleManager._phase == 'discard')
	{
		var wasValidString = false;
		var item = this._skillWindow.item();
		if (typeof item === 'string')
		{
			return;
		}
		var index = this._skillWindow.index();
		if (Isiah.CGC.showEndTurn && index == this._skillWindow.endTurnIndex())
		{
			this._skillWindow.discardSelectedCards();
		}
		else
		{
			this._skillWindow.readyDiscard(index);
		}
		//this._skillWindow.discardCard(index);
		this._skillWindow.reselect();
		this._skillWindow.activate();
		//BattleManager._cardsToDiscard--;
	}
	else
	{
		var wasValidString = false;
		var item = this._skillWindow.item();
		if (typeof item === 'string')
		{
			wasValidString = this.executeStringSkill(item);
		}

		if (wasValidString == false)
			Isiah.CGC.Scene_Battle_onSkillOk.call(this);
	}
	
	//SceneManager._scene.reorderCardSprites(index);
	//
};

Scene_Battle.prototype.executeStringSkill = function (string)
{
	if (string == 'itemMenu' && Isiah.CGC.showItemButton)
	{
		this._lastWindow = 'skill';
		this.commandItem();
		return true;
	}
	return false;
}

Isiah.CGC.Scene_Battle_onSkillCancel = Scene_Battle.prototype.onSkillCancel;
Scene_Battle.prototype.onSkillCancel = function ()
{
	if (!$gameSystem._cardBattleEnabled)
	{
		Isiah.CGC.Scene_Battle_onSkillCancel.call(this);
		return;
	}

	if (BattleManager._phase != 'discard')
	{
		if (Isiah.CGC.skipActorCommand)
		{
			this.selectPreviousCommand();
			this._skillWindow.deselect();
		}
		else
		{
			Isiah.CGC.Scene_Battle_onSkillCancel.call(this);
			//SceneManager._scene.reorderCardSprites();
			this._skillWindow.deselect();
		}
	}
	
};

Isiah.CGC.Scene_Battle_onItemCancel = Scene_Battle.prototype.onItemCancel;
Scene_Battle.prototype.onItemCancel = function ()
{
	if (!$gameSystem._cardBattleEnabled)
	{
		Isiah.CGC.Scene_Battle_onItemCancel.call(this);
		return;
	}

	if (this._lastWindow == 'skill')
	{
		this._lastWindow = undefined;
		this._itemWindow.hide();
		this._skillWindow.activate();
		this._skillWindow.reselect();

		if (Isiah.CGC.showHelpWindow)
		{
			this._helpWindow.show();
		}
	}
	else
		Isiah.CGC.Scene_Battle_onItemCancel.call(this);

	if (Isiah.Util.usingMZ)
		this._actorWindow.show();
};

if (Isiah.Util.usingMZ)
{
	Isiah.CGC.Scene_Battle_onEnemyCancel = Scene_Battle.prototype.onEnemyCancel;
	Scene_Battle.prototype.onEnemyCancel = function ()
	{
		Isiah.CGC.Scene_Battle_onEnemyCancel.call(this);
		if (!$gameSystem._cardBattleEnabled)
		{
			return;
		}

		this._statusWindow.show();
		this._skillWindow.activate();
	}
}


Isiah.CGC.Scene_Battle_createWindowLayer = Scene_Battle.prototype.createWindowLayer;
Scene_Battle.prototype.createWindowLayer = function ()
{
	
	if ($gameSystem._cardBattleEnabled && !this._cardParent)
	{
		var cardParent = new Sprite();
		this._cardParent = cardParent;
		this.addChild(this._cardParent);
	}

	Isiah.CGC.Scene_Battle_createWindowLayer.call(this);
	if ($gameSystem._cardBattleEnabled)
	{
		this.createDeckSprite();
		this.createDiscardSprite();
	}
};

Scene_Battle.prototype.createDeckSprite = function ()
{
	this._deckSprite = new Sprite_DeckTop();
	this._deckSprite.x = Isiah.CGC.coordinates.deckX;
	this._deckSprite.y = Isiah.CGC.coordinates.deckY;
	this.addCardSprite(this._deckSprite);
};

Scene_Battle.prototype.createDiscardSprite = function ()
{
	this._discardSprite = new Sprite_DiscardPile();
	this._discardSprite.x = Isiah.CGC.coordinates.discardX;
	this._discardSprite.y = Isiah.CGC.coordinates.discardY;
	this.addCardSprite(this._discardSprite);
}

Scene_Battle.prototype.createEndTurnButton = function ()
{
	this._endTurnButton = new Sprite_EndTurnButton();
	this._endTurnButton._skillWindow = this._skillWindow;
	this._skillWindow._endTurnButton = this._endTurnButton;
	/*	var bitmap = Isiah.Util.createOutline(100, 100, 2);//new Bitmap(100, 100);
		bitmap.drawText("EndTurn", 0, 0, 100, 100, 'center');
		this._endTurnButton.bitmap = bitmap;*/
	this.addCardSprite(this._endTurnButton);
	this._endTurnButton.x = Isiah.CGC.coordinates.endTurnButtonX;
	this._endTurnButton.y = Isiah.CGC.coordinates.endTurnButtonY;
};

Scene_Battle.prototype.createItemButton = function ()
{
	this._itemButton = new Sprite_CardButton('itemMenu');
	this._itemButton._enabledCondition = Isiah.CGC.itemButtonCondition;
	this._itemButton._skillWindow = this._skillWindow;
	this._skillWindow._itemButton = this._itemButton;
	var images = Isiah.CGC.images;
	this._itemButton.setBitmaps(images.itemButton, images.itemButtonDisabled, images.itemButtonHighlight);
	//this._itemButton.setIndex(0);
	this.addCardSprite(this._itemButton);
	

	this._itemButton.x = Isiah.CGC.coordinates.itemButtonX;
	this._itemButton.y = Isiah.CGC.coordinates.itemButtonY;
}

Scene_Battle.prototype.createExtraButtons = function ()
{
	this._extraButtons = [];
	//to be overwritten by IsiahCGCExtraButtons
}

Scene_Base.prototype.addCardSprite = function (sprite)
{
	this._cardParent.addChild(sprite);
	if (sprite._amountText)
	{
		this._cardParent.addChild(sprite._amountText);
	}
};

Scene_Base.prototype.removeCardSprite = function (sprite)
{
	this._cardParent.removeChild(sprite);
	if (sprite._amountText)
		this._cardParent.removeChild(sprite._amountText);
};

Scene_Battle.prototype.reorderCardSprites = function (indexToFront)
{
	if (!this._skillWindow) return;
	var actor = this._skillWindow._actor;
	var sprites = this._skillWindow._cardSprites.getCards();
	for (var i = 0; i < sprites.length; i++)
	{
		this.removeCardSprite(sprites[i]);
	}

	for (var i = 0; i < sprites.length; i++)
	{
		if (i != indexToFront)
			this.addCardSprite(sprites[i]);
	}

	if (indexToFront != null && indexToFront >= 0 && indexToFront < sprites.length)
		this.addCardSprite(sprites[indexToFront]);
};

Isiah.CGC.Scene_Battle_createAllWindows = Scene_Battle.prototype.createAllWindows;
Scene_Battle.prototype.createAllWindows = function ()
{
	Isiah.CGC.Scene_Battle_createAllWindows.call(this);
	if (Isiah.CGC.statusWindowAtTop && $gameSystem._cardBattleEnabled)
	{
		this._statusWindow.setHelpWindow(this._helpWindow);
		this._actorCommandWindow.setHelpWindow(this._helpWindow);
		if (!Isiah.CGC.PartyUI)
			this._logWindow.y += this._statusWindow.height;
	}
};

if (Isiah.CGC.skipActorCommand)
{

	Isiah.CGC.Scene_Battle_startActorCommandSelection = Scene_Battle.prototype.startActorCommandSelection;
	Scene_Battle.prototype.startActorCommandSelection = function ()
	{
		if (!$gameSystem._cardBattleEnabled)
			return Isiah.CGC.Scene_Battle_startActorCommandSelection.call(this);

		this._statusWindow.select(BattleManager.actor().index());
		this._partyCommandWindow.close();
		this._partyCommandWindow.deactivate();
		//this._actorCommandWindow.setup(BattleManager.actor());
		this.commandSkill();
	};
}


//UI
Window_Base.prototype.drawActorCardZones = function (actor, x, y)
{
	var xx = x;
	var textWidth = this.textWidth("00");

	this.drawText(actor._cardHand.length, xx, y, textWidth, 'right');
	xx += textWidth;
	this.drawIcon(Isiah.CGC.statusIcons.handSize, xx, y + 2);

	xx += Window_Base._iconWidth + 4;

	this.drawText(actor._cardDeck.length, xx, y, textWidth, 'right');
	xx += textWidth;
	this.drawIcon(Isiah.CGC.statusIcons.deckSize, xx, y + 2);
	xx += Window_Base._iconWidth + 4;

	this.drawText(actor._cardDiscard.length, xx, y, textWidth, 'right');
	xx += textWidth;
	this.drawIcon(Isiah.CGC.statusIcons.discardSize, xx, y + 2);
};

Window_Base.prototype.drawActorCardZonesVertical = function (actor, x, y)
{
	var xx = x;
	var yy = y;
	var textWidth = this.textWidth("00");

	this.drawText(actor._cardHand.length, xx, yy, textWidth, 'right');
	this.drawIcon(Isiah.CGC.statusIcons.handSize, xx + textWidth, yy + 2);

	yy += this.lineHeight();

	this.drawText(actor._cardDeck.length, xx, yy, textWidth, 'right')
	this.drawIcon(Isiah.CGC.statusIcons.deckSize, xx + textWidth, yy + 2);

	yy += this.lineHeight();

	this.drawText(actor._cardDiscard.length, xx, yy, textWidth, 'right');
	this.drawIcon(Isiah.CGC.statusIcons.discardSize, xx + textWidth, yy + 2);
};




Isiah.Util.shuffleArray = function (array)
{
	let currentIndex = array.length, randomIndex;

	while (currentIndex != 0)
	{
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex--;

		[array[currentIndex], array[randomIndex]] = [
			array[randomIndex], array[currentIndex]];
	}

	return array;
};

Isiah.Util.createOutline = function (width, height, thickness)
{
	thickness = thickness || 1;
	var outline = new Bitmap(width, height);
	var sw = width;
	var sh = height;
	outline.fillRect(0, 0, sw, thickness, 'white');
	outline.fillRect(0, sh - thickness, sw, thickness, 'white');
	outline.fillRect(0, 0, thickness, sh, 'white');
	outline.fillRect(sw - thickness, 0, thickness, sh, 'white');

	return outline;
};

Isiah.Util.findSkillbyName = function (name)
{
	for (var i = 0; i < $dataSkills.length; i++)
	{
		var skill = $dataSkills[i];
		if (!skill) continue;
		if (skill.name == name)
			return skill;
	}

	return null;
}

Window_Base.prototype.drawIconScaled = function (iconIndex, x, y, width, height)
{
	var bitmap = ImageManager.loadSystem('IconSet');
	var pw = Window_Base._iconWidth;
	var ph = Window_Base._iconHeight;
	var sx = iconIndex % 16 * pw;
	var sy = Math.floor(iconIndex / 16) * ph;
	var b = new Bitmap(pw, ph);
	b.blt(bitmap, sx, sy, pw, ph, 0, 0)
	this.contents.blt(b, 0, 0, pw, ph, x, y, width, height);
}

Isiah.Util.spritePrototype.prototype.drawIconScaled = function (iconIndex, x, y, width, height)
{
	var bitmap = ImageManager.loadSystem('IconSet');

	var pw = Isiah.Util.usingMZ ? ImageManager.iconWidth : Window_Base._iconWidth;
	var ph = Isiah.Util.usingMZ ? ImageManager.iconHeight :  Window_Base._iconHeight;
	var sx = iconIndex % 16 * pw;
	var sy = Math.floor(iconIndex / 16) * ph;
	//console.log(pw, ph, sx, sy);
	var b = new Bitmap(pw, ph);
	b.blt(bitmap, sx, sy, pw, ph, 0, 0)
	this.bitmap.blt(b, 0, 0, pw, ph, x, y, width, height);
};

Isiah.Util.spritePrototype.prototype.drawIcon = function (iconIndex, x, y)
{
	var size = Isiah.CGC.fontSizes.iconSize;
	this.drawIconScaled(iconIndex, x, y - 3, size, size);
/*	var bitmap = ImageManager.loadSystem('IconSet');
	var pw = Window_Base._iconWidth;
	var ph = Window_Base._iconHeight;
	var sx = iconIndex % 16 * pw;
	var sy = Math.floor(iconIndex / 16) * ph;
	this.bitmap.blt(bitmap, sx, sy, pw, ph, x, y);*/
};



//=================================================================
// Scene_Skill -> Library Scene
//===================================================================

Isiah.CGC.Window_MenuCommand_addOriginalCommands = Window_MenuCommand.prototype.addOriginalCommands;
Window_MenuCommand.prototype.addOriginalCommands = function ()
{
	Isiah.CGC.Window_MenuCommand_addOriginalCommands.call(this);
	if (!Isiah.CGC.cardLibraryForSkill && $gameSystem._showCardLibraryInMenu)
		this.addCommand(Isiah.CGC.cardLibraryMenuDesc, 'card', true);
};

Isiah.CGC.Scene_Menu_createCommandWindow = Scene_Menu.prototype.createCommandWindow;
Scene_Menu.prototype.createCommandWindow = function ()
{
	Isiah.CGC.Scene_Menu_createCommandWindow.call(this);
	this._commandWindow.setHandler('card', this.commandPersonal.bind(this));
};

Isiah.CGC.Scene_Menu_onPersonalOk = Scene_Menu.prototype.onPersonalOk;
Scene_Menu.prototype.onPersonalOk = function ()
{
	var symbol = this._commandWindow.currentSymbol();
	if (symbol == 'skill' && Isiah.CGC.cardLibraryForSkill)
	{
		SceneManager.push(Scene_CardLibrary);
		return;
	}
	Isiah.CGC.Scene_Menu_onPersonalOk.call(this);
	if (symbol == 'card')
		SceneManager.push(Scene_CardLibrary);
}


function Scene_CardLibrary()
{
	this.initialize.apply(this, arguments);
};

Scene_CardLibrary.prototype = Object.create(Scene_Skill.prototype);
Scene_CardLibrary.prototype.constructor = Scene_CardLibrary;

Scene_CardLibrary.prototype.createHelpWindow = function ()
{
	if (Isiah.Util.usingMZ)
	{
		const rect = this.helpWindowRect();
		this._helpWindow = new Window_Help(rect);
	}
	else
		this._helpWindow = new Window_Help();

	if (Isiah.CGC.showHelpWindowInSkillScene)
		this.addWindow(this._helpWindow);
	else
	{
		this._helpWindow.y -= this._helpWindow.height;
		this._helpWindow.height = 0;
	}

};

Scene_CardLibrary.prototype.createItemWindow = function ()
{
	var wx = 0;
	var wy = this._statusWindow.y + this._statusWindow.height;
	var ww = Graphics.boxWidth;
	var wh = Graphics.boxHeight - wy;
	this._itemWindow = new Window_CardList(wx, wy, ww, wh);
	this._itemWindow.setHelpWindow(this._helpWindow);
	this._itemWindow.setHandler('ok', this.onItemOk.bind(this));
	this._itemWindow.setHandler('cancel', this.onItemCancel.bind(this));
	this._skillTypeWindow.setSkillWindow(this._itemWindow);
	this.addWindow(this._itemWindow);
};

Isiah.CGC.Scene_Base_createWindowLayer = Scene_Base.prototype.createWindowLayer
Scene_Base.prototype.createWindowLayer = function ()
{
	if (!this._cardParent)
	{
		var cardParent = new Sprite();
		this._cardParent = cardParent;
		this.addChild(this._cardParent);
	}
	Isiah.CGC.Scene_Base_createWindowLayer.call(this);

};

Scene_CardLibrary.prototype.addCardSprite = function (sprite)
{
	this._cardParent.addChild(sprite);
	if (sprite._amountText)
	{
		this._cardParent.addChild(sprite._amountText);
	}
};

Scene_CardLibrary.prototype.removeCardSprite = function (sprite)
{
	this._cardParent.removeChild(sprite);
	if (sprite._amountText)
		this._cardParent.removeChild(sprite._amountText);
};




/*Scene_Skill.prototype.createHelpWindow = function ()
{
	if (Isiah.Util.usingMZ)
	{
		const rect = this.helpWindowRect();
		this._helpWindow = new Window_Help(rect);
	}
	else
		this._helpWindow = new Window_Help();

	if (Isiah.CGC.showHelpWindowInSkillScene)
		this.addWindow(this._helpWindow);
	else
	{
		this._helpWindow.y -= this._helpWindow.height;
		this._helpWindow.height = 0;
	}

};

Scene_Skill.prototype.createItemWindow = function ()
{
	var wx = 0;
	var wy = this._statusWindow.y + this._statusWindow.height;
	var ww = Graphics.boxWidth;
	var wh = Graphics.boxHeight - wy;
	this._itemWindow = new Window_CardList(wx, wy, ww, wh);
	this._itemWindow.setHelpWindow(this._helpWindow);
	this._itemWindow.setHandler('ok', this.onItemOk.bind(this));
	this._itemWindow.setHandler('cancel', this.onItemCancel.bind(this));
	this._skillTypeWindow.setSkillWindow(this._itemWindow);
	this.addWindow(this._itemWindow);
};

Isiah.CGC.Scene_Skill_createWindowLayer = Scene_Skill.prototype.createWindowLayer;
Scene_Skill.prototype.createWindowLayer = function ()
{
	var cardParent = new Sprite();
	this._cardParent = cardParent;
	this.addChild(this._cardParent);
	Isiah.CGC.Scene_Skill_createWindowLayer.call(this);

};

Scene_Skill.prototype.addCardSprite = function (sprite)
{
	this._cardParent.addChild(sprite);
};

Scene_Skill.prototype.removeCardSprite = function (sprite)
{
	this._cardParent.removeChild(sprite);
};
*/

function Window_CardList()
{
	this.initialize.apply(this, arguments);
};

Window_CardList.prototype = Object.create(Window_SkillList.prototype);
Window_CardList.prototype.constructor = Window_CardList;

Window_CardList.prototype.initialize = function (x, y, width, height)
{
	if (Isiah.Util.usingMZ)
	{
		var rect = new Rectangle(x, y, width, height);
		Window_SkillList.prototype.initialize.call(this, rect);
	}
	else
		Window_SkillList.prototype.initialize.call(this, x, y, width, height);
	this.opacity = 0;
	this.contentsOpacity = 0;

	this._cardSprites = [];
	this._currentRow = 0;
	this._cardToCreate = -1;
	this._maxCols = 1;
};

Window_CardList.prototype.setActor = function (actor)
{
	Window_SkillList.prototype.setActor.call(this, actor);
	//this.createCardSprites();
};

Window_CardList.prototype.drawItemBackground = function (index)
{

};

Window_CardList.prototype.createCardSprites = function ()
{
	this.deleteCardSprites();
	this._cardToCreate = 0;
};


Window_CardList.prototype.refresh = function ()
{
	if ($gameSystem._cardBattleEnabled && !this.isInBattle())
		this.createCardSprites();

	Window_SkillList.prototype.refresh.call(this);

};

Isiah.CGC.Window_SkillList_makeItemList = Window_SkillList.prototype.makeItemList;
Window_SkillList.prototype.makeItemList = function ()
{
	if (!$gameSystem._cardBattleEnabled)
	{
		Isiah.CGC.Window_SkillList_makeItemList.call(this);
		return;
	}
	this._data = [];
	this._itemsBeforeCards = 0;

	var isBattle = this.isInBattle();
	var cards = isBattle ? this._cardSprites.getCards() : this._cardSprites;

	var addedHand = false;

	if (cards)
	{
		for (var buttonIndex = 0; buttonIndex < Isiah.CGC.buttonOrder.length; buttonIndex++)
		{
			var button = Isiah.CGC.buttonOrder[buttonIndex].toLowerCase();

			if (button == "hand")
			{
				addedHand = true;
				for (var i = 0; i < cards.length; i++)
				{
					var dataSkill = $dataSkills[cards[i]._skill];
					//if (!this.includes(dataSkill)) continue;
					this._data.push(cards[i]._skill);
					if (this.isEnabled(this._data[i + this._itemsBeforeCards]))
						cards[i]._enabledSprite.show();
					else
						cards[i]._enabledSprite.hide();
				}
			}
			else if (!isBattle || this.previewOnly)
				continue;
			else if (button == "item")
			{
				this._data.push('itemMenu');
				this._itemButton.setIndex(this._data.length - 1);

				if (!addedHand)
					this._itemsBeforeCards++;
			}
			else if (button == 'end' || button == 'endturn')
			{
				this._data.push($dataSkills[Isiah.CGC.endTurnSkill]);
				this._endTurnButton.setIndex(this._data.length - 1);

				if (!addedHand)
					this._itemsBeforeCards++;
			}
			else
			{
				this.addCustomCardButton(button, addedHand);
			}
		}
	}
};

Window_SkillList.prototype.isInBattle = function ()
{
	return false;
}

Window_BattleSkill.prototype.isInBattle = function ()
{
	return true;
}

Window_SkillList.prototype.addCustomCardButton = function (buttonName, addedHand)
{
	//to be overridded if/when new buttons are added
}

Window_SkillList.prototype.endTurnIndex = function ()
{
	if (!this._endTurnButton) return -1;

	return this._endTurnButton._index;

/*	var indexInArray = Isiah.CGC.buttonOrder.findIndex(function (button) { return button.toLowerCase() == "end" });
	if (indexInArray < Isiah.CGC.handIndex)
		return indexInArray;
	else
		return this._data.length - (Isiah.CGC.buttonOrder.length - indexInArray);*/
}

Window_SkillList.prototype.itemButtonIndex = function ()
{
	if (!this._itemButton) return -1;

	return this._itemButton._index;

/*	var indexInArray = Isiah.CGC.buttonOrder.findIndex(function (button) { return button.toLowerCase() == "item" });
	if (indexInArray < Isiah.CGC.handIndex)
		return indexInArray;
	else
		return this._data.length - (Isiah.CGC.buttonOrder.length - indexInArray);*/
}



Window_CardList.prototype.deleteCardSprites = function ()
{
	for (var i = this._cardSprites.length - 1; i >= 0; i--)
	{
		var card = this._cardSprites[i];
		SceneManager._scene.removeCardSprite(card);
	}
	this._cardSprites = [];
};

Window_CardList.prototype.update = function ()
{
	Window_SkillList.prototype.update.call(this);
	this.updateCardCreation();
	this.updateCardPosition();
};

Window_CardList.prototype.updateCardCreation = function ()
{
	if (this._cardToCreate == -1) return;

	var spriteCard = Isiah.CGC.simpleDeckView ? this.createSimpleCard() : this.createCard();
	if (spriteCard)
	{
		SceneManager._scene.addCardSprite(spriteCard);
		this._cardSprites.push(spriteCard);
		this.makeItemList();

		if (this._maxCols == -1)
			this.setMaxCols();
		spriteCard.x = -this.getCardX(0) * 2;
		spriteCard.y = this.getCardY(0);
	}

};

Window_CardList.prototype.actorCards = function ()
{
	return this._actor._skillCards.slice();
}

Window_CardList.prototype.createCard = function ()
{
	var skill = null; var valid = false;
	var amount = 0;
	var actor = this._actor;
	var actorCards = this.actorCards();
	do
	{
		
		this._cardToCreate++;;
		if (this._cardToCreate >= $dataSkills.length)
			return;
		
		skill = $dataSkills[this._cardToCreate];

		valid = (!!skill && !skill.hideFromCardLibrary && skill.name != "" && this.includes(skill));
		if (valid)
		{
			amount = 0;
			for (var j = actorCards.length - 1; j >= 0; j--)
			{
				var card = actorCards[j];
				if (card.id() == skill.id)
				{
					amount++;
					actorCards.splice(j, 1);
				}
			}
			if (amount == 0 && !this.showMissingCards())
				valid = false;
		}
	} while (!valid)
	var spriteCard = new Sprite_SkillCard(skill, actor);

	var amountBitmap = new Bitmap(40, 40);
	spriteCard._amountText = new Sprite(amountBitmap);
	spriteCard._amount = amount;
	//this.addChild(spriteCard._amountText);
	spriteCard.drawAmount();

	return spriteCard;
};

Window_CardList.prototype.showMissingCards = function ()
{
	return Isiah.CGC.showMissingCardsInLibrary;
}

Window_CardList.prototype.createSimpleCard = function ()
{
	var actor = this._actor;
	var cards = [...actor._skillCards._data];
	cards.sort(function (a, b) { return a.id() - b.id() });

	var skill = null; var valid = false;
	do
	{
		try
		{
			var id = cards[this._cardToCreate].id();
		}
		catch (error)
		{
			console.error(error)
		}
		skill = $dataSkills[id];
		valid = (!!skill && !skill.hideFromCardLibrary && skill.name != "");
		this._cardToCreate++;
		if (this._cardToCreate > cards.length)
			return;

	} while (!valid);

	var spriteCard = new Sprite_SkillCard(skill, actor);
	return spriteCard;
}

Window_CardList.prototype.setMaxCols = function ()
{
	var windowWidth = this.contents.width;
	var scale = this.cardScale();
	var buffer = this.getCardPadding();
	var cardWidth = this._cardSprites[0] ? (this._cardSprites[0].bitmap.width * scale.x) + buffer : buffer;
	var maxCols = Math.floor(windowWidth / cardWidth);
	this._maxCols = maxCols;
}

Window_CardList.prototype.getCardPadding = function ()
{
	return 20;
}

Window_CardList.prototype.ensureCursorVisible = function ()
{

}

Window_CardList.prototype.updateCardPosition = function ()
{
	var windowHeight = this.contents.height;
	var extraCardHeight = this.contents.fontSize * 2;
	var cardHeight = this._cardSprites[0] ? this._cardSprites[0].bitmap.height + extraCardHeight : extraCardHeight;
	//this._maxCols = maxCols;
	this.setMaxCols();
	var lowestRow = Math.floor(windowHeight / cardHeight);
	var currentRow = Math.floor(this.index() / this._maxCols);

	if (this._currentRow - currentRow < 0)
		this._currentRow++;
	if (this._currentRow - currentRow >= lowestRow)
		this._currentRow--;
	if (this.index() == -1)
		this._currentRow = 0;
	for (var i = 0; i < this._cardSprites.length; i++)
	{
		var card = this._cardSprites[i];
		var targetX = this.getCardX(i);
		card.x += (targetX - card.x) / 10;
		var targetY = this.getCardY(i);
		card.y += (targetY - card.y) / 10;

		if (this.index() == i)
			card.scale = this.selectedCardScale();
		else
			card.scale = this.cardScale();

		if (card._amountText)
		{

			card._amountText.x = this.getAmountX(card);
			card._amountText.y = this.getAmountY(card);
		}
	}
};

Window_CardList.prototype.cardScale = function ()
{
	return new Point(1, 1);
}

Window_CardList.prototype.selectedCardScale = function ()
{
	return new Point(1.1, 1.1);
}

Window_CardList.prototype.getCardX = function (index)
{
	var cardWidth = this.getCardPadding();
	if (this._cardSprites[0])
	{
		var scaleX = this.cardScale().x;
		cardWidth = this._cardSprites[0].bitmap.width * scaleX;
	}
	var totalCardWidth = cardWidth + this.getCardPadding();
	var startingPadding = this.standardPadding ? this.standardPadding() : 30;

	var targetX = this.x + totalCardWidth * (index % this._maxCols) + startingPadding + cardWidth / 2;
	return targetX;
}

Window_CardList.prototype.getCardY = function (index)
{
	var extraCardHeight = this.extraCardHeight();
	var cardHeight = extraCardHeight;
	if (this._cardSprites[0])
	{
		var scaleY = this.cardScale().y;
		cardHeight = this._cardSprites[0].bitmap.height * scaleY + extraCardHeight;
	}
	//var cardHeight = this._cardSprites[0] ? this._cardSprites[0].bitmap.height + extraCardHeight : extraCardHeight;
	var padding = this.standardPadding ? this.standardPadding() : 30;

	var targetY = this.y + cardHeight * (Math.floor(index / this._maxCols) - this._currentRow) + padding * 2 + (cardHeight - extraCardHeight) / 2;

	return targetY;
};

Window_CardList.prototype.extraCardHeight = function ()
{
	return this.contents.fontSize * 2;
}

Window_CardList.prototype.getAmountX = function (spriteCard)
{
	return spriteCard.x - (spriteCard._amountText.bitmap.width / 2);
}

Window_CardList.prototype.getAmountY = function (spriteCard)
{
	return spriteCard.y + spriteCard.bitmap.height / 2 * this.cardScale().y;
}

Window_CardList.prototype.maxCols = function ()
{
	return this._maxCols;
};

Window_CardList.prototype.refresh = function ()
{
	if ($gameSystem._cardBattleEnabled && !this.isInBattle())
		this.createCardSprites();

	Window_SkillList.prototype.refresh.call(this);

};




Isiah.CGC.DataManager_isDatabaseLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function ()
{
	if (!Isiah.CGC.DataManager_isDatabaseLoaded.call(this)) return false;
	if (!Isiah.loaded_CGC)
	{
		DataManager.processCardAppearanceNotetags($dataSkills);

		DataManager.processCardActionNotetags($dataSkills);
		DataManager.processCardActionNotetags($dataItems);

		DataManager.processCardTargetActionNotetags($dataSkills);
		DataManager.processCardTargetActionNotetags($dataItems);

		DataManager.processCardPassiveNotetags($dataSkills);


		//deprecated
		DataManager.processCardBehaviorNotetags($dataSkills);
		DataManager.processCardBehaviorNotetags($dataItems);
		DataManager.processCardBehaviorNotetags2($dataSkills);
		DataManager.processCardBehaviorNotetags2($dataItems);
		Isiah.loaded_CGC = true;
	}

	return true;
}

DataManager.processCardAppearanceNotetags = function (group)
{
	var hideNote = /<(?:HIDE FROM CARD LIBRARY)>/i;
	var artNote = /<(?:CARD ART: )(.*)>/i;
	var designNote = /<(?:CARD BASE: )(.*)>/i;
	
	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);

		for (var i = 0; i < notedata.length; i++)
		{			
			var line = notedata[i];
			if (line.match(hideNote))
			{
				obj.hideFromCardLibrary = true;
			}
			else if (line.match(artNote))
			{
				obj._cardArt = RegExp.$1;
			}
			else if(line.match(designNote))
			{
				obj._cardBase = RegExp.$1;
			}
		}
	}
};

DataManager.processCardActionNotetags = function (group)
{
	var startNote = /<Card Actions?>/i;
	var endNote = /<\/Card Actions?>/i;


	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);
		var mode = '';
		for (var i = 0; i < notedata.length; i++)
		{
			var line = notedata[i];
			if (line.match(startNote))
			{
				mode = 'actions';
				obj._cardActions = "";
			}
			else if (line.match(endNote))
			{
				mode = '';
			}
			else if (mode == 'actions')
			{
				line = line.trim();
				line = line.replace(/,/g, '`comma`');
				if (obj._cardActions == "")
					obj._cardActions = line.trim();
				else
					obj._cardActions += "," + line.trim();
			}
		}
	}
};

DataManager.processCardTargetActionNotetags = function (group)
{
	var startNote = /<Card Target Actions?>/i;
	var endNote = /<\/Card Target Actions?>/i;


	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);
		var mode = '';
		for (var i = 0; i < notedata.length; i++)
		{
			var line = notedata[i];
			if (line.match(startNote))
			{
				mode = 'actions';
				obj._cardTargetActions = "";
			}
			else if (line.match(endNote))
			{
				mode = '';
			}
			else if (mode == 'actions')
			{
				line = line.trim();
				line = line.replace(/,/g, '`comma`');
				if (obj._cardTargetActions == "")
					obj._cardTargetActions = line.trim();
				else
					obj._cardTargetActions += "," + line.trim();
			}
		}
	}
};

DataManager.processCardPassiveNotetags = function (group)
{
	var startNote = /<Card Passives?>/i;
	var endNote = /<\/Card Passives?>/i;


	var removeThisNote = /remove this/i;

	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);
		var mode = '';
		for (var i = 0; i < notedata.length; i++)
		{
			var line = notedata[i];
			if (line.match(startNote))
			{
				mode = 'passives';
				obj._cardPassives = {};
			}
			else if (line.match(endNote))
			{
				mode = '';
			}
			else if (mode == 'passives')
			{
				if (line.match(/remove this/i))
					obj._cardPassives.removeAfterPlay = true;
				else if (line.match(/discard if unplayed/i))
					obj._cardPassives.discardIfUnplayed = true;
				else if (line.match(/remove if unplayed/i))
					obj._cardPassives.removeIfUnplayed = true;
				else if (line.match(/start in hand/i))
					obj._cardPassives.startInZone = 'hand';
				else if (line.match(/start in discard/i))
					obj._cardPassives.startInZone = 'discard'; // TODO
				else if (line.match(/require (.*)/i))
				{
					if (!obj._cardPassives.requirements)
						obj._cardPassives.requirements = [];

					obj._cardPassives.requirements.push(RegExp.$1);
				}
				else if (line.match(/start of turn:? ?(?:skill)? ?(\d+)/i))
				{
					if (!obj.__forcedActions)
						obj.__forcedActions = {};
					if (!obj.__forcedActions.turnStart)
						obj.__forcedActions.turnStart = [];
					obj.__forcedActions.turnStart.push(RegExp.$1);
				}
				else if (line.match(/end of turn:? ?(?:skill)? ?(\d+)/i))
				{
					if (!obj.__forcedActions)
						obj.__forcedActions = {};
					if (!obj.__forcedActions.turnEnd)
						obj.__forcedActions.turnEnd = [];
					obj.__forcedActions.turnEnd.push(RegExp.$1);
				}
				else if (line.match(/enter (\w*):? ?(?:skill)? ?(\d+)/i))
				{
					if (!obj.__forcedActions)
						obj.__forcedActions = {};
					if (!obj.__forcedActions.enterZone)
						obj.__forcedActions.enterZone = [];
					var zoneData = { zone: RegExp.$1, skill: RegExp.$2 };
					obj.__forcedActions.enterZone.push(zoneData);
				}
				else if (line.match(/exit (\w*):? ?(?:skill)? ?(\d+)/i))
				{
					if (!obj.__forcedActions)
						obj.__forcedActions = {};
					if (!obj.__forcedActions.exitZone)
						obj.__forcedActions.exitZone = [];
					var zoneData = { zone: RegExp.$1, skill: RegExp.$2 };
					obj.__forcedActions.exitZone.push(zoneData);
				}
			}
		}
	}
}

DataManager.processCardBehaviorNotetags = function (group)
{
	var escapeIfNote = /<Card Actions?>/i;

	var drawNote = /<?(?:Draw )(\d+)>?/i;
	var drawUntilNote = /<?(?:Draw Until )(\d+)>?/i;
	var discardNote = /<?(?:Discard )(\d+)>?/i;
	var discardUntilNote = /<?(?:Discard Until )(\d+)>?/i;
	var shuffleNote = /<?Shuffle Deck>?/i;

	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);

		for (var i = 0; i < notedata.length; i++)
		{
			var line = notedata[i];

			if (line.match(escapeIfNote))
				break;

			if (line.match(drawNote))
			{
				obj._amountToDraw = RegExp.$1;
				obj._amountToDrawTo = undefined;
			}
			else if (line.match(drawUntilNote))
			{
				obj._amountToDraw = undefined;
				obj._amountToDrawTo = RegExp.$1;
			}
			else if (line.match(discardNote))
			{
				obj._amountToDiscard = RegExp.$1;
				obj._amountToDiscardTo = undefined;
			}
			else if (line.match(discardUntilNote))
			{
				obj._amountToDiscard = undefined;
				obj._amountToDiscardTo = RegExp.$1;
			}
			else if (line.match(shuffleNote))
			{
				obj._shuffle = 'deck';
			}
		}
	}
};

DataManager.processCardBehaviorNotetags2 = function (group)
{
	var escapeIfNote = /<Card Actions?>/i;


	var removeThisNote = /<?(?:Remove this)>?/i
	var removeNote = /<?(?:Remove )(\d+)>?/i;
	var removeUntilNote = /<?(?:Remove Until )(\d+)>?/i;

	for (n = 1; n < group.length; n++)
	{
		var obj = group[n];
		var notedata = obj.note.split(/[\r\n]+/);

		for (var i = 0; i < notedata.length; i++)
		{
			var line = notedata[i];

			if (line.match(escapeIfNote))
				break;

			if (line.match(removeThisNote))
			{
				obj._removeAfterPlay = true;
			}
			else if (line.match(removeNote))
			{
				obj._amountToRemove = RegExp.$1;
				obj._amountToRemoveTo = undefined;
			}
			else if (line.match(removeUntilNote))
			{
				obj._amountToRemove = undefined;
				obj._amountToRemoveTo = RegExp.$1;
			}
		}
	}
}


// DEPRECATED
Game_Action.prototype.applyCardEffect = function ()
{
	var item = this.item();
	if (item._amountToDraw)
	{
		this.subject().drawCards(item._amountToDraw);
	}
	if (item._amountToDrawTo)
	{
		this.subject().drawCardsUntil(item._amountToDrawTo);
	}
	if (item._amountToDiscard)
	{
		this.subject().discardCards(item._amountToDiscard);
	}
	if (item._amountToDiscardTo)
	{
		this.subject().discardCardsUntil(item._amountToDiscardTo);
	}
	if (item._amountToRemove)
	{
		this.subject().removeCards(item._amountToRemove);
	}
	if (item._amountToRemoveTo)
	{
		this.subject().removeCardsUntil(item._amountToRemoveTo);
	}
	if (item._shuffle == 'deck')
	{
		this.subject().shuffleDeck();
	}
	this.subject().syncEvalVariables();
};

if (Imported.YEP_BattleEngineCore)
{
	BattleManager.updateActionTargetList = function ()
	{
		for (; ;)
		{
			if (this._phase == 'discard') break;
			if (this._phase == 'cardwait') break;
			this._actSeq = this._actionList.shift();
			if (this._actSeq)
			{
				if (!this.actionConditionsMet(this._actSeq)) continue;
				var seqName = this._actSeq[0].toUpperCase();
				if (!this.processActionSequenceCheck(seqName, this._actSeq[1]))
				{
					break;
				}
			} else if (this._individualTargets.length > 0)
			{
				this._individualTargets.shift();
				if (this._individualTargets.length > 0)
				{
					this.setTargets([this._individualTargets[0]]);
					this._actionList = this._action.item().targetActions.slice();
				} else
				{
					this._phase = 'phaseChange';

					break;
				}
			} else
			{
				this._phase = 'phaseChange';
				break;
			}
		}
	};
}

if (!Imported.YEP_InstantCast)
{
	

	Isiah.CGC.Scene_Battle_selectNextCommand = Scene_Battle.prototype.selectNextCommand;
	Scene_Battle.prototype.selectNextCommand = function ()
	{
		if (this.willCardEndTurn())
		{
			BattleManager._endTheTurn = true;
			Isiah.CGC.Scene_Battle_selectNextCommand.call(this);
		}
		else
		{
			BattleManager.playCard();
		}
	}

	Scene_Battle.prototype.willCardEndTurn = function ()
	{
		if (!$gameSystem._cardBattleEnabled) return true;

		var actor = BattleManager.actor();
		if (!actor) return true;
		var action = BattleManager.inputtingAction();
		if (!action) return false;
		if (action !== actor.action(0)) return false;
		var item = action.item();
		if (!item) return false;
		return item.meta.willEndTurn;
	};

	BattleManager.playCard = function ()
	{
		if (Imported.YEP_BattleEngineCore)
		{
			this.stopAllSelection();
			this.resetSelection();
		}
		this._subject = BattleManager.actor();
		if (!this._subject)
			this._subject = this._actionForcedBattler;
		this._endTheTurn = false;
		if (Imported.YEP_BattleEngineCore && BattleManager.isDTB())
		{
			this._ignoreTurnOrderFirstIndex = true;
		}
		this.startAction();
	}

	Isiah.CGC.BattleManager_endAction = BattleManager.endAction;
	BattleManager.endAction = function ()
	{
		if ($gameSystem._cardBattleEnabled && this._endTheTurn === false)
		{
			this.doNotEndTurn();
/*			if (this.__forcedActions.length > 0)
				this._phase = 'input';*/
		} else
		{
			Isiah.CGC.BattleManager_endAction.call(this);
		}
	};

	BattleManager.doNotEndTurn = function ()
	{
		if (Imported.YEP_BattleEngineCore && BattleManager.isDTB())
		{
			this._ignoreTurnOrderFirstIndex = false;
		}
		var user = this._subject;
		if (Imported.YEP_BattleEngineCore)
		{
			if (this._processingForcedAction) this._phase = this._preForcePhase;
			this._processingForcedAction = false;
		}
		if (this.updateEventMain()) return;
		Isiah.CGC.BattleManager_endAction.call(this);
		this._subject = user;
		user.makeActions();
		if (this.checkBattleEnd()) return;
		this._phase = 'input';
		if (!(user.canMove() && user.canInput()))
		{
			user.makeActions();
			this.selectNextCommand();
		}
		this._endTheTurn = true;
		if (Isiah.Util.usingMZ)
		{
			var skillWindow = SceneManager._scene._skillWindow;
			skillWindow.activate();
			skillWindow.select(skillWindow._itemsBeforeCards);
		}
		else
			this.refreshStatus();
		if (Imported.YEP_BattleEngineCore && BattleManager.isDTB())
		{
			this._subject = undefined;
		}

		if (Isiah.CGC.showHelpWindow && this.__forcedActions.length == 0)
			SceneManager._scene._helpWindow.show();
	};
}
